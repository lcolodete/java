package generics.crate;

public class Zebra {

}
