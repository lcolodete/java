package generics.crate;

public class Elephant {

}
