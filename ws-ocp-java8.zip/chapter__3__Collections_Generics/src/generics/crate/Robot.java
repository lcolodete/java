package generics.crate;

public class Robot {

}
