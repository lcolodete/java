package generics.crate;

public interface Shippable<T> {

	public void ship(T t);
}
