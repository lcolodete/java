package generics.crate;

public class Car {

}
