package generics.crate;

public class ShippableRobotCrate implements Shippable<Robot> {

	@Override
	public void ship(Robot t) {
		
	}

}
