package appendix;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TestLock2 {

	private static Lock lock = new ReentrantLock();
	
	private static void performTask() {
		if (lock.tryLock()) {
			
			try {
				System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : BEGIN");
				
				Thread.sleep(10);
				
				System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : task");
				System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : END");
				
			} catch(Exception e) {
				
			} finally {
				lock.unlock();
			}
			
		} else {
			System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : unable to acquire lock");
		}
	}
	
	public static void main(String[] args) throws InterruptedException {

		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(6);
			
			service.execute( () -> performTask() );
			service.execute( () -> performTask() );
			service.execute( () -> performTask() );
			service.execute( () -> performTask() );
			service.execute( () -> performTask() );
			
			Thread.sleep(3000);
			
			service.execute( () -> performTask() );
			
		} finally {
			if (service != null)
				service.shutdown();
		}
		
	}

}
