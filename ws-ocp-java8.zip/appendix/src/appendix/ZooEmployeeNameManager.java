package appendix;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ZooEmployeeNameManager {

	private ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
	
	private List<String> names = new ArrayList<>();
	
	public ZooEmployeeNameManager() {
		names.addAll(Arrays.asList("John Smith", "Sarah Smith", "James Johnson"));
	}
	
	private String readNames(int i) {
		Lock lock = readWriteLock.readLock();
		try {
			lock.lock();
			System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : Read Lock Obtained!");
			return names.get(i % names.size());
		} finally {
			System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : Read Lock Released!");
			lock.unlock();
		}
	}
	
	private void addName(String name) {
		Lock lock = readWriteLock.writeLock();
		try {
			lock.lock();
			System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : Write Lock Obtained!");
			
			Thread.sleep(3000);
			
			names.add(name);
		} catch (Exception e) {
			
		} finally {
			System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : Write Lock Released!");
			lock.unlock();
		}
	}
	
	public static void main(String[] args) {

		ZooEmployeeNameManager manager = new ZooEmployeeNameManager();
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(20);
			
			for (int i=0; i<100; i++) {
				final int employeeNumber = i;
				service.execute( () ->  manager.readNames(employeeNumber));
			}
			
			service.execute( () -> manager.addName("Grace Hopper"));
			service.execute( () -> manager.addName("Josephine Davis"));
			
		} finally {
			if (service != null)
				service.shutdown();
		}
	}

}
