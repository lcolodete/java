package appendix;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SheepManagerReentrantLock {

	private int sheepCount = 0;
	
	private Lock lock = new ReentrantLock();
	
	private void incrementAndReport() {
		try {
			lock.lock();
			System.out.print((++sheepCount)+" ");
		} finally {
			lock.unlock();
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		for (int i=0; i<200; i++)
			testSheepManager();
		
	}

	private static void testSheepManager() throws InterruptedException {
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(20);
			
			SheepManagerReentrantLock manager = new SheepManagerReentrantLock();
			
			for (int i=0; i<10; i++) {
				service.submit( () ->  manager.incrementAndReport());
			}
		} finally {
			if (service != null)
				service.shutdown();
			
			service.awaitTermination(2, TimeUnit.SECONDS);
			System.out.println(" >> END ("+service.isTerminated()+")");
		}
	}
}
