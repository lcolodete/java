package appendix;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TestLock3 {

	private static Lock lock = new ReentrantLock();
	
	private static void performTask() {
		if (lock.tryLock()) {
			
			try {
				System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : BEGIN");
				
				Thread.sleep(6000);
				
				System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : task");
				System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : END");
				
			} catch(Exception e) {
				
			} finally {
				lock.unlock();
			}
			
		} else {
			System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : unable to acquire lock");
		}
	}
	
	private static void performTaskWithTryLockWait() {
		try {
			System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : performTaskWithTryLockWait");
			if (lock.tryLock(7000, TimeUnit.MILLISECONDS)) {
				
				try {
					System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : BEGIN");
					System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : task");
					System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : END");
					
				} catch(Exception e) {
					
				} finally {
					lock.unlock();
				}
				
			} else {
				System.out.println(">>>>>> ("+Thread.currentThread().getName()+") : unable to acquire lock");
			}
		} catch (InterruptedException e) {
			
		}
	}
	
	public static void main(String[] args) throws InterruptedException {

		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(6);
			
			service.execute( () -> performTask() );
			service.execute( () -> performTask() );
			service.execute( () -> performTask() );
			service.execute( () -> performTask() );
			service.execute( () -> performTaskWithTryLockWait() );
			
		} finally {
			if (service != null)
				service.shutdown();
		}
		
	}

}
