package patterns;

import java.util.Arrays;

public class TestAnimal_v2 {

	public static void main(String[] args) {
		Animal_v2 duck = Animal_v2.getBuilder()
						.setAge(10)
						.setFavoriteFoods(Arrays.asList("grass", "fish"))
						.setSpecies("duck")
						.build();
		
		Animal_v2 myDog = new Animal_v2.AnimalBuilder()
		.setAge(7)
		.setSpecies("dog")
		.setFavoriteFoods(Arrays.asList("rice", "carrots", "melon"))
		.build();
		
		System.out.println(myDog.getAge());
		System.out.println(myDog.getSpecies());
		System.out.println(myDog.getFavoriteFoods());
		
		System.out.println(duck.getAge());
		System.out.println(duck.getSpecies());
		System.out.println(duck.getFavoriteFoods());
	}
}
