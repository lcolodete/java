package functional;

@FunctionalInterface
public interface CheckTrait {

	public boolean test(Animal a);

}
