package teste.dom4j;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.URL;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class TesteDom4j {

	/**
	 * @param args
	 * @throws FileNotFoundException
	 * @throws DocumentException
	 */
	public static void main(String[] args) throws FileNotFoundException,
			DocumentException {
		System.out.println("TesteDom4j");

		String mvnUserDir = System.getProperty("user.home") + "/.m2";
		System.out.println("mvnUserDir="+mvnUserDir);

		FileReader reader = new FileReader(mvnUserDir + "/" + "settings.xml");
		Document document = parse(reader);
		System.out.println(document);

		// tem que ter o jaxen no classpath
		// Node node = document.selectSingleNode("//settings/localRepository");

		Element root = document.getRootElement();

		Element localRepoElement = root.element("localRepository");
		System.out.println("localRepoElement=" + localRepoElement);
		System.out.println("localRepoElement.getText()="
				+ localRepoElement.getText());

		// iterate through child elements of root with element name
		// "localRepository"
		// for ( Iterator i = root.elementIterator( "localRepository" );
		// i.hasNext(); ) {
		// Element localRepoElement = (Element) i.next();
		// // do something
		// System.out.println("localRepoElement="+localRepoElement);
		// System.out.println("localRepoElement.getData()="+localRepoElement.getData());
		// System.out.println("localRepoElement.getText()="+localRepoElement.getText());
		// }

	}

	public static Document parse(URL url) throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(url);
		return document;
	}

	public static Document parse(FileReader fileReader)
			throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(fileReader);
		return document;
	}
}
