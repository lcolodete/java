package teste.xstream;

public class PhoneNumber {
	private int code;
	  private String number;
	public PhoneNumber(int code, String number) {
		super();
		this.code = code;
		this.number = number;
	}
}
