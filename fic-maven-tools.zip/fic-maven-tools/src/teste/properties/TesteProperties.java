package teste.properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class TesteProperties {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Properties props = new Properties();
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream(System.getProperty("user.dir") + "/maximo_version.properties");
			props.load(inputStream);
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo properties nao encontrado: "+e.getMessage());
		} catch (IOException e) {
			System.out.println("Erro ao carregar arquivo properties: "+e.getMessage());
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					System.out.println("Erro ao fechar o arquivo properties.");
				}
			}
		}
		
		System.out.println(props.getProperty("MAXIMO_LIBS_PATH"));
		System.out.println(props.getProperty("MAXIMO_LIBS_VERSION"));
		
	}

}
