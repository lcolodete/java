package teste.regex;

public class TesteRegex {

	public static void main(String[] args) {
		String templateFile = "MAXIMO_7116_LIBS_GEN.template";
		System.out.println(templateFile.matches("\\w*\\.template$"));
		System.out.println(templateFile.matches("MAXIMO\\w*.template"));
		
		String s = "AAAb";
		System.out.println(s.matches("A*b"));
	}
}
