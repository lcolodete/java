package petrobras.engenharia.fic.cronovisao.service.cronhistory;

import java.util.ArrayList;
import java.util.List;

import petrobras.engenharia.fic.cronovisao.service.OrderByObject;
import petrobras.engenharia.fic.cronovisao.service.PagerObject;
import petrobras.engenharia.fic.cronovisao.service.XmlQuery;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

public final class CronHistoryQuery extends XmlQuery {

	private PagerObject pagerObject;
//	private OrderByObject orderObject;
	
	public CronHistoryQuery(String cronTaskName, List<CronTaskInstance> cronInstances, PagerObject pager, OrderByObject orderObject) {
		this.pagerObject = pager;
//		this.orderObject = orderObject;
		List<String> instanceNames = new ArrayList<String>();
		for (CronTaskInstance c : cronInstances) {
			instanceNames.add(c.getInstancename());
		}
		this.where = CronHistoryQueryHelper.buildWhere(instanceNames, cronTaskName);
		
		String sortField = null;
		String sortOrder = null;
		
		if (orderObject != null) {
			sortField = orderObject.getFieldName();
			sortOrder = orderObject.getOrder();
			
			if (sortField != null && !sortField.isEmpty() && sortOrder != null && !sortOrder.isEmpty()) {
				String attributeName = sortField;
				if (attributeName.equals("dataInicio"))
					attributeName = "starttime";
				else if (attributeName.equals("dataFim"))
					attributeName = "endtime";
				else if (attributeName.equals("duracao"))
					attributeName = "(endtime-starttime)";
				this.where += String.format(" order by %s %s", attributeName, sortOrder);
			}
		}
	}
	
	//Um instanceName : nao precisa de paginacao nem de ordenacao 
	public CronHistoryQuery(String cronTaskName, String cronInstanceName) {
		this.where = CronHistoryQueryHelper.buildWhere(cronInstanceName, cronTaskName);
	}
	
	public static class CronHistoryQueryBuilder {
		private String cronTaskName;
		private List<CronTaskInstance> cronInstances;
		private String instanceName;
		private PagerObject pagerObject;
		private OrderByObject orderObject;
		
		public CronHistoryQueryBuilder setCronTaskName(String cronTaskName) {
			this.cronTaskName = cronTaskName;
			return this;
		}
		
		public CronHistoryQueryBuilder setCronInstances(List<CronTaskInstance> cronInstances) {
			this.cronInstances = cronInstances;
			return this;
		}
		
		public CronHistoryQueryBuilder setInstanceName(String instanceName) {
			this.instanceName = instanceName;
			return this;
		}
		
		public CronHistoryQueryBuilder setPagerObject(PagerObject pager) {
			this.pagerObject = pager;
			return this;
		}
		
		public CronHistoryQueryBuilder setOrderByObject(OrderByObject orderObject) {
			this.orderObject = orderObject;
			return this;
		}
		
		public CronHistoryQuery build() {
			if (instanceName != null && !instanceName.isEmpty())
				return new CronHistoryQuery(cronTaskName, instanceName);
			return new CronHistoryQuery(cronTaskName, cronInstances, pagerObject, orderObject);
		}
	}
	
	@Override
	protected String getXmlBegin() {
		
		Integer rsStart = null;
		Integer maxItems = null;
		
		StringBuilder resultStr = new StringBuilder();
		resultStr.append("<max:QueryMXCRONHIST xmlns:max=\"http://www.ibm.com/maximo\"");
		
		if (pagerObject != null) {
			rsStart = pagerObject.getFirst();
			maxItems = pagerObject.getPageSize();
			
			if (rsStart != null && maxItems != null) {
				resultStr.append(String.format(" rsStart=\"%d\" maxItems=\"%d\"", rsStart, maxItems));
			}
		}
		
		resultStr.append("><max:MXCRONHISTQuery");
		
		//TODO o orderby como um atributo nao funciona junto com o elemento <max:WHERE>. 
		// Para ordenar com <max:WHERE>, deve ser informado um order by no final da clausula where, como em SQL 

		//TODO o orderby como atributo funciona com QueryByExample
		
		//TODO Mover esse codigo para uma superclasse QueryByExample
//		String sortField = null;
//		String sortOrder = null;
//		
//		if (orderObject != null) {
//			sortField = orderObject.getFieldName();
//			sortOrder = orderObject.getOrder();
//			
//			if (sortField != null && !sortField.isEmpty() && sortOrder != null && !sortOrder.isEmpty()) {
//				resultStr.append(String.format(" orderby=\"%s %s\"", sortField, sortOrder));
//			}
//		}
		
		resultStr.append(">");
		
		return resultStr.toString();
	}

	@Override
	protected String getXmlEnd() {
		return "</max:MXCRONHISTQuery></max:QueryMXCRONHIST>";
	}

}
