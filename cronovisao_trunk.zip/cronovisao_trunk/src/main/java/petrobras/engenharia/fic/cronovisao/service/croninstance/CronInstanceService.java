package petrobras.engenharia.fic.cronovisao.service.croninstance;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.AbstractHttpClient;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryResponse;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

public class CronInstanceService extends AbstractHttpClient implements IServiceDelegate<CronTaskInstance, String> {

	private static final Logger logger = LogManager.getLogger(CronInstanceService.class);
	
	private static Configuracao config = Configuracao.getInstance();
	
	public CronInstanceService() {
		super(config.getMosCronTaskInstance());
	}

	private static final long serialVersionUID = 1L;

	@Override
	public Set<CronTaskInstance> processMessage(String query) {
		
		if (query == null || query.isEmpty()) {
			return null;
		}
		
		CronInstanceQueryResponse cronInstanceQueryResponse = getBuilder().post(CronInstanceQueryResponse.class, query);

		List<CronTaskInstance> cronInstances = cronInstanceQueryResponse.getCronInstances();

		Set<CronTaskInstance> cronInstanceSet = new TreeSet<CronTaskInstance>();
		cronInstanceSet.addAll(cronInstances);

		return cronInstanceSet;
	}

}
