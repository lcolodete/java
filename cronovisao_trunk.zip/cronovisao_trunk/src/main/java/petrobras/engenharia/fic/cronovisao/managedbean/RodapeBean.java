package petrobras.engenharia.fic.cronovisao.managedbean;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;


@SessionScoped
@ManagedBean
public class RodapeBean implements Serializable {

	private static final long serialVersionUID = 1L;

	public RodapeBean() {
	}
	
	public String getCurrentTime() {
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
		return df.format(new Date());
	}
	
//	public static void main(String[] args) {
//		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
//		System.out.println(df.format(new Date()));
//	}
}

