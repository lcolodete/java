package petrobras.engenharia.fic.cronovisao.model;

import java.io.Serializable;
import java.util.List;

import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

/**
 * Agenda de cron tasks de gera��o de ordens de preserva��o.
 * 
 * @author UR5G
 *
 */
public class AgendaPmWoGen implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * lista de objetos Dia, que define a agenda de segunda a domingo
	 */
	private List<Dia> programacaoSemanal;
	
	/**
	 * lista de CronTaskInstances que tem programa��es diferentes de semanal 
	 */
	private List<CronTaskInstance> outrasProgramacoes;

	public List<Dia> getProgramacaoSemanal() {
		return programacaoSemanal;
	}

	public void setProgramacaoSemanal(List<Dia> programacaoSemanal) {
		this.programacaoSemanal = programacaoSemanal;
	}

	public List<CronTaskInstance> getOutrasProgramacoes() {
		return outrasProgramacoes;
	}

	public void setOutrasProgramacoes(List<CronTaskInstance> outrasProgramacoes) {
		this.outrasProgramacoes = outrasProgramacoes;
	}

	
}
