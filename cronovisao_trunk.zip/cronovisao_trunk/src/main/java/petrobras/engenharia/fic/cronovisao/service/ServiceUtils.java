package petrobras.engenharia.fic.cronovisao.service;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;

public class ServiceUtils {

	private static Configuracao config = Configuracao.getInstance();
	
	/**
	 * Constroi o header de autenticacao exigido pelo servi�o.
	 * Este header deve conter usuario e senha v�lidos para login no Maximo.
	 *  
	 * O header � calculado da seguinte forma:
	 * <code>
	 * BASE_64( usuario:senha )
	 * </code> 
	 * 
	 * @return
	 */
	public static String buildAuthHeader() {
		
		String usuario = config.getUsuario();
		String senhaBase64 = config.getSenha();
		
		String senhaAberta = Base64Utils.decode(senhaBase64);
		
		String sEncoded = Base64Utils.encode(usuario+":"+senhaAberta);
		
		return sEncoded;
	}
	
}
