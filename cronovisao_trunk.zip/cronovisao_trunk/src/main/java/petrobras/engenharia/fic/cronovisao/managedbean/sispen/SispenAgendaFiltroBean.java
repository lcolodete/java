package petrobras.engenharia.fic.cronovisao.managedbean.sispen;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceQuery;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryByExample;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ManagedBean
@ViewScoped
public class SispenAgendaFiltroBean {

	private static final Logger logger = Logger.getLogger(SispenAgendaFiltroBean.class);
	
	private DataTable dataTable;

	private IServiceDelegate<CronTaskInstance, CronInstanceQueryByExample> cronInstanceService = new SispenCronInstanceService();
	
	private List<CronTaskInstance> cronTaskList;

	private String txtEmpreendimento;
	
	public SispenAgendaFiltroBean() {
	}
	
	public void filtrar() {
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> filtrar()");
		}
		
		this.dataTable.setValueExpression("sortBy", null);
		this.carregarLista();
	}
	
	private void carregarLista() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> carregarLista()");
		}
			
		this.cronTaskList = null;

		SispenCronInstanceQuery sispenQuery = new SispenCronInstanceQuery(txtEmpreendimento.toLowerCase());
		Set<CronTaskInstance> cronInstances = cronInstanceService.processMessage(sispenQuery.getQueryObject());
		
		if (cronInstances != null && cronInstances.size() > 0) {
			for (CronTaskInstance cron : cronInstances) {
				cron.setEmpreendimento(cron.getParam("EMPREENDIMENTO"));
			}

			this.cronTaskList = new ArrayList<CronTaskInstance>(cronInstances);
		}
	}
	
	public List<CronTaskInstance> getCronTaskList() {
		return cronTaskList;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}


	public String getTxtEmpreendimento() {
		return txtEmpreendimento;
	}


	public void setTxtEmpreendimento(String txtEmpreendimento) {
		this.txtEmpreendimento = txtEmpreendimento;
	}

}
