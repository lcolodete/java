package petrobras.engenharia.fic.cronovisao.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;

public class DateUtil {
	
	public static final Locale LOCALE_PT_BR = new Locale("pt", "BR");

	/**
	 * Formata uma data para exibi��o na tela segundo o formato informado.
	 * 
	 * @param dateTime
	 * @return data formatada como String de acordo com o formato
	 */
	public static String formatDate(String dateTime, String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false);

		if (dateTime == null || dateTime.isEmpty()){
			return "-";
		}
		
		//Retira a informa��o do time zone antes do parsing
		String dateString = dateTime.substring(0, 19);

		Date d;
		try {
			d = sdf.parse(dateString);
		} catch (ParseException e) {
			return "-";
		}
		
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, LOCALE_PT_BR);
		return df.format(d);
	}

	/**
	 * Calcula em que dia cai o dia da semana informado como par�metro.
	 * O metodo retorna sempre a data correspondente ao proximo dia da semana (o que vem ap�s o dia de hoje).
	 * Assim, se hoje � s�bado e o dia da semana passado como par�metro � s�bado, o metodo retorna
	 * a data relativa ao proximo sabado.<br>
	 * <br>
	 * Exemplos:<br>
	 * - se o dia da semana informado � s�bado e hoje � quinta, 19, o metodo retorna 21..<br>
	 * - se o dia da semana informado � s�bado e hoje � s�bado, 7, retorna 14. 
	 * 
	 * @param diaDaSemanaAsInteger Dia da semana para o qual sera calculada a data
	 * @return objeto Date representando a data do dia da semana
	 */
	public static Date calculateDateOfNextDayOfWeek(int diaDaSemanaAsInteger) {
		Calendar c = new GregorianCalendar(LOCALE_PT_BR);
		c.setTime(new Date());
		
		if (c.get(Calendar.DAY_OF_WEEK) == diaDaSemanaAsInteger) {
//			System.out.println("hoje igual a data desejada");
			c.add(Calendar.DAY_OF_MONTH, 7);
			return c.getTime();
		} else if (c.get(Calendar.DAY_OF_WEEK) < diaDaSemanaAsInteger) {
//			System.out.println("hoje menor que data desejada");
			int diff = diaDaSemanaAsInteger - c.get(Calendar.DAY_OF_WEEK);
			c.add(Calendar.DAY_OF_MONTH, diff);
			return c.getTime();
		} else {
//			System.out.println("hoje maior que data desejada");
			int diff = c.get(Calendar.DAY_OF_WEEK) - diaDaSemanaAsInteger;
			c.add(Calendar.DAY_OF_MONTH, 7-diff);
			return c.getTime();
		}
	}

	public static void main(String[] args) {

		Calendar c = Calendar.getInstance(LOCALE_PT_BR);
		c.setTime(new Date());
		
		System.out.println( c.get(Calendar.DAY_OF_WEEK) );

		Date dateProximaSexta = DateUtil.calculateDateOfNextDayOfWeek(DiaDaSemana.SEXTA.getId());
		
		DateFormat df = DateFormat.getDateInstance(DateFormat.DEFAULT, LOCALE_PT_BR);
		System.out.println(df.format(dateProximaSexta));
	}

}
