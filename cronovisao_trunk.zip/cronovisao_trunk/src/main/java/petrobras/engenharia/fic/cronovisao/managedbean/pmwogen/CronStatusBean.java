package petrobras.engenharia.fic.cronovisao.managedbean.pmwogen;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.helper.AgendaHelper;
import petrobras.engenharia.fic.cronovisao.model.Dia;
import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryQuery;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryQuery.CronHistoryQueryBuilder;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;
import petrobras.engenharia.fic.cronovisao.service.jaxb.PreservQueryResponse;
import petrobras.engenharia.fic.cronovisao.service.scheduler.PreservQuery;
import petrobras.engenharia.fic.cronovisao.service.scheduler.PreservServiceDelegate;
import petrobras.engenharia.fic.cronovisao.util.DateUtil;
import petrobras.engenharia.fic.cronovisao.util.ScheduleUtil;

@ViewScoped
@ManagedBean
public class CronStatusBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static Configuracao config = Configuracao.getInstance();
	
	private static final Logger logger = Logger.getLogger(CronStatusBean.class);
	
	private DataTable dataTable;

	private DiaDaSemana diaSelecionado;
	
	private AgendaBean agendaBean;
	
	private IServiceDelegate<CronTaskHistory, String> cronServiceDelegate;
	
//	private IServiceDelegate<PreservQueryResponse, String> preservServiceDelegate = new FakePreservServiceDelegate();
	private IServiceDelegate<PreservQueryResponse, String> preservServiceDelegate = new PreservServiceDelegate();
	
	private List<CronTaskHistory> cronTaskList;
	
	private List<CronTaskInstance> cronInstances;
	
	private String cronInstanceSelecionada;
	
	public CronStatusBean() {
	}

	@PostConstruct
	public void init() {
		this.cronServiceDelegate = new CronHistoryService();
//		serviceDelegate = new MockCronHistServiceDelegate();
		
		FacesContext context = FacesContext.getCurrentInstance();
		Application app = context.getApplication();
		this.agendaBean = app.evaluateExpressionGet(context, "#{agendaBean}", AgendaBean.class);
		
		Calendar calendar = Calendar.getInstance(DateUtil.LOCALE_PT_BR);
		calendar.setTime(new Date());
		this.diaSelecionado = DiaDaSemana.valueOf(calendar.get(Calendar.DAY_OF_WEEK));
		
		List<Dia> agenda = this.agendaBean.getProgramacaoSemanal();
		this.cronInstances = AgendaHelper.listaCronTasksAtivasDoDia(agenda, this.diaSelecionado); 
	}
	
	public void carregarLista() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> carregarLista()");
			logger.debug(">>>>>>>>>>>>>>>>> dia="+this.diaSelecionado);
			logger.debug(">>>>>>>>>>>>>>>>> cronInstanceSelecionada="+this.cronInstanceSelecionada);
		}
		
		this.dataTable.setValueExpression("sortBy", null);
		
		this.cronTaskList = null;
		
		if (this.cronInstances != null && !this.cronInstances.isEmpty()) {
			
			CronHistoryQueryBuilder queryBuilder = new CronHistoryQueryBuilder()
														.setCronTaskName(config.getPmwogenCrontaskname());
			
			if (this.cronInstanceSelecionada != null) {
				queryBuilder.setInstanceName(this.cronInstanceSelecionada);
			} else {
				queryBuilder.setCronInstances(this.cronInstances);
			}
	
			CronHistoryQuery query = queryBuilder.build();
			
			Set<CronTaskHistory> cronTaskHistorySet = this.cronServiceDelegate.processMessage(query.getXml());
			
			/*
			 * para cada cronTaskHistory:
			 *    procura qual o cronTaskInstance dele (instancename tem que bater)
			 *    copia o empreendimento do cronTaskInstance para cronTaskHistory
			 *    busca a quantidade de preservacoes a processar (uma chamada HTTP para cada cronTaskHistory) 
			 */
			for (CronTaskHistory cronHistory : cronTaskHistorySet) {
				
				CronTaskInstance cronInstanceSearch = new CronTaskInstance();
				cronInstanceSearch.setCrontaskname(cronHistory.getCrontaskname());
				cronInstanceSearch.setInstancename(cronHistory.getInstancename());
				
				int index = Collections.binarySearch(this.cronInstances, cronInstanceSearch);
				if ( index >= 0) {
					CronTaskInstance cronInstance = this.cronInstances.get(index);
					String empreendimento = cronInstance.getEmpreendimento();
					cronHistory.setEmpreendimento(empreendimento);
				
					//busca a quantidade de preservacoes a processar
					Integer numPreservacoesProcessar = getNumPreservacoesProcessar(cronInstance);
					cronHistory.setNumPreservacoesProcessar(numPreservacoesProcessar);
				}
			}
			
			cronTaskList = new ArrayList<CronTaskHistory>();
			cronTaskList.addAll(cronTaskHistorySet);
		}
	}
	
	/**
	 * Dada a cron, chama o servi�o HTTP para buscar a quantidade de 
	 * preservacoes a processar.
	 * 
	 * @param cron objeto CronTaskInstance
	 */
	private Integer getNumPreservacoesProcessar(CronTaskInstance cron) {
		
		String dateStr = "(sysdate+%d)";
		int delta = 0;
		if (ScheduleUtil.isFrequenciaSemanal(cron.getSchedule())) {
			delta = 6;
		} else if (ScheduleUtil.isFrequenciaQuinzenal(cron.getSchedule())) {
			delta = 13;
		}
		
		PreservQuery query = new PreservQuery(cron.getEmpreendimento(), String.format(dateStr, delta));
		
		Set<PreservQueryResponse> resultSet = this.preservServiceDelegate.processMessage(query.getXml());
		if (resultSet != null && !resultSet.isEmpty()) {
			PreservQueryResponse preservQueryResponse = resultSet.iterator().next();
			return Integer.valueOf(preservQueryResponse.getNumRecords());
		}
		return 0;
	}

	
	public DiaDaSemana getDiaSelecionado() {
		return this.diaSelecionado;
	}

	public void setDiaSelecionado(DiaDaSemana d) {
		this.diaSelecionado = d;
	}
	
	public List<CronTaskHistory> getCronTaskList() {
		return cronTaskList;
	}

	public List<CronTaskInstance> getCronInstances() {
		return cronInstances;
	}

	public Integer getCronTaskListSize() {
		Integer qtd = 0;

		if (cronTaskList != null) {
			qtd = cronTaskList.size();
		}
		
		return qtd;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}

	public String getCronInstanceSelecionada() {
		return cronInstanceSelecionada;
	}

	public void setCronInstanceSelecionada(String cronInstanceSelecionada) {
		this.cronInstanceSelecionada = cronInstanceSelecionada;
	}
	
}
