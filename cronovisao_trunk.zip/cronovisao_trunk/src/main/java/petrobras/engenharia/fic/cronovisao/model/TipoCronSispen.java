package petrobras.engenharia.fic.cronovisao.model;

public enum TipoCronSispen {

	CCM("FIC_CCM"),
	TAP("FIC_TAPPENDIMPED"),
	TAP2("FIC_TAP2PENDIMPED"),
	TTAS("FIC_TTAS"),
	TTI("FIC_TTI");
	
	private String internalValue;
	
	TipoCronSispen(String internalValue) {
		this.internalValue = internalValue;
	}

	public String getInternalValue() {
		return internalValue;
	}
}
