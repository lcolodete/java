package petrobras.engenharia.fic.cronovisao.managedbean.sispen;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.model.Empreendimento;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.croninstance.CronInstanceQuery;
import petrobras.engenharia.fic.cronovisao.service.croninstance.CronInstanceService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ManagedBean
@SessionScoped
public class SispenAgendaBean {

	private static final long serialVersionUID = 1L;
	
	private static Configuracao config = Configuracao.getInstance();
	
	private static final Logger logger = Logger.getLogger(SispenAgendaBean.class);
	
	private DataTable dataTable;

	private IServiceDelegate<CronTaskInstance, String> cronInstanceService = new CronInstanceService();
	
	private List<CronTaskInstance> cronTaskList;
	
	private Map<String, Empreendimento> siteMap;
	
	public SispenAgendaBean() {
	}

	
	@PostConstruct
	public void init() {
		this.carregarLista();
	}

	
	public void atualizarAgenda() {
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> atualizarAgenda()");
		}
		
		this.dataTable.setValueExpression("sortBy", null);
		this.carregarLista();
	}
	
	private void carregarLista() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> carregarLista()");
		}
			
		this.cronTaskList = null;
		this.siteMap = new HashMap<String, Empreendimento>();
		
		CronInstanceQuery cronInstanceQuery = new CronInstanceQuery( String.format("crontaskname='%s' and active='1'", config.getSispenCrontaskname()) );
		
		Set<CronTaskInstance> cronInstances = cronInstanceService.processMessage(cronInstanceQuery.getXml());
		
		if (cronInstances != null && cronInstances.size() > 0) {
			for (CronTaskInstance cron : cronInstances) {
				
				String siteId = cron.getParam("EMPREENDIMENTO");
				if (siteId == null || siteId.isEmpty()) {
					siteId = ">> VALOR N�O DEFINIDO <<";
				}
				cron.setEmpreendimento(siteId);

				Empreendimento emp = this.siteMap.get(siteId);
				if (emp == null) {
					emp = new Empreendimento(siteId);
					this.siteMap.put(siteId, emp);
				}
				emp.add(cron);
			}

			this.cronTaskList = new ArrayList<CronTaskInstance>(cronInstances);
		}
	}
	
	public List<CronTaskInstance> getCronTaskList() {
		return cronTaskList;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}

	public List<Empreendimento> getEmpreendimentos() {
		List<Empreendimento> empList = new ArrayList<Empreendimento>(this.siteMap.values());
		Collections.sort(empList);
		return empList;
	}
	
}
