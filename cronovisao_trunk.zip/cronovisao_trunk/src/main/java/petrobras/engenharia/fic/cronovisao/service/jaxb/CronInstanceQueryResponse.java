package petrobras.engenharia.fic.cronovisao.service.jaxb;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QueryMXCRONINSTANCEResponse")
public class CronInstanceQueryResponse {

/*
<?xml version="1.0" encoding="UTF-8"?>
<QueryMXCRONINSTANCEResponse 
    xmlns="http://www.ibm.com/maximo" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" creationDateTime="2013-09-30T11:52:45-03:00" transLanguage="PT" baseLanguage="PT" messageID="1380552765848510365" maximoVersion="7 1 20120709-1611 V71111-19" rsStart="0" rsCount="1" rsTotal="1">
    <MXCRONINSTANCESet>
        <CRONTASKINSTANCE>
            <ACTIVE>1</ACTIVE>
            <AUTOREMOVAL>0</AUTOREMOVAL>
            <CRONTASKINSTANCEID>1101</CRONTASKINSTANCEID>
            <CRONTASKNAME>PMWoGenCronTask</CRONTASKNAME>
            <DESCRIPTION>Tarefa Cron de PmWogen</DESCRIPTION>
            <INSTANCENAME>CMTL</INSTANCENAME>
            <KEEPHISTORY>1</KEEPHISTORY>
            <MAXHISTORY>1000</MAXHISTORY>
            <NEXTRUNTMOVERWRITE xsi:nil="true"></NEXTRUNTMOVERWRITE>
            <RELOADREQTIME>2013-04-19T12:39:24-03:00</RELOADREQTIME>
            <RUNASUSERID>FICCRONCMTL</RUNASUSERID>
            <SCHEDULE>1w,0,0,2,*,*,*,6,*,*</SCHEDULE>
            <MAXUSER>
                <DEFSITE>CMTL</DEFSITE>
                <LOGINID>FICCRONCMTL</LOGINID>
                <MAXUSERID>364</MAXUSERID>
                <USERID>FICCRONCMTL</USERID>
            </MAXUSER>
        </CRONTASKINSTANCE>
    </MXCRONINSTANCESet>
</QueryMXCRONINSTANCEResponse>
*/
	
	private List<CronTaskInstance> cronInstances;

	@XmlElementWrapper(name="MXCRONINSTANCESet")
	@XmlElements({
		@XmlElement(name="CRONTASKINSTANCE")
	})
	public List<CronTaskInstance> getCronInstances() {
		return cronInstances;
	}

	public void setCronInstances(List<CronTaskInstance> cronInstances) {
		this.cronInstances = cronInstances;
	}
	
	
	
}
