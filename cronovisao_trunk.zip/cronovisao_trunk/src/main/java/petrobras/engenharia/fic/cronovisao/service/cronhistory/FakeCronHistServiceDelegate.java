package petrobras.engenharia.fic.cronovisao.service.cronhistory;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringEscapeUtils;

import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;

public class FakeCronHistServiceDelegate implements IServiceDelegate<CronTaskHistory, String> {

	private static final long serialVersionUID = 1L;

	@Override
	public Set<CronTaskHistory> processMessage(String query) {
		
		CronTaskHistory cronTaskHist = new CronTaskHistory();
		cronTaskHist.setActivity("ACTION");
		cronTaskHist.setCrontaskhistoryid("6093288");
		cronTaskHist.setCrontaskname("PMWoGenCronTask");
		cronTaskHist.setEndtime("2012-04-20T02:32:26-03:00");
		cronTaskHist.setInstancename("CMTL");
		cronTaskHist.setRuntimeerror("");
		cronTaskHist.setSequence("231");
		cronTaskHist.setServerhost("10.152.47.5");
		cronTaskHist.setServername("MXServerESC1");
		cronTaskHist.setStarttime("2012-04-20T02:01:13-03:00");
		
		CronTaskHistory cronTaskHist2 = new CronTaskHistory();
		cronTaskHist2.setActivity("ACTION");
		cronTaskHist2.setCrontaskhistoryid("1234567");
		cronTaskHist2.setCrontaskname("PMWoGenCronTask");
		cronTaskHist2.setEndtime("2012-05-20T03:32:26-03:00");
		cronTaskHist2.setInstancename("COMPERJ-XYZ");
		cronTaskHist2.setRuntimeerror("");
		cronTaskHist2.setSequence("987");
		cronTaskHist2.setServerhost("10.152.47.7");
		cronTaskHist2.setServername("MXServerESC3");
		cronTaskHist2.setStarttime("2012-05-20T03:01:13-03:00");

		Set<CronTaskHistory> cronTaskSet = new HashSet<CronTaskHistory>();
		cronTaskSet.add(cronTaskHist);
		cronTaskSet.add(cronTaskHist2);

		return cronTaskSet;
	}
	
	public static void main(String[] args) {
		
		String str = "ENG-E&P/IEUEP-II/IEICO-II";
		String srtEscaped = StringEscapeUtils.escapeXml(str);
		
		System.out.println("str=["+str+"]");
		System.out.println( "escaped=["+ srtEscaped +"]");
		System.out.println( "unescaped=["+StringEscapeUtils.unescapeXml(srtEscaped) +"]");
	}

}
