package petrobras.engenharia.fic.cronovisao.model;

import java.util.Calendar;

/**
 * Representa o dia da semana dentro do campo schedule do objeto CronTaskInstance.
 * 
 * @author ur5g
 *
 */
public enum DiaDaSemana {
	DOMINGO(Calendar.SUNDAY),
	SEGUNDA(Calendar.MONDAY),
	TERCA(Calendar.TUESDAY),
	QUARTA(Calendar.WEDNESDAY),
	QUINTA(Calendar.THURSDAY),
	SEXTA(Calendar.FRIDAY),
	SABADO(Calendar.SATURDAY);

	DiaDaSemana(Integer id) {
		this.id = id;
	}

	/**
	 * Identificador do dia da semana dentro do campo schedule.
	 */
	private Integer id;
	
	@Override
	public String toString() {

		String str = "";
		
		switch(this) {
			case DOMINGO:
			case SEGUNDA:
			case QUARTA:
			case QUINTA:
			case SEXTA:
				str = capitalizeName(this);
				break;
			case TERCA:
				str = "Ter�a";
				break;
			case SABADO:
				str = "S�bado";
				break;
		}
		
		return str;
	}

	private String capitalizeName(DiaDaSemana dia) {
		String nameLowerCase = dia.name().toLowerCase();
		
		char firstLetterChar = nameLowerCase.charAt(0);
		String firstLetterStr = firstLetterChar + "";

		String capitalizedString = firstLetterStr.toUpperCase() + nameLowerCase.substring(1);
		
		return capitalizedString;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public static DiaDaSemana valueOf(int i) {
		DiaDaSemana dia = null;
		switch(i) {
			case Calendar.SUNDAY:
				dia = DiaDaSemana.DOMINGO;
				break;
			case Calendar.MONDAY:
				dia = DiaDaSemana.SEGUNDA;
				break;
			case Calendar.TUESDAY:
				dia = DiaDaSemana.TERCA;
				break;
			case Calendar.WEDNESDAY:
				dia = DiaDaSemana.QUARTA;
				break;
			case Calendar.THURSDAY:
				dia = DiaDaSemana.QUINTA;
				break;
			case Calendar.FRIDAY:
				dia = DiaDaSemana.SEXTA;
				break;
			case Calendar.SATURDAY:
				dia = DiaDaSemana.SABADO;
				break;
		}
		return dia;
	}
}
