package petrobras.engenharia.fic.cronovisao.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * Servlet Filter utilizado como solu��o alternativa para o tratamento de 
 * <code>ViewExpiredException</code>.
 *  
 * @author e18k
 */
public class SessionTimeoutFilter implements Filter {
	private static final Logger LOG = LogManager.getLogger(SessionTimeoutFilter.class);

	private String timeoutPage = "error-pages/timeout.xhtml";
	
	public String getTimeoutPage() {
		return timeoutPage;
	}

	public void setTimeoutPage(String timeout_page) {
		timeoutPage = timeout_page;
	}

	public void destroy() {
		LOG.info("destroy");
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		if ((request instanceof HttpServletRequest)
				&& (response instanceof HttpServletResponse)) {
			HttpServletRequest httpReq = (HttpServletRequest) request;
			HttpServletResponse httpResp = (HttpServletResponse) response;

			// is session expire control required for this request?
			if (isSessionControlRequiredForThisResource(httpReq)) {

				// is session invalid?
				if (isSessionInvalid(httpReq)) {
					String timeoutUrl = httpResp.encodeRedirectURL(
							httpReq.getContextPath() + "/" + getTimeoutPage());
					LOG.info("session is invalid! redirecting to timeoutpage : " + timeoutUrl);

					httpResp.sendRedirect(timeoutUrl);
					return;
				}
			}
		}
		filterChain.doFilter(request, response);
	}

	public void init(FilterConfig arg0) throws ServletException {
		LOG.info("init");
	}

	/**
	 * 
	 * session shouldn't be checked for some pages. For example: for timeout
	 * page.. Since we're redirecting to timeout page from this filter, if we
	 * don't disable session control for it, filter will again redirect to it
	 * and this will be result with an infinite loop...
	 */
	protected boolean isSessionControlRequiredForThisResource(
			HttpServletRequest httpServletRequest) {
		String requestPath = httpServletRequest.getRequestURI();

		boolean controlRequired = !requestPath.contains(getTimeoutPage());

		return controlRequired;
	}

	private boolean isSessionInvalid(HttpServletRequest httpServletRequest) {
		boolean sessionInValid = (httpServletRequest.getRequestedSessionId() != null)
				&& !httpServletRequest.isRequestedSessionIdValid();
		return sessionInValid;
	}

}
