package petrobras.engenharia.fic.cronovisao.config;

import java.io.Serializable;
import java.util.MissingResourceException;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Configuracao implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//app.properties
	private static final String CODIGO_EXTERNALIZACAO = "CODIGO_EXTERNALIZACAO";
	private static final String MOS_ESCALATION = "MOS_ESCALATION";
	private static final String MOS_CRONTASKINSTANCE = "MOS_CRONTASKINSTANCE";
	private static final String MOS_CRONTASKHISTORY = "MOS_CRONTASKHISTORY";
	private static final String MOS_PRESERV = "MOS_PRESERV";

	//config.properties (por ambiente)
	private static final String LOG4J_PATH = "log4jpath";
	private static final String USUARIO = "USUARIO";
	private static final String SENHA = "SENHA";
	private static final String URI_BASE_SERVICO = "URI_BASE_SERVICO";
	private static final String URL_LOGS = "URL_LOGS";
	private static final String URL_LOGS_CRON = "URL_LOGS_CRON";
	private static final String PMWOGEN_CRONTASKNAME = "PMWOGEN_CRONTASKNAME";
	private static final String SISPEN_CRONTASKNAME = "SISPEN_CRONTASKNAME";
	private static final String LOG_MXServerESC = "LOG_MXServerESC";
	private static final String LOG_MXServerESC1 = "LOG_MXServerESC1";
	private static final String LOG_MXServerBIRT1 = "LOG_MXServerBIRT1";
	private static final String LOG_MXServerBIRT = "LOG_MXServerBIRT";
	private static final String DATASOURCE_NAME = "DATASOURCE_NAME";
	
	
	private static final Logger LOGGER = LogManager.getLogger(Configuracao.class);
	
	private static Configuracao config;
	
	private Properties properties;
	
	private Configuracao() {
		this.properties = new Properties();
	}
	
	public static synchronized Configuracao getInstance() {
		if (config == null) {
			config = new Configuracao();
		}
		return config;
	}
	
	public void loadProperties(String propertiesFile) {
    	try {
            this.properties.load(Configuracao.getInstance().getClass().getResourceAsStream(propertiesFile));
        } catch (Exception e) {
           	LOGGER.error(e, e);
        }
	}
	
    /**
     * Retorna o valor de uma propriedade do arquivo de configura��o
     * 
     * @param property nome da propriedade
     * @return String Valor da propriedade
     */
    private String getProperty(String property) {
        String retorno = null;
        
        try {
            retorno = this.properties.getProperty(property);
            if (retorno == null) {
            	String msg = "propriedade [" + property + "] n�o configurada";
             	throw new IllegalArgumentException(msg);
            }
				
        }
        catch (MissingResourceException e) {
            LOGGER.error(e, e);
        }
        
        return retorno; 
    }
    
    public String getCodigoExternalizacao() {
    	return getProperty(CODIGO_EXTERNALIZACAO);
    }
    
    public String getMosEscalation() {
    	return getProperty(MOS_ESCALATION);
    }
    
    public String getMosCronTaskInstance() {
    	return getProperty(MOS_CRONTASKINSTANCE);
    }
    
    public String getMosCronTaskHistory() {
    	return getProperty(MOS_CRONTASKHISTORY);
    }
    
    public String getMosPreserv() {
    	return getProperty(MOS_PRESERV);
    }
    
    public String getLog4JPath() {
    	return getProperty(LOG4J_PATH);
    }
    
    public String getUsuario() {
    	return getProperty(USUARIO);
    }
    
    public String getSenha() {
    	return getProperty(SENHA);
    }
    
    public String getUriBaseServico() {
    	return getProperty(URI_BASE_SERVICO);
    }
    
    public String getUrlLogs() {
    	return getProperty(URL_LOGS);
    }
    
    public String getUrlLogsCron() {
    	return getProperty(URL_LOGS_CRON);
    }

    public String getPmwogenCrontaskname() {
    	return getProperty(PMWOGEN_CRONTASKNAME);
    }
    
	public String getSispenCrontaskname() {
		return getProperty(SISPEN_CRONTASKNAME);
	}

	public String getLogMXServerESC() {
		return getProperty(LOG_MXServerESC);
	}
	
	public String getLogMXServerESC1() {
		return getProperty(LOG_MXServerESC1);
	}
	
	public String getLogMXServerBIRT1() {
		return getProperty(LOG_MXServerBIRT1);
	}
	
	public String getLogMXServerBIRT() {
		return getProperty(LOG_MXServerBIRT);
	}
	
	public String getJvmLogUri(String jvmName) {
		
		StringBuilder sb = new StringBuilder();
		sb.append( getUrlLogs() );
		
		String logServerName = "LOG_"+jvmName;
		if (Configuracao.LOG_MXServerESC.equals(logServerName)) {
			sb.append(getLogMXServerESC());
		} else if (Configuracao.LOG_MXServerESC1.equals(logServerName)) {
			sb.append(getLogMXServerESC1());
		} else if (Configuracao.LOG_MXServerBIRT1.equals(logServerName)) {
			sb.append(getLogMXServerBIRT1());
		} else if ( Configuracao.LOG_MXServerBIRT.equals(logServerName) ) {
			sb.append(getLogMXServerBIRT());
		}
		
		return sb.toString();
	}
	
	public String getDataSourceName() {
		return getProperty(DATASOURCE_NAME);
	}
}
