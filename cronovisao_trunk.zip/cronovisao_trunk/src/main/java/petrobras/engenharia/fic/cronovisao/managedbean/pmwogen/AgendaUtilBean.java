package petrobras.engenharia.fic.cronovisao.managedbean.pmwogen;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import petrobras.engenharia.fic.cronovisao.util.ScheduleFormat;

@SessionScoped
@ManagedBean
public class AgendaUtilBean implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Formata o campo schedule para exibi��o em tela, 
	 * em um formato mais amig�vel para o usu�rio. 
	 * 
	 * @param schedule
	 * @return
	 */
	public String formatSchedule(String schedule) {
		ScheduleFormat sf = ScheduleFormat.getInstance(schedule);
		String formattedStr = sf.format();
		return formattedStr;
	}
	
	public String formatFrequencia(String schedule) {
		ScheduleFormat sf = ScheduleFormat.getInstance(schedule);
		String formattedStr = sf.formatFrequenciaPrincipal();
		return formattedStr;
	}
	
}
