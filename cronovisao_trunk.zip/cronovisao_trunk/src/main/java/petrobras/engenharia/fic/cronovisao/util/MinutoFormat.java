package petrobras.engenharia.fic.cronovisao.util;

public class MinutoFormat extends ScheduleFormat {

	protected MinutoFormat(String schedule) {
		super(schedule);
		this.textoFrequenciaPrincipal = "minuto";
	}

	@Override
	public String formatHora() {
		return "N/A";
	}
	
	/**
	 * Exemplo de campo schedule: <code>35m,*,*,*,*,*,*,*,*,*</code>
	 * <br/>
	 * <br/>
	 * <code>
	 * 35m, -> A cada 35 minutos<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *    -> Nao usado
	 * </code>
	 * 
	 */
	@Override
	public String format() {
		String formattedStr = "";
		
		formattedStr = formatFrequenciaPrincipal();
		
		return formattedStr;
	}

}
