package petrobras.engenharia.fic.cronovisao.managedbean.sispen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryQuery;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryService;
import petrobras.engenharia.fic.cronovisao.service.croninstance.CronInstanceQuery;
import petrobras.engenharia.fic.cronovisao.service.croninstance.CronInstanceService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ManagedBean
@ViewScoped
public class SispenHistFiltroInstanciaBean {

	private static final long serialVersionUID = 1L;
	
	private static Configuracao config = Configuracao.getInstance();
	
	private static final Logger logger = Logger.getLogger(SispenHistFiltroInstanciaBean.class);
	
	private DataTable dataTable;

	private IServiceDelegate<CronTaskHistory, String> cronHistoryService = new CronHistoryService();
	
	private IServiceDelegate<CronTaskInstance, String> cronInstanceService = new CronInstanceService();
	
	private List<CronTaskHistory> cronTaskList;
	
	private Map<String, String> cronsAndSites;

	private String txtInstanceName;
	
	public SispenHistFiltroInstanciaBean() {
	}

	public void filtrar() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> filtrar()");
			logger.debug(">>>>>>>>>>>>>>>>> instanceName=["+txtInstanceName+"]");
		}
		
		this.dataTable.setValueExpression("sortBy", null);
		
		this.cronTaskList = null;
		
		this.cronsAndSites = new HashMap<String, String>();

		StringBuilder predicateStr = new StringBuilder( String.format("crontaskname='%s' and active='1'", config.getSispenCrontaskname()) );
		
		if ( txtInstanceName != null && !txtInstanceName.isEmpty() ) {
			predicateStr.append( String.format(" and lower(instancename) like '%%%s%%'", txtInstanceName.toLowerCase()) );
		}
		
		CronInstanceQuery cronInstanceQuery = new CronInstanceQuery( predicateStr.toString() );
		
		Set<CronTaskInstance> cronInstances = cronInstanceService.processMessage(cronInstanceQuery.getXml());
		
		for (CronTaskInstance cron : cronInstances) {
			cronsAndSites.put(cron.getInstancename(), cron.getParam("EMPREENDIMENTO"));
		}
		
		if (cronInstances != null && cronInstances.size() > 0) {
			
			CronHistoryQuery query = new CronHistoryQuery.CronHistoryQueryBuilder()
										.setCronTaskName(config.getSispenCrontaskname())
										.setCronInstances(new ArrayList<CronTaskInstance>(cronInstances))
										.build();
			
			Set<CronTaskHistory> cronTaskHistorySet = this.cronHistoryService.processMessage(query.getXml());
			
			for (CronTaskHistory cronHistory : cronTaskHistorySet) {
				cronHistory.setEmpreendimento(cronsAndSites.get(cronHistory.getInstancename()));
			}
			
			this.cronTaskList = new ArrayList<CronTaskHistory>(cronTaskHistorySet);
		}
	
	}
	
	public List<CronTaskHistory> getCronTaskList() {
		return cronTaskList;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}

	public String getTxtInstanceName() {
		return txtInstanceName;
	}

	public void setTxtInstanceName(String txtInstanceName) {
		this.txtInstanceName = txtInstanceName;
	}

}
