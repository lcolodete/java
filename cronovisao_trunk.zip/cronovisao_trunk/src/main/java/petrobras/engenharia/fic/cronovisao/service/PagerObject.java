package petrobras.engenharia.fic.cronovisao.service;

public class PagerObject {

	private Integer first;
	private Integer pageSize;
	
	public PagerObject(Integer first, Integer pageSize) {
		this.first = first;
		this.pageSize = pageSize;
	}

	public Integer getFirst() {
		return first;
	}

	public void setFirst(Integer first) {
		this.first = first;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	
}
