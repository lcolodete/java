package petrobras.engenharia.fic.cronovisao.service.escalation;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.service.AbstractHttpClient;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.Escalation;
import petrobras.engenharia.fic.cronovisao.service.jaxb.EscalationQueryResponse;

public class EscalationService extends AbstractHttpClient implements IServiceDelegate<Escalation, String> {

	private static final Logger logger = LogManager.getLogger(EscalationService.class);
	
	private static final long serialVersionUID = 1L;

	public EscalationService() {
		super("MXESCALATION");
	}

	@Override
	public Set<Escalation> processMessage(String query) {
		if (query == null || query.isEmpty()) {
			return null;
		}
		
		EscalationQueryResponse escalationQueryResponse = getBuilder().post(EscalationQueryResponse.class, query);

		List<Escalation> escalations = escalationQueryResponse.getEscalations();

		if (logger.isDebugEnabled() && !escalations.isEmpty()) {
			for (Escalation esc : escalations) {
				
				logger.debug(">>>>> Escalation: " + esc.getEscalation());
				logger.debug("escalation.active="+esc.getActive());
				logger.debug("escalation.instancename="+esc.getInstancename());
				logger.debug("escalation.lastrun="+esc.getLastrun());
				logger.debug("escalation.objectname="+esc.getObjectname());
				logger.debug("escalation.schedule="+esc.getSchedule());
			}
		}
		
		Set<Escalation> escalationSet = new TreeSet<Escalation>();
		escalationSet.addAll(escalations);

		return escalationSet;
	}

}
