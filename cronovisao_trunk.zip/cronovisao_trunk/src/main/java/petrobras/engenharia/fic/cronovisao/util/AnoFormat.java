package petrobras.engenharia.fic.cronovisao.util;

import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;

public class AnoFormat extends ScheduleFormat {

	protected AnoFormat(String schedule) {
		super(schedule);
		this.textoFrequenciaPrincipal = "ano";
	}

	/**
	 * Exemplo de campo schedule: <code>1y,0,0,14,5,1,*,*,*,*</code>
	 * <br/>
	 * <br/>
	 * <code>
	 * 1y,  -> A cada 1 ano<br/>
	 * 0,   -> Segundo<br/>
	 * 0,   -> Minuto<br/>
	 * 14,  -> Hora: �s 14h<br/>
	 * 5,   -> Dia do mes: No dia 05<br/>
	 * 1,   -> Mes: Fevereiro (Janeiro=0, ..., Dezembro=11)<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *    -> Nao usado
	 * </code>
	 * 
	 * <br/>
	 * <br/>
	 * Outro exemplo: <code>1y,0,0,9,*,*,*,7,0,*</code>
	 * <br/>
	 * <br/>
	 * <code>
	 * 1y,  -> A cada 1 ano<br/>
	 * 0,   -> Segundo<br/>
	 * 0,   -> Minuto<br/>
	 * 9,   -> Hora: �s 9h<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * 7,   -> Dia da semana: Sabado (Domingo=1, ..., Sabado=7)<br/>
	 * 0,   -> Primeiro ou �ltimo: Primeiro=0, �ltimo=1<br/>
	 * *    -> Nao usado
	 * </code>
	 */
	@Override
	public String format() {
		String formattedStr = "";
		
		//PARTE 1: Frequencia
		
		StringBuilder formattedSb = new StringBuilder();
		String frequenciaPrincipal = formatFrequenciaPrincipal();
		
		//PARTE 2: Dia
		// Sao duas possibilidades (XOR):
		// a) Mes + dia do mes OU
		// b) Dia da semana + (Primeiro ou Ultimo do ano)
		
		StringBuilder diaSb = new StringBuilder();
		
		String[] scheduleTokens = this.schedule.split(",");
		String diaDoMes = scheduleTokens[4];
		
		if (!"*".equals(diaDoMes)) {
			//Op��o a
			String mes = scheduleTokens[5];
			
			diaSb.append(". No dia ")
				 .append(diaDoMes)
				 .append(" de ")
				 .append(ScheduleFormat.MESES[Integer.parseInt(mes)]);
		} else {
			//Op��o b
			String diaDaSemana = scheduleTokens[7];
			String primeiroUltimo = scheduleTokens[8];
			
			diaSb.append(". No ");
			if (primeiroUltimo.equals(ScheduleFormat.PRIMEIRO)) {
				diaSb.append("primeiro ");
			} else {
				diaSb.append("�ltimo ");
			}
			
			//a partir do inteiro que representa o dia da semana, descobre qual o enum correspondente
			for (DiaDaSemana diaEnum : DiaDaSemana.values()) {
				if (diaEnum.getId().equals(Integer.valueOf(diaDaSemana))) {
					diaSb.append(diaEnum.toString())
						 .append(" do ano");
					break;
				}
			}
			
		}


		//PARTE 3: Hor�rio

		String hora = formatHora();
		
		formattedStr = formattedSb.append(frequenciaPrincipal)
								  .append("<br/>")	// pula linha
								  .append(diaSb)
								  .append("<br/>")	// pula linha
								  .append(hora)
								  .toString();
		
		return formattedStr;
	}

}
