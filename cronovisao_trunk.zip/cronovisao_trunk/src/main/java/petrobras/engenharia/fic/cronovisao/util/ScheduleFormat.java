package petrobras.engenharia.fic.cronovisao.util;

/**
 * Classe respons�vel pelo parsing e formata��o do campo schedule
 * do objeto CronTaskInstance.
 * <br/>
 * Exemplo de campo schedule: <code>1w,0,0,3,*,*,*,6,*,*</code>
 * <br/>
 * <br/>
 * <code>
 * 1w, -> A cada 1 semana (i.e., de 7 em 7 dias)<br/>
 * 0,   -> segundos<br/>
 * 0,   -> minutos<br/>
 * 3,   -> horas<br/>
 * *,   -> Nao usado<br/>
 * *,   -> Nao usado<br/>
 * *,   -> Nao usado<br/>
 * 6,  -> Dia da semana<br/>
 * *,   -> Nao usado<br/>
 * *   -> Nao usado
 * </code>
 * 
 * @author UR5G
 *
 */
public abstract class ScheduleFormat {
	
	public static final Integer HORA_FIELD = 1;
	public static final Integer FREQUENCIA_FIELD = 2;

	public static final String SEGUNDO = "s";
	public static final String MINUTO = "m";
	public static final String HORA = "h";
	public static final String DIA = "d";
	public static final String SEMANA = "w";
	public static final String MES = "M";
	public static final String ANO = "y";

	public static final String PRIMEIRO = "0";
	public static final String ULTIMO = "1";
	
	//Janeiro=0, ..., Dezembro=11
	public static final String[] MESES = {"Janeiro", "Fevereiro", "Mar�o", "Abril", 
										  "Maio", "Junho", "Julho", "Agosto", 
										  "Setembro", "Outubro", "Novembro", "Dezembro"};
	
	protected String schedule;
	
	protected String textoFrequenciaPrincipal;
	
	protected ScheduleFormat(String schedule) {
		this.schedule = schedule;
	}
	
	public static ScheduleFormat getInstance(String schedule) {
		
		String[] scheduleTokens = schedule.split(",");
		
		String frequenciaPrincipal = scheduleTokens[0];
		
		// pega o �ltimo caracter da string frequenciaPrincipal
		String caracterFrequencia = ScheduleUtil.getCaracterFrequenciaPrincipal(frequenciaPrincipal);

		ScheduleFormat scheduleFormat = null;
		
		if (caracterFrequencia.equals(SEGUNDO)) {
			scheduleFormat = new SegundoFormat(schedule);
		} else if (caracterFrequencia.equals(MINUTO)) {
			scheduleFormat = new MinutoFormat(schedule);
		} else if (caracterFrequencia.equals(HORA)) {
			scheduleFormat = new HoraFormat(schedule);
		} else if (caracterFrequencia.equals(DIA)) {
			scheduleFormat = new DiaFormat(schedule);
		} else if (caracterFrequencia.equals(SEMANA)) {
			scheduleFormat = new SemanaFormat(schedule);
		} else if (caracterFrequencia.equals(MES)) {
			scheduleFormat = new MesFormat(schedule);
		} else if (caracterFrequencia.equals(ANO)) {
			scheduleFormat = new AnoFormat(schedule);
		} else {
			throw new IllegalArgumentException("Caracter de frequencia desconhecido: " + caracterFrequencia);
		}
		
		return scheduleFormat;
	}
	
	public abstract String format();

	/**
	 * Formata o hor�rio de execu��o para exibi��o em tela.
	 * <br/>
	 * <br/>
	 * Exemplo:<br/>
	 * schedule=<code>1w,0,0,3,*,*,*,6,*,*</code>
	 * <br/>
	 * <br/>
	 * O m�todo produz a seguinte String:
	 * <br/>
	 * <br/>
	 * <code>. �s 03:00</code>
	 * <br/>
	 * <br/>
	 * Regra geral do formato:
	 * <br/>
	 * <br/>
	 * <code>
	 * HH:mm:ss (omitir o ss se igual a 0)
	 * </code>
	 * 
	 * @return hor�rio de execu��o formatado
	 */
	public String formatHora() {
		
		String[] scheduleTokens = schedule.split(",");
		
		Integer segundo = Integer.valueOf(scheduleTokens[1]);
		Integer minuto = Integer.valueOf(scheduleTokens[2]);
		Integer hora = Integer.valueOf(scheduleTokens[3]);
		
		
		//faz o padLeft de zero na hora, no minuto e no segundo
		
		String segundoStr = "";
		if (segundo > 0) {
			segundoStr = ""+segundo;
			if (segundo < 10) {
				segundoStr = "0"+segundo;
			}
		}
		
		String minutoStr = ""+minuto;
		if (minuto < 10) {
			minutoStr = "0"+minuto;
		}
		
		String horaStr = ""+hora;
		if (hora < 10) {
			horaStr = "0"+hora;
		}
		
		StringBuilder textoHoraSb = new StringBuilder();
		textoHoraSb.append(horaStr)
				   .append(":")
				   .append(minutoStr);
		
		if (!segundoStr.isEmpty()) {
			textoHoraSb.append(":")
					   .append(segundoStr);
		}

		return textoHoraSb.toString();
	}
	
	/**
	 * Formata a frequencia principal para exibi��o em tela.
	 * <br/>
	 * <br/>
	 * Exemplo:<br/>
	 * schedule=<code>1w,0,0,3,*,*,*,6,*,*</code>
	 * <br/>
	 * <br/>
	 * O m�todo produz a seguinte String:
	 * <br/>
	 * <br/>
	 * <code>
	 * . A cada 1 semana<br/>
	 * </code>
	 * <br/>
	 * Regra geral do formato:
	 * <br/>
	 * <br/>
	 * <code>
	 * . A cada N textoFrequenciaPrincipal
	 * </code>
	 * <br/>
	 * <br/>
	 * Onde:
	 * <br/>
	 * - N � a frequencia<br/>
	 * - Se N > 1, insere s ao final (faz o plural)<br/>
	 * 
	 * @return String frequencia principal formatada
	 */
	public String formatFrequenciaPrincipal() {
		String[] scheduleTokens = schedule.split(",");
		
		String frequenciaPrincipal = scheduleTokens[0];
		
		Integer frequencia = ScheduleUtil.getNumFrequenciaPrincipal(frequenciaPrincipal);
		
		StringBuilder formattedSb = new StringBuilder();
		formattedSb.append(". A cada ")
				   .append(frequencia)
				   .append(" ")
				   .append(textoFrequenciaPrincipal);
		
		// pega o �ltimo caracter da string frequenciaPrincipal
		String caracterFrequencia = ScheduleUtil.getCaracterFrequenciaPrincipal(frequenciaPrincipal);

		if (frequencia > 1) {
			if (caracterFrequencia.equals(MES)) { // plural de mes � irregular, adicionar es (meses)
				formattedSb.append("es");
			} else {
				formattedSb.append("s");
			}
		}

		return formattedSb.toString();
	}
	
	public static void main(String[] args) {
		ScheduleFormat sf = ScheduleFormat.getInstance("1y,0,0,9,*,*,*,7,1,*");
		System.out.println(sf.format());
	}
}
