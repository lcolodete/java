package petrobras.engenharia.fic.cronovisao.service.cronhistory;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.AbstractHttpClient;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronHistoryQueryResponse;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;

public class CronHistoryService extends AbstractHttpClient implements IServiceDelegate<CronTaskHistory, String> {

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = LogManager.getLogger(CronHistoryService.class);
	
	private static Configuracao config = Configuracao.getInstance();
	
	public CronHistoryService() {
		super(config.getMosCronTaskHistory());
	}

	public Set<CronTaskHistory> processMessage(String query) {
		
		if (query == null || query.isEmpty()) {
			return null;
		}
		
		CronHistoryQueryResponse cronHistQueryResponse = getBuilder().post(CronHistoryQueryResponse.class, query);

		List<CronTaskHistory> cronHistoryList = cronHistQueryResponse.getCronTaskList();

		if (LOGGER.isDebugEnabled()) {
			for (CronTaskHistory cronTaskHist : cronHistoryList) {
				
				LOGGER.debug(">>>>> Cron Task Instance Name: "
						+ cronTaskHist.getInstancename());
				LOGGER.debug("cronTaskHist.sequence="
						+ cronTaskHist.getSequence());
				LOGGER.debug("cronTaskHist.activity="
						+ cronTaskHist.getActivity());
				LOGGER.debug("cronTaskHist.starttime="
						+ cronTaskHist.getStarttime());
				LOGGER.debug("cronTaskHist.endtime="
						+ cronTaskHist.getEndtime());
				LOGGER.debug("cronTaskHist.servername="
						+ cronTaskHist.getServername());
				LOGGER.debug("cronTaskHist.serverhost="
						+ cronTaskHist.getServerhost());
			}
		}
		

		Set<CronTaskHistory> cronHistorySet = new TreeSet<CronTaskHistory>();
		cronHistorySet.addAll(cronHistoryList);
		
		return cronHistorySet;

	}
}
