package petrobras.engenharia.fic.cronovisao.model;

import java.util.ArrayList;
import java.util.List;

import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

public class Empreendimento implements Comparable<Empreendimento> {

	private String siteId;
	
	private List<CronTaskInstance> sispenCronInstances = new ArrayList<CronTaskInstance>();

	public Empreendimento(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteId() {
		return siteId;
	}

	public List<CronTaskInstance> getSispenCronInstances() {
		return sispenCronInstances;
	}

	public void add(CronTaskInstance cron) {
		this.sispenCronInstances.add(cron);
	}
	
	@Override
	public int compareTo(Empreendimento emp) {
		return this.siteId.compareTo(emp.getSiteId());
	}
}
