package petrobras.engenharia.fic.cronovisao.service.croninstance;

import java.util.Arrays;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryByExample;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskParam;

public final class SispenCronInstanceQuery {

	private CronInstanceQueryByExample queryObj;
	
	
	public CronInstanceQueryByExample getQueryObject() {
		return this.queryObj;
	}
	
	public SispenCronInstanceQuery(String paramValue) {
		
		CronTaskInstance cronInstance = new CronTaskInstance();
		cronInstance.setActive("1");
		cronInstance.setCrontaskname(Configuracao.getInstance().getSispenCrontaskname());
		
		CronTaskParam param1 = new CronTaskParam();
		param1.setValue(paramValue);
		
		cronInstance.setParams(Arrays.asList(param1));
		
		CronInstanceQueryByExample queryObj = new CronInstanceQueryByExample();
		queryObj.setCronInstances(Arrays.asList(cronInstance));
		
		this.queryObj = queryObj;
	}
}
