package petrobras.engenharia.fic.cronovisao.managedbean.sispen;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.OrderByObject;
import petrobras.engenharia.fic.cronovisao.service.PagerObject;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryQuery;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.PagedCronHistoryService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronHistoryQueryResponse;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

public class CronHistDataModel extends LazyDataModel<CronTaskHistory> {

	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = Logger.getLogger(CronHistDataModel.class);
	
	private static Configuracao config = Configuracao.getInstance();
	
	private IServiceDelegate<CronHistoryQueryResponse, String> cronHistoryService = new PagedCronHistoryService();
	
	private SispenHistFiltroTipoBean ownerBean;
	
	public CronHistDataModel() {
		FacesContext context = FacesContext.getCurrentInstance();
		Application app = context.getApplication();
		ownerBean = app.evaluateExpressionGet(context, "#{sispenHistFiltroTipoBean}", SispenHistFiltroTipoBean.class);
	}

	@Override
	public List<CronTaskHistory> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String, String> filters) {

		// Busca proxima pagina:
		//first == rsStart
		//pageSize == maxItems
		
		List<CronTaskHistory> cronTaskList = null;

		if (logger.isDebugEnabled()) {
			logger.debug("first=["+first+"]");
			logger.debug("pageSize=["+pageSize+"]");
			logger.debug("sortField=["+sortField+"]");
			logger.debug("sortOrder=["+sortOrder+"]");
			logger.debug("filters=["+filters+"]");
		}

		
		Set<CronTaskInstance> cronInstances = ownerBean.findCronInstancesByTipo();
		if (cronInstances != null && cronInstances.size() > 0) {
			
			CronHistoryQuery query = new CronHistoryQuery.CronHistoryQueryBuilder()
										.setCronTaskName(config.getSispenCrontaskname())
										.setCronInstances(new ArrayList<CronTaskInstance>(cronInstances))
										.setPagerObject(new PagerObject(first, pageSize))
										.setOrderByObject(new OrderByObject(sortField, sortOrder))
										.build();
			
			Set<CronHistoryQueryResponse> resultSet = this.cronHistoryService.processMessage(query.getXml());
			
			CronHistoryQueryResponse response = resultSet.iterator().next();
			
			logger.debug("rsTotal=["+response.getNumRecords()+"]");

			//TODO setar rowCount somente se first == 0
			setRowCount(Integer.parseInt(response.getNumRecords()));
			
			List<CronTaskHistory> cronHistoryList = response.getCronTaskList();
			
			for (CronTaskHistory cronHistory : cronHistoryList) {
				cronHistory.setEmpreendimento(ownerBean.findEmpreendimentoByCronInstanceName(cronHistory.getInstancename()));
			}
			
			cronTaskList = new ArrayList<CronTaskHistory>(cronHistoryList);
		}
		
		return cronTaskList;
	}

}
