package petrobras.engenharia.fic.cronovisao.service;

import org.primefaces.model.SortOrder;

public class OrderByObject {

	private String fieldName;
	private String orderStr;
	
	public OrderByObject(String fieldName, String orderStr) {
		this.fieldName = fieldName;
		this.orderStr = orderStr;
	}
	
	public OrderByObject(String fieldName, SortOrder sortOrder) {
		String orderStr = null;
		switch (sortOrder) {
			case ASCENDING:
				orderStr = "asc";
				break;
			case DESCENDING:
				orderStr = "desc";
				break;
		}
		this.fieldName = fieldName;
		this.orderStr = orderStr;
	}

	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getOrder() {
		return orderStr;
	}
	public void setOrder(String orderStr) {
		this.orderStr = orderStr;
	}
	
	
}
