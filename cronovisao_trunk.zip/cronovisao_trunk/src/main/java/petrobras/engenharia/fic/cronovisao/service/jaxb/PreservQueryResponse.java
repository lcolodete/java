package petrobras.engenharia.fic.cronovisao.service.jaxb;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QueryMXPRESERVResponse")
public class PreservQueryResponse {
	
//	<?xml version="1.0" encoding="UTF-8"?>
//	<QueryMXPRESERVResponse 
//	    xmlns="http://www.ibm.com/maximo" 
//	    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" creationDateTime="2015-11-19T18:12:42-02:00" transLanguage="PT" baseLanguage="PT" messageID="1447963963282795220" maximoVersion="7 5 20130829-1209 V7510--1" rsStart="0" rsTotal="7329" rsCount="1">
//	    <MXPRESERVSet>
//	        <PM>
//	            <ASSETNUM>118702</ASSETNUM>
//	            <FIC_DATA_PROX>2015-11-22T00:00:00-02:00</FIC_DATA_PROX>
//	            <PMNUM>106585</PMNUM>
//	            <SITEID>COMPERJ-IEUT</SITEID>
//	            <STATUS maxvalue="ACTIVE">ATIVO</STATUS>
//	        </PM>
//	    </MXPRESERVSet>
//	</QueryMXPRESERVResponse>

	
	private String numRecords;
	
	@XmlAttribute(name="rsTotal")
	public String getNumRecords() {
		return numRecords;
	}

	public void setNumRecords(String numRecords) {
		this.numRecords = numRecords;
	}
}
