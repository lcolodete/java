package petrobras.engenharia.fic.cronovisao.service;

import java.io.Serializable;
import java.util.Set;

public interface IServiceDelegate<T, U> extends Serializable {

	public Set<T> processMessage(U payload);
	
}
