package petrobras.engenharia.fic.cronovisao.managedbean.pmwogen;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.helper.AgendaHelper;
import petrobras.engenharia.fic.cronovisao.model.AgendaPmWoGen;
import petrobras.engenharia.fic.cronovisao.model.Dia;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.croninstance.CronInstanceQuery;
import petrobras.engenharia.fic.cronovisao.service.croninstance.CronInstanceService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@SessionScoped
@ManagedBean
public class AgendaBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private static Configuracao config = Configuracao.getInstance();
	
	private IServiceDelegate<CronTaskInstance, String> service = new CronInstanceService();
//	private IServiceDelegate<CronTaskInstance, String> service = new MockCronInstanceServiceDelegate();
	
	private AgendaPmWoGen agenda;
	
	public AgendaBean() {
	}

	@PostConstruct
	public void init() {
		this.agenda = criaAgenda();
	}
	
	public void atualizarAgenda() {
		this.agenda = criaAgenda(); 
	}
	
	private AgendaPmWoGen criaAgenda() {
		CronInstanceQuery cronInstanceQuery = new CronInstanceQuery("crontaskname='" + config.getPmwogenCrontaskname() +"' and active='1'");
		
		Set<CronTaskInstance> cronInstanceSet = service.processMessage(cronInstanceQuery.getXml());

		AgendaPmWoGen agenda = AgendaHelper.criaAgenda(cronInstanceSet);
		
		return agenda;
	}
	
	public List<Dia> getProgramacaoSemanal() {
		return this.agenda.getProgramacaoSemanal();
	}

	public List<CronTaskInstance> getOutrasProgramacoes() {
		return this.agenda.getOutrasProgramacoes();
	}
	
	public Integer getQtdCronTasksSemanal() {
		Integer qtdTotal = 0;
		
		for (Dia dia : getProgramacaoSemanal()) {
			qtdTotal += dia.getCronInstances().size();
		}
		
		return qtdTotal;
	}
	
	public Integer getQtdCronTasksOutrasProgramacoes() {
		return getOutrasProgramacoes().size();
	}

}
