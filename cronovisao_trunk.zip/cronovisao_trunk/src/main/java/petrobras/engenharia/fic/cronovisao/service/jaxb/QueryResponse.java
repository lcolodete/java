package petrobras.engenharia.fic.cronovisao.service.jaxb;

import javax.xml.bind.annotation.XmlAttribute;

public abstract class QueryResponse {

	private String numRecords;
	private String rsStart;
	private String rsCount;
	
	@XmlAttribute(name="rsTotal")
	public String getNumRecords() {
		return numRecords;
	}

	public void setNumRecords(String numRecords) {
		this.numRecords = numRecords;
	}

	@XmlAttribute(name="rsStart")
	public String getRsStart() {
		return rsStart;
	}

	public void setRsStart(String rsStart) {
		this.rsStart = rsStart;
	}

	@XmlAttribute(name="rsCount")
	public String getRsCount() {
		return rsCount;
	}

	public void setRsCount(String rsCount) {
		this.rsCount = rsCount;
	}

}
