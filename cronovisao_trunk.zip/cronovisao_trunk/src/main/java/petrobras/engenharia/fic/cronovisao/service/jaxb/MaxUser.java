package petrobras.engenharia.fic.cronovisao.service.jaxb;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

public class MaxUser implements Serializable {

	private static final long serialVersionUID = 1L;

	/*
        <MAXUSER>
            <DEFSITE>IEABAST-IERB-CARTEIRA DE DIESEL-001</DEFSITE>
            <LOGINID>PRV_IERB_001</LOGINID>
            <MAXUSERID>5625</MAXUSERID>
            <USERID>PRV_IERB_001</USERID>
        </MAXUSER>
	 */

	private String defsite;
	private String loginid;
	private String maxuserid;
	private String userid;
	
	public MaxUser() {
	}
	
	@XmlElement(name="DEFSITE")
	public String getDefsite() {
		return defsite;
	}
	
	public void setDefsite(String defsite) {
		this.defsite = defsite;
	}
	
	@XmlTransient
	public String getLoginid() {
		return loginid;
	}
	
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}
	
	@XmlTransient
	public String getMaxuserid() {
		return maxuserid;
	}
	
	public void setMaxuserid(String maxuserid) {
		this.maxuserid = maxuserid;
	}
	
	@XmlElement(name="USERID")
	public String getUserid() {
		return userid;
	}
	
	public void setUserid(String userid) {
		this.userid = userid;
	}
}
