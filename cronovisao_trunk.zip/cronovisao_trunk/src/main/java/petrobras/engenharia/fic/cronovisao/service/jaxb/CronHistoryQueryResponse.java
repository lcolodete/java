package petrobras.engenharia.fic.cronovisao.service.jaxb;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QueryMXCRONHISTResponse")
public class CronHistoryQueryResponse extends QueryResponse {
	
	private List<CronTaskHistory> cronTaskList;

	@XmlElementWrapper(name="MXCRONHISTSet")
	@XmlElements({
		@XmlElement(name="CRONTASKHISTORY")
	})
	public List<CronTaskHistory> getCronTaskList() {
		return cronTaskList;
	}

	public void setCronTaskList(List<CronTaskHistory> cronTaskList) {
		this.cronTaskList = cronTaskList;
	}
	
	
}
