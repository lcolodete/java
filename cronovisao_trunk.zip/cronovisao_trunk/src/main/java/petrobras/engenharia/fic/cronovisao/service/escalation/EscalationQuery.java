package petrobras.engenharia.fic.cronovisao.service.escalation;

import petrobras.engenharia.fic.cronovisao.service.XmlQuery;

public class EscalationQuery extends XmlQuery {

	private StringBuilder xmlBegin;
	
	private StringBuilder xmlEnd;
	
	{
		xmlBegin = new StringBuilder();
		xmlBegin.append("<max:QueryMXESCALATION xmlns:max=\"http://www.ibm.com/maximo\" >")
				.append("<max:MXESCALATIONQuery>");
				

		xmlEnd = new StringBuilder();
		xmlEnd.append("</max:MXESCALATIONQuery>")
			  .append("</max:QueryMXESCALATION>");
	}

	public EscalationQuery(String where) {
		this.where = where;
	}

	@Override
	protected String getXmlBegin() {
		return xmlBegin.toString();
	}

	@Override
	protected String getXmlEnd() {
		return xmlEnd.toString();
	}

}
