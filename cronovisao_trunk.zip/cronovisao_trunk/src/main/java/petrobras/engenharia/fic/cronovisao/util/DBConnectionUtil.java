package petrobras.engenharia.fic.cronovisao.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;

public final class DBConnectionUtil {

	private static final Logger LOGGER = Logger.getLogger(DBConnectionUtil.class);
	
	public static DataSource getDataSource() {

		Configuracao config = Configuracao.getInstance();
		
		DataSource ds = null;
		try {
			InitialContext context = new InitialContext();
			
			String dsName = config.getDataSourceName();
			LOGGER.debug("dsName=["+dsName+"]");
			
			ds = (DataSource) context.lookup("java:/comp/env/"+dsName);
			
			LOGGER.debug("getDataSource(): ds=["+ds+"]");
			return ds;
			
		} catch (NamingException e) {
			LOGGER.error("Erro ao acessar JNDI para obter DataSource", e);
			throw new RuntimeException(e);
		}
	}
	
	private void testDatabaseConnection() {
		DataSource ficDS = DBConnectionUtil.getDataSource();
		
		try {
			Connection con = ficDS.getConnection();
			
			// usa a conexao obtida para fazer uma query
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			try {
				LOGGER.info("Executando query...");
				
				stmt = con.prepareStatement("SELECT * FROM maxsession");
				
				long begin = System.currentTimeMillis();
				rs = stmt.executeQuery();
				long end = System.currentTimeMillis();
				double queryTime = (end-begin)/1000.0;
				
				LOGGER.info("Query executada em "+queryTime+"s");
				
				while (rs.next()) {
					LOGGER.info(rs.getObject("userid").toString() + " - " + rs.getObject("issystem").toString() + " - " + rs.getObject("logindatetime").toString());
				}
				
			} catch (SQLException e) {
				LOGGER.error("Erro", e);
			} finally {
				if (rs != null)
					try {
						rs.close();
					} catch (SQLException e) {
						LOGGER.error("Erro", e);
					}
				
				if (stmt != null)
					try {
						stmt.close();
					} catch (SQLException e) {
						LOGGER.error("Erro", e);
					}
				
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {
						LOGGER.error("Erro", e);
					}
				}
			}
			
		} catch (SQLException e) {
			LOGGER.error("Erro ao criar conexao: "+e);
			throw new RuntimeException(e);
		}
	}

	
}
