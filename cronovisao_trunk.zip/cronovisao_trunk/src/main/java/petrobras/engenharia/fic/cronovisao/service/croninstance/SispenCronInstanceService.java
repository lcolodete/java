package petrobras.engenharia.fic.cronovisao.service.croninstance;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.AbstractHttpClient;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryByExample;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryResponse;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

public class SispenCronInstanceService extends AbstractHttpClient implements IServiceDelegate<CronTaskInstance, CronInstanceQueryByExample> {

	private static final long serialVersionUID = 1L;

	private static Configuracao config = Configuracao.getInstance();
	
	public SispenCronInstanceService() {
		super(config.getMosCronTaskInstance());
	}

	@Override
	public Set<CronTaskInstance> processMessage(CronInstanceQueryByExample payload) {

		if (payload == null) {
			return null;
		}
		
		CronInstanceQueryResponse cronInstanceQueryResponse = getBuilder()
																.entity(payload)
																.post(CronInstanceQueryResponse.class);

		List<CronTaskInstance> cronInstances = cronInstanceQueryResponse.getCronInstances();

		return new TreeSet<CronTaskInstance>(cronInstances);
	}

}
