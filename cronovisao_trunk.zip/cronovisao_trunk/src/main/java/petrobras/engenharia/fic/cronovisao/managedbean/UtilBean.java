package petrobras.engenharia.fic.cronovisao.managedbean;

import java.io.Serializable;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;

@SessionScoped
@ManagedBean
public class UtilBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Configuracao config = Configuracao.getInstance();
	
	public UtilBean() {
	}
	
	public String linkLogCron(String instanceName) {
		StringBuilder sb = new StringBuilder();
		sb.append( config.getUrlLogsCron() )
		  .append(instanceName)
		  .append(".log");
		
		return sb.toString();
	}
	
	public String linkLogJVM(String jvmName) {
		return config.getJvmLogUri(jvmName);
	}
	
	public String getPmWoGenCronTask() {
		return config.getPmwogenCrontaskname(); 
	}
	
	public String getSispenCronTask() {
		return config.getSispenCrontaskname();
	}

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		sdf.setLenient(false);
		
		System.out.println( sdf.format(new Date()) );
		
		Date startDate = sdf.parse("2012-04-20T02:01:13");
		Date endDate = sdf.parse("2012-04-20T02:32:26");
		System.out.println(startDate);
		System.out.println( sdf.format(startDate) );

		long duracaoMilis = endDate.getTime() - startDate.getTime();
		double duracaoMinutos = (duracaoMilis/1000d) / 60d;
		
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(2);
		
		System.out.println( duracaoMinutos ); 
		System.out.println( nf.format(duracaoMinutos) );
		
		
		///////////
		
		endDate = sdf.parse("2017-04-12T15:32:26");
		
		Date now = new Date();
		
		Calendar endLimit = Calendar.getInstance();
		endLimit.setTime(now);
		endLimit.add(Calendar.DAY_OF_MONTH, -1);
		
		if (endDate.before(endLimit.getTime())) {
			System.out.println("endDate before");
		} else {
			System.out.println("endDate after");
		}
	}
	
	
}
