package petrobras.engenharia.fic.cronovisao.managedbean.sispen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.model.LazyDataModel;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.model.TipoCronSispen;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryQuery;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryService;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceQuery;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryByExample;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ManagedBean
@ViewScoped
public class CopyOfSispenHistFiltroTipoBean {

	private static Configuracao config = Configuracao.getInstance();
	
	private static final Logger logger = Logger.getLogger(CopyOfSispenHistFiltroTipoBean.class);
	
	private DataTable dataTable;

	private IServiceDelegate<CronTaskHistory, String> cronHistoryService = new CronHistoryService();
	
	private IServiceDelegate<CronTaskInstance, CronInstanceQueryByExample> cronInstanceService = new SispenCronInstanceService();
	
	private List<CronTaskHistory> cronTaskList;
	
	private TipoCronSispen[] tipos = TipoCronSispen.values();
	
	private TipoCronSispen tipoSelecionado;
	
	private Map<TipoCronSispen, Set<CronTaskInstance>> cronInstanceCache = new HashMap<TipoCronSispen, Set<CronTaskInstance>>();
	
	private Map<String, String> cronsAndSites = new HashMap<String, String>();
	
	private LazyDataModel<CronTaskHistory> dataModel;
	
	private int pageSize = 5;
	
	public CopyOfSispenHistFiltroTipoBean() {
		createDataModel(0);
	}

	private void createDataModel(int rowCount) {
		this.dataModel = new CronHistDataModel();
		this.dataModel.setRowCount(rowCount);
		this.dataModel.setPageSize(this.getPageSize());
	}
	
	public void carregarLista() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> carregarLista()");
			logger.debug(">>>>>>>>>>>>>>>>> tipo="+getTipoSelecionado());
		}
		
		if (getTipoSelecionado() != null) {
			
			this.dataTable.setValueExpression("sortBy", null);
			
			this.cronTaskList = null;
			
			Set<CronTaskInstance> cronInstances = cronInstanceCache.get(getTipoSelecionado());
			if (cronInstances == null) {

				SispenCronInstanceQuery sispenQuery = new SispenCronInstanceQuery(getTipoSelecionado().getInternalValue());
				cronInstances = cronInstanceService.processMessage(sispenQuery.getQueryObject());
				
				for (CronTaskInstance cron : cronInstances) {
					cronsAndSites.put(cron.getInstancename(), cron.getParam("EMPREENDIMENTO"));
				}
				
				cronInstanceCache.put(getTipoSelecionado(), cronInstances);
			}
			
			if (cronInstances != null && cronInstances.size() > 0) {
				
				CronHistoryQuery query = new CronHistoryQuery.CronHistoryQueryBuilder()
											.setCronTaskName(config.getSispenCrontaskname())
											.setCronInstances(new ArrayList<CronTaskInstance>(cronInstances))
											.build();
				
				Set<CronTaskHistory> cronTaskHistorySet = this.cronHistoryService.processMessage(query.getXml());
				
				for (CronTaskHistory cronHistory : cronTaskHistorySet) {
					cronHistory.setEmpreendimento(cronsAndSites.get(cronHistory.getInstancename()));
				}
				
				this.cronTaskList = new ArrayList<CronTaskHistory>(cronTaskHistorySet);
			}
		}
		
	}
	
	public List<CronTaskHistory> getCronTaskList() {
		return cronTaskList;
	}

	public TipoCronSispen[] getTipos() {
		return tipos;
	}

	public TipoCronSispen getTipoSelecionado() {
		return tipoSelecionado;
	}

	public void setTipoSelecionado(TipoCronSispen tipoSelecionado) {
		this.tipoSelecionado = tipoSelecionado;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}

	public LazyDataModel<CronTaskHistory> getDataModel() {
		return dataModel;
	}

	public int getPageSize() {
		return pageSize;
	}

}
