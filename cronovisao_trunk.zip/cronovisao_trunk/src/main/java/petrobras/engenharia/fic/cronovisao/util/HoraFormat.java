package petrobras.engenharia.fic.cronovisao.util;

public class HoraFormat extends ScheduleFormat {

	protected HoraFormat(String schedule) {
		super(schedule);
		this.textoFrequenciaPrincipal = "hora";
	}

	@Override
	public String formatHora() {
		return "N/A";
	}

	/**
	 * Exemplo de campo schedule: <code>3h,*,25,*,*,*,*,*,*,*</code>
	 * <br/>
	 * <br/>
	 * <code>
	 * 3h,  -> A cada 3 horas<br/>
	 * *,   -> Nao usado<br/>
	 * 25,  -> No minuto 25<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *    -> Nao usado
	 * </code>
	 * 
	 */
	@Override
	public String format() {
		String formattedStr = "";
		
		StringBuilder formattedSb = new StringBuilder();

		String[] scheduleTokens = this.schedule.split(",");
		String minuto = scheduleTokens[2];

		StringBuilder minutoSb = new StringBuilder();
		minutoSb.append(". No minuto ")
				.append(minuto);
		
		formattedStr = formattedSb.append(formatFrequenciaPrincipal())
				  .append("<br/>")	// pula linha
				  .append(minutoSb)
				  .toString();
		
		return formattedStr;
	}

}
