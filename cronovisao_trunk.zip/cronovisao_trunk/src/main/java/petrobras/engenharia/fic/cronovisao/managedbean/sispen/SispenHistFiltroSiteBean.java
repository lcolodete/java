package petrobras.engenharia.fic.cronovisao.managedbean.sispen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryQuery;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryService;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceQuery;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryByExample;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ManagedBean
@ViewScoped
public class SispenHistFiltroSiteBean {

	private static Configuracao config = Configuracao.getInstance();
	
	private static final Logger logger = Logger.getLogger(SispenHistFiltroSiteBean.class);
	
	private DataTable dataTable;

	private IServiceDelegate<CronTaskHistory, String> cronHistoryService = new CronHistoryService();
	
	private IServiceDelegate<CronTaskInstance, CronInstanceQueryByExample> cronInstanceService = new SispenCronInstanceService();
	
	private List<CronTaskHistory> cronTaskList;
	
	private Map<String, String> cronsAndSites;

	private String txtEmpreendimento;
	
	public SispenHistFiltroSiteBean() {
	}

	public void filtrar() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> filtrar()");
			logger.debug(">>>>>>>>>>>>>>>>> empreendimento=["+txtEmpreendimento+"]");
		}
		
		this.dataTable.setValueExpression("sortBy", null);
		
		this.cronTaskList = null;
		
		this.cronsAndSites = new HashMap<String, String>();

		SispenCronInstanceQuery sispenQuery = new SispenCronInstanceQuery(txtEmpreendimento.toLowerCase());
		Set<CronTaskInstance> cronInstances = cronInstanceService.processMessage(sispenQuery.getQueryObject());
		
		for (CronTaskInstance cron : cronInstances) {
			cronsAndSites.put(cron.getInstancename(), cron.getParam("EMPREENDIMENTO"));
		}
		
		if (cronInstances != null && cronInstances.size() > 0) {
			
			CronHistoryQuery query = new CronHistoryQuery.CronHistoryQueryBuilder()
										.setCronTaskName(config.getSispenCrontaskname())
										.setCronInstances(new ArrayList<CronTaskInstance>(cronInstances))
										.build();
			
			Set<CronTaskHistory> cronTaskHistorySet = this.cronHistoryService.processMessage(query.getXml());
			
			for (CronTaskHistory cronHistory : cronTaskHistorySet) {
				cronHistory.setEmpreendimento(cronsAndSites.get(cronHistory.getInstancename()));
			}
			
			this.cronTaskList = new ArrayList<CronTaskHistory>(cronTaskHistorySet);
		}
	
	}
	
	public List<CronTaskHistory> getCronTaskList() {
		return cronTaskList;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}

	public String getTxtEmpreendimento() {
		return txtEmpreendimento;
	}

	public void setTxtEmpreendimento(String txtEmpreendimento) {
		this.txtEmpreendimento = txtEmpreendimento;
	}

}
