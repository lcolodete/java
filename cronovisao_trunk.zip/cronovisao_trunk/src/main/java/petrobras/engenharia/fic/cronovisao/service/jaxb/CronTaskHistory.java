package petrobras.engenharia.fic.cronovisao.service.jaxb;

import java.io.Serializable;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

import petrobras.engenharia.fic.cronovisao.util.DateUtil;

public class CronTaskHistory implements Serializable, Comparable<CronTaskHistory> {

	private static final long serialVersionUID = 1L;
	
	/**
	 * Formato: YYYY-MM-ddThh:mm:ss-03:00
	 * Ex: 2012-04-20T02:01:13-03:00
	 */
	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	
	private String activity;
	private String crontaskhistoryid;
	private String crontaskname;
	private String endtime;
	private String instancename;
	private String runtimeerror;
	private String sequence;
	private String serverhost;
	private String servername;
	private String starttime;

	//Transientes
	private String empreendimento;
	private Date dataInicio;
	private Date dataFim;
	private String dataInicioAsString;
	private String dataFimAsString;
	private String duracaoAsString;
	private Double duracao;
	/**
	 * Numero de registros de PM que ainda serao processados.
	 */
	private Integer numPreservacoesProcessar = 0;

	public CronTaskHistory() {
	}
	
	@XmlElement(name="ACTIVITY")
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	
	@XmlElement(name="CRONTASKHISTORYID")
	public String getCrontaskhistoryid() {
		return crontaskhistoryid;
	}
	public void setCrontaskhistoryid(String crontaskhistoryid) {
		this.crontaskhistoryid = crontaskhistoryid;
	}
	
	@XmlElement(name="CRONTASKNAME")
	public String getCrontaskname() {
		return crontaskname;
	}
	public void setCrontaskname(String crontaskname) {
		this.crontaskname = crontaskname;
	}
	
	@XmlElement(name="ENDTIME")
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	
	@XmlElement(name="INSTANCENAME")
	public String getInstancename() {
		return instancename;
	}
	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}
	
	@XmlElement(name="RUNTIMEERROR")
	public String getRuntimeerror() {
		return runtimeerror;
	}
	public void setRuntimeerror(String runtimeerror) {
		this.runtimeerror = runtimeerror;
	}
	
	@XmlElement(name="SEQUENCE")
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	
	@XmlElement(name="SERVERHOST")
	public String getServerhost() {
		return serverhost;
	}
	public void setServerhost(String serverhost) {
		this.serverhost = serverhost;
	}
	
	@XmlElement(name="SERVERNAME")
	public String getServername() {
		return servername;
	}
	public void setServername(String servername) {
		this.servername = servername;
	}
	
	@XmlElement(name="STARTTIME")
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	@XmlTransient
	public String getEmpreendimento() {
		return empreendimento;
	}
	
	public void setEmpreendimento(String empreendimento) {
		this.empreendimento = empreendimento;
	}

	/**
	 * Cria um objeto Date a partir da String fornecida.
	 * 
	 * Formato do parametro: YYYY-MM-ddThh:mm:ss-03:00
	 * Ex: 2012-04-20T02:01:13-03:00
	 */
	private Date parseDate(String dateString) throws ParseException {
		//Retira a informa��o do time zone antes de fazer o calculo
		String newDateString = dateString.substring(0, 19);

		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		sdf.setLenient(false);

		Date date = sdf.parse(newDateString);
		return date;
	}
	
	@XmlTransient
	public Date getDataInicio() {
		if (this.dataInicio == null) {
			try {
				this.dataInicio = parseDate(this.starttime);
			} catch (ParseException e) {
				return null;
			}
		}
		return this.dataInicio;
	}
	
	@XmlTransient
	public Date getDataFim() {
		if (this.dataFim == null) {
			try {
				this.dataFim = parseDate(this.endtime);
			} catch (ParseException e) {
				return null;
			}
		}
		return this.dataFim;
	}
	
	@XmlTransient
	public boolean getShouldWarnEndTime() {
		
		if (getDataFim() != null) {
			Calendar endLimit = Calendar.getInstance();
			endLimit.setTime(new Date());
			endLimit.add(Calendar.DAY_OF_MONTH, -1);
			
			if (getDataFim().before(endLimit.getTime())) {
				return true;
			}
		}
		return false;
	}
	
	@XmlTransient
	public String getDataInicioAsString() {
		if (this.dataInicioAsString == null) {
			this.dataInicioAsString = DateUtil.formatDate(this.starttime, DATE_FORMAT);
		}
		return this.dataInicioAsString;
	}
	
	@XmlTransient
	public String getDataFimAsString() {
		if (this.dataFimAsString == null) {
			this.dataFimAsString = DateUtil.formatDate(this.endtime, DATE_FORMAT);
		}
		return this.dataFimAsString;
	}
	
	@XmlTransient
	public Double getDuracao() {
		if (this.duracao == null) {
			double duracao = 0.0;
			
			try {
				duracao = calculaDuracao(getDataInicio(), getDataFim());
			} catch (ParseException e) {
				duracao = -1;
			}

			this.duracao = duracao;
		}
		return this.duracao;
	}
	
	@XmlTransient
	public String getDuracaoAsString() {
		if (this.duracaoAsString == null) {
			Double duracaoDouble = getDuracao();
			
			if (duracaoDouble <= 0) {
				return "0";
			}
			
			NumberFormat nf = NumberFormat.getInstance();
			nf.setMaximumFractionDigits(2);
			
			String duracaoFormatada = nf.format(duracaoDouble) + " min";
			
			this.duracaoAsString = duracaoFormatada;
		}
		return this.duracaoAsString;
	}

	@XmlTransient
	public Integer getNumPreservacoesProcessar() {
		return numPreservacoesProcessar;
	}
	
	public void setNumPreservacoesProcessar(Integer numPreservacoesProcessar) {
		this.numPreservacoesProcessar = numPreservacoesProcessar;
	}

	/**
	 * Calcula o tempo de execucao da cron task, em minutos.
	 * 
	 * Formato dos parametros: YYYY-MM-ddThh:mm:ss-03:00
	 * Ex: 2012-04-20T02:01:13-03:00
	 * 
	 * @param startDate data e hora de inicio
	 * @param endDate data e hora de termino
	 * @return
	 */
	private double calculaDuracao(Date startDate, Date endDate) throws ParseException {
		long duracaoMilis = endDate.getTime() - startDate.getTime();
		
		double duracaoMinutos = (duracaoMilis/1000d) / 60d;
		
		return duracaoMinutos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((crontaskhistoryid == null) ? 0 : crontaskhistoryid
						.hashCode());
		result = prime * result
				+ ((instancename == null) ? 0 : instancename.hashCode());
		result = prime * result
				+ ((sequence == null) ? 0 : sequence.hashCode());
		result = prime * result
				+ ((starttime == null) ? 0 : starttime.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CronTaskHistory other = (CronTaskHistory) obj;
		if (crontaskhistoryid == null) {
			if (other.crontaskhistoryid != null)
				return false;
		} else if (!crontaskhistoryid.equals(other.crontaskhistoryid))
			return false;
		if (instancename == null) {
			if (other.instancename != null)
				return false;
		} else if (!instancename.equals(other.instancename))
			return false;
		if (sequence == null) {
			if (other.sequence != null)
				return false;
		} else if (!sequence.equals(other.sequence))
			return false;
		if (starttime == null) {
			if (other.starttime != null)
				return false;
		} else if (!starttime.equals(other.starttime))
			return false;
		return true;
	}
	
	@Override
	public int compareTo(CronTaskHistory o) {
		return instancename.compareToIgnoreCase(o.getInstancename());
	}
	
}
