package petrobras.engenharia.fic.cronovisao.service;

import com.sun.jersey.core.util.Base64;

public class Base64Utils {

	public static String encode(String s) {
		byte[] result = Base64.encode(s);
		
		return byteArrayToAsciiString(result);
	}

	private static String byteArrayToAsciiString(byte[] b) {
		return new String(b);
	}
	
	public static String decode(String s) {
		byte[] bDecoded = Base64.decode(s);
		
		return byteArrayToAsciiString(bDecoded);
	}

}
