package petrobras.engenharia.fic.cronovisao.managedbean.escalation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.model.LazyDataModel;

import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.escalation.EscalationQuery;
import petrobras.engenharia.fic.cronovisao.service.escalation.EscalationService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.Escalation;

@SessionScoped
@ManagedBean
public class EscalationListaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(EscalationListaBean.class);
	
	private DataTable dataTable;

	private IServiceDelegate<Escalation, String> serviceDelegate;
	
	private List<Escalation> escalationList;
	
	private LazyDataModel<Escalation> model;
	
	public EscalationListaBean() {
		LOGGER.debug("ManagedBean instanciado: "+this.getClass().getSimpleName());
	}

	@PostConstruct
	public void init() {
		LOGGER.debug("ManagedBean postConstruct");
		
		this.serviceDelegate = new EscalationService();
//		serviceDelegate = new FakeEscalationServiceDelegate();
		
		carregarLista();
		
//		model = new LazyDataModel<Escalation>() {
//
//			@Override
//			public List<Escalation> load(int first, int pageSize, String sortField, SortOrder sortOrder, Map<String, String> filters) {
//				logger.debug(first);//rsStart
//				logger.debug(pageSize);//maxItems
//				logger.debug(sortField);
//				logger.debug(sortOrder);
//				logger.debug(filters);
//				
//				List<Escalation> escalations;
//				
//				Escalation esc1 = new Escalation();
//				esc1.setActive("1");
//				esc1.setEscalation("FIC_OCULTATTI");
//				esc1.setInstancename("ESCFIC_OCULTATTI");
//				esc1.setLastrun("2013-12-11T18:03:31-02:00");
//				esc1.setObjectname("WORKORDER");
//				esc1.setSchedule("10m,*,*,*,*,*,*,*,*,*");
//				
//				Escalation esc2 = new Escalation();
//				esc2.setActive("1");
//				esc2.setEscalation("FIC_RECEBITECRT");
//				esc2.setInstancename("ESCFIC_RECEBITECRT");
//				esc2.setLastrun("2013-12-12T02:00:03-02:00");
//				esc2.setObjectname("WORKORDER");
//				esc2.setSchedule("1d,0,0,2,*,*,*,*,*,*");
//				
//				Escalation esc3 = new Escalation();
//				esc3.setActive("1");
//				esc3.setEscalation("FIC_RPI");
//				esc3.setInstancename("ESCFIC_RPI");
//				esc3.setLastrun("2013-12-12T12:00:39-02:00");
//				esc3.setObjectname("WORKORDER");
//				esc3.setSchedule("1h,*,0,*,*,*,*,*,*,*");
//				
//				escalations = new ArrayList<Escalation>();
//				
//				escalations.add(esc1);
//				escalations.add(esc2);
//				escalations.add(esc3);
//
//				setRowCount(24);//rsTotal
//				
//				return escalations;
//			}
//			
//		};
	}
	
	public void atualizarLista(ActionEvent event) {
		LOGGER.debug(">>>>>>>>>> atualizarLista() - INICIO");
		LOGGER.debug(">>>>>>>>>> ActionEvent=["+event+"]");
		carregarLista();
		this.dataTable.setValueExpression("sortBy", null);
		LOGGER.debug(" com setValueExpression ");
		LOGGER.debug(">>>>>>>>>> atualizarLista() - FIM");
	}
	
	private void carregarLista() {
		this.escalationList = null;
		
		EscalationQuery query = new EscalationQuery("active=1");
		
		Set<Escalation> escalationSet = this.serviceDelegate.processMessage(query.getXml());
		
		if (escalationSet != null && escalationSet.size() > 0) {
			this.escalationList = new ArrayList<Escalation>();
			this.escalationList.addAll(escalationSet);
		}
	}
	
	public List<Escalation> getEscalationList() {
		return this.escalationList;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}

	public LazyDataModel<Escalation> getModel() {
		return model;
	}

	
}
