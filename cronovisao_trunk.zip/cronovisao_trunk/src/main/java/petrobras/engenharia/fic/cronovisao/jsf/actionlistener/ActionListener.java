package petrobras.engenharia.fic.cronovisao.jsf.actionlistener;

import java.text.MessageFormat;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.sun.faces.application.ActionListenerImpl;

public class ActionListener extends ActionListenerImpl {

	private static final Logger logger = LogManager.getLogger(ActionListener.class);

	@Override
	public void processAction(ActionEvent event) {
		
		try {
			
			logger.debug("BEFORE >>> " + event.getPhaseId() + " -> " + MessageFormat.format("processAction({0})",
	                    event.getComponent().getId()));
			
	        super.processAction(event);

	        logger.debug("AFTER >>> " + event.getPhaseId() + " -> " + MessageFormat.format("processAction({0})",
	                    event.getComponent().getId()));	        
			
	    } catch (Exception e) {
	    	e.printStackTrace();
	    	
			FacesContext context = FacesContext.getCurrentInstance();
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getCause().getMessage(), e.getMessage());
			context.addMessage(null, message);
	    }
	}



}
