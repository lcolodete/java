package petrobras.engenharia.fic.cronovisao.service.scheduler;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.service.AbstractHttpClient;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.PreservQueryResponse;

public class PreservServiceDelegate extends AbstractHttpClient implements IServiceDelegate<PreservQueryResponse, String> {

	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = LogManager.getLogger(PreservServiceDelegate.class);
	
	public PreservServiceDelegate() {
		super("MXPRESERV");
	}
	
	@Override
	public Set<PreservQueryResponse> processMessage(String query) {
		if (query == null || query.isEmpty()) {
			return null;
		}

		PreservQueryResponse preservQueryResponse = getBuilder().post(PreservQueryResponse.class, query);
		
		LOGGER.info("query=["+query+"], retorno=["+preservQueryResponse.getNumRecords()+"]");
		
		Set<PreservQueryResponse> resultSet = new HashSet<PreservQueryResponse>();
		resultSet.add(preservQueryResponse);
		return resultSet;
	}

}
