package petrobras.engenharia.fic.cronovisao.managedbean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import petrobras.engenharia.fic.cronovisao.model.Dia;
import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;

@SessionScoped
@ManagedBean
public class TesteBean {

	private String dia;
	
	private DiaDaSemana diaEnum;
	
	private DiaDaSemana[] dias;
	
	private List<Dia> agenda;

	public List<Dia> getAgenda() {
		return agenda;
	}

	public void setAgenda(List<Dia> agenda) {
		this.agenda = agenda;
	}

	public TesteBean() {
		agenda = new ArrayList<Dia>();
		agenda.add(new Dia(DiaDaSemana.DOMINGO));
		agenda.add(new Dia(DiaDaSemana.SEGUNDA));
		
		dias = DiaDaSemana.values();
	}
	
	public void imprimeDia() {
		System.out.println(">>>>>>>>>>> dia = " + dia);
		System.out.println(">>>>>>>>>>> diaEnum = " + diaEnum);
	}
	
	public DiaDaSemana[] getDias() {
		return dias;
	}

	public void setDias(DiaDaSemana[] dias) {
		this.dias = dias;
	}

	public String getDia() {
		return dia;
	}

	public void setDia(String dia) {
		this.dia = dia;
	}

	public DiaDaSemana getDiaEnum() {
		return diaEnum;
	}

	public void setDiaEnum(DiaDaSemana diaEnum) {
		this.diaEnum = diaEnum;
	}
}
