package petrobras.engenharia.fic.cronovisao.managedbean.pmwogen;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.helper.AgendaHelper;
import petrobras.engenharia.fic.cronovisao.model.Dia;
import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryQuery;
import petrobras.engenharia.fic.cronovisao.service.cronhistory.CronHistoryService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ViewScoped
@ManagedBean
public class CronHistBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static Configuracao config = Configuracao.getInstance();
	
	private static final Logger logger = Logger.getLogger(CronHistBean.class);
	
	private DataTable dataTable;

	private DiaDaSemana diaSelecionado;
	
	private DiaDaSemana[] dias;
	
	private AgendaBean agendaBean;
	
	private IServiceDelegate<CronTaskHistory, String> serviceDelegate;
	
	private List<CronTaskHistory> cronTaskList;
	
	public CronHistBean() {
	}

	@PostConstruct
	public void init() {
		dias = DiaDaSemana.values();
		
		serviceDelegate = new CronHistoryService();
//		serviceDelegate = new MockCronHistServiceDelegate();
		
		FacesContext context = FacesContext.getCurrentInstance();
		Application app = context.getApplication();
		agendaBean = app.evaluateExpressionGet(context, "#{agendaBean}", AgendaBean.class);
	}
	
	public void carregarLista() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> carregarLista()");
			logger.debug(">>>>>>>>>>>>>>>>> dia="+getDiaSelecionado());
		}
		
		this.dataTable.setValueExpression("sortBy", null);
		
		this.cronTaskList = null;
		
		List<Dia> agenda = this.agendaBean.getProgramacaoSemanal();
		
		List<CronTaskInstance> cronInstances = AgendaHelper.listaCronTasksAtivasDoDia(agenda, this.diaSelecionado);
		
		if (cronInstances != null && cronInstances.size() > 0) {
			CronHistoryQuery query = new CronHistoryQuery.CronHistoryQueryBuilder()
											.setCronTaskName(config.getPmwogenCrontaskname())
											.setCronInstances(cronInstances)
											.build();
			
			Set<CronTaskHistory> cronTaskHistorySet = this.serviceDelegate.processMessage(query.getXml());
			
			/*
			 * para cada cronTaskHistory
			 *    procura qual o cronTaskInstance dele (instancename tem que bater)
			 *    copia o empreendimento do cronTaskInstance para cronTaskHistory 
			 */
			
			for (CronTaskHistory cronHistory : cronTaskHistorySet) {
				
				CronTaskInstance cronInstanceSearch = new CronTaskInstance();
				cronInstanceSearch.setCrontaskname(cronHistory.getCrontaskname());
				cronInstanceSearch.setInstancename(cronHistory.getInstancename());
				
				int index = Collections.binarySearch(cronInstances, cronInstanceSearch);
				
				if (logger.isDebugEnabled()) {
					logger.debug("index="+index);
				}
				
				if ( index >= 0) { // achou
					String empreendimento = cronInstances.get(index).getEmpreendimento();
					if (logger.isDebugEnabled()) {
						logger.debug("instancename="+cronHistory.getInstancename());
						logger.debug("empreendimento="+empreendimento);
					}
					cronHistory.setEmpreendimento(empreendimento);
				}
				
			}
			
			
			cronTaskList = new ArrayList<CronTaskHistory>();
			cronTaskList.addAll(cronTaskHistorySet);
		}
	}
	
	public List<CronTaskHistory> getCronTaskList() {
		return cronTaskList;
	}

	public DiaDaSemana[] getDias() {
		return dias;
	}

	public DiaDaSemana getDiaSelecionado() {
		return diaSelecionado;
	}

	public void setDiaSelecionado(DiaDaSemana diaSelecionado) {
		this.diaSelecionado = diaSelecionado;
	}

	public Integer getCronTaskListSize() {
		Integer qtd = 0;

		if (cronTaskList != null) {
			qtd = cronTaskList.size();
		}
		
		return qtd;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}
	
}
