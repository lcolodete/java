package petrobras.engenharia.fic.cronovisao.service.jaxb;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

import petrobras.engenharia.fic.cronovisao.util.DateUtil;

public class Escalation implements Serializable, Comparable<Escalation> {
	
	private static final long serialVersionUID = 1L;

	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	
	private String active;
	private String escalation;
	private String instancename;
	private String lastrun;
	private String objectname;
	private String schedule;
	
	private String dataUltimaExecucaoAsString;
	private Date dataUltimaExecucao;
	
	@XmlElement(name="ACTIVE")
	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	@XmlElement(name="ESCALATION")
	public String getEscalation() {
		return escalation;
	}

	public void setEscalation(String escalation) {
		this.escalation = escalation;
	}

	@XmlElement(name="INSTANCENAME")
	public String getInstancename() {
		return instancename;
	}

	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}

	@XmlElement(name="LASTRUN")
	public String getLastrun() {
		return lastrun;
	}

	public void setLastrun(String lastrun) {
		this.lastrun = lastrun;
	}

	@XmlElement(name="OBJECTNAME")
	public String getObjectname() {
		return objectname;
	}

	public void setObjectname(String objectname) {
		this.objectname = objectname;
	}

	@XmlElement(name="SCHEDULE")
	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	/**
	 * Cria um objeto Date a partir da String fornecida.
	 * 
	 * Formato do parametro: YYYY-MM-ddThh:mm:ss-03:00
	 * Ex: 2012-04-20T02:01:13-03:00
	 */
	private Date parseDate(String dateString) throws ParseException {
		//Retira a informa��o do time zone antes de fazer o calculo
		String newDateString = dateString.substring(0, 19);

		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		sdf.setLenient(false);

		Date date = sdf.parse(newDateString);
		return date;
	}
	
	@XmlTransient
	public Date getDataUltimaExecucao() {
		if (this.dataUltimaExecucao == null) {
			try {
				this.dataUltimaExecucao = parseDate(this.lastrun);
			} catch (ParseException e) {
			}
		}
		return this.dataUltimaExecucao;
	}
	
	@XmlTransient
	public String getDataUltimaExecucaoAsString() {
		if (this.dataUltimaExecucaoAsString == null) {
			this.dataUltimaExecucaoAsString = DateUtil.formatDate(this.lastrun, DATE_FORMAT);
		}
		return this.dataUltimaExecucaoAsString;
	}

	@Override
	public int compareTo(Escalation o) {
		return this.escalation.compareToIgnoreCase(o.getEscalation());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((escalation == null) ? 0 : escalation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Escalation other = (Escalation) obj;
		if (escalation == null) {
			if (other.escalation != null)
				return false;
		} else if (!escalation.equals(other.escalation))
			return false;
		return true;
	}

	
}
