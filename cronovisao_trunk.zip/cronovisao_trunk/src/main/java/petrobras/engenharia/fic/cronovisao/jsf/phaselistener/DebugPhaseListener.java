package petrobras.engenharia.fic.cronovisao.jsf.phaselistener;

import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class DebugPhaseListener implements PhaseListener {

	private static final Logger logger = LogManager.getLogger(DebugPhaseListener.class);

	/**
	 * Exibe os atributos do request e da sessao antes da fase 1
	 */
	private static final Boolean SHOW_ATTRIBUTES = Boolean.FALSE; 
	
	@Override
	public void afterPhase(PhaseEvent event) {
		logger.info("++++++ END PHASE " + event.getPhaseId()+" ++++++");
	}

	@Override
	public void beforePhase(PhaseEvent event) {
		logger.info("++++++ START PHASE " + event.getPhaseId()+" ++++++");
		
		if (event.getPhaseId().equals(PhaseId.RESTORE_VIEW)) {
			
			if (SHOW_ATTRIBUTES) {
				FacesContext context = FacesContext.getCurrentInstance();
				
				Map<String, Object> requestAttributes = context.getExternalContext().getRequestMap();
				
				logger.info("<REQUEST ATTRIBUTES>");
				for (Map.Entry<String, Object> entry : requestAttributes.entrySet()) {
					logger.info(entry.getKey()+"="+entry.getValue());
				}
				logger.info("</REQUEST ATTRIBUTES>");
				
				Map<String, Object> sessionAttributes = context.getExternalContext().getSessionMap();
				
				logger.info("<SESSION ATTRIBUTES>");
				for (Map.Entry<String, Object> entry : sessionAttributes.entrySet()) {
					logger.info(entry.getKey()+"="+entry.getValue());
				}
				logger.info("</SESSION ATTRIBUTES>");
			}
			
		}
		
	}

	@Override
	public PhaseId getPhaseId() {
		return PhaseId.ANY_PHASE;
	}

}
