package petrobras.engenharia.fic.cronovisao.service.cronhistory;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;
import petrobras.engenharia.fic.cronovisao.service.AbstractHttpClient;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronHistoryQueryResponse;

public class PagedCronHistoryService extends AbstractHttpClient implements IServiceDelegate<CronHistoryQueryResponse, String> {

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = LogManager.getLogger(PagedCronHistoryService.class);
	
	private static Configuracao config = Configuracao.getInstance();
	
	public PagedCronHistoryService() {
		super(config.getMosCronTaskHistory());
	}

	public Set<CronHistoryQueryResponse> processMessage(String query) {
		
		if (query == null || query.isEmpty()) {
			return null;
		}
		
		CronHistoryQueryResponse cronHistQueryResponse = getBuilder().post(CronHistoryQueryResponse.class, query);
		Set<CronHistoryQueryResponse> resultSet = new HashSet<CronHistoryQueryResponse>();
		resultSet.add(cronHistQueryResponse);
		return resultSet;
	}
}
