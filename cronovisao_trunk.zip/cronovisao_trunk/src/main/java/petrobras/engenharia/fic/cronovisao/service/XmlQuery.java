package petrobras.engenharia.fic.cronovisao.service;

import org.apache.commons.lang.StringEscapeUtils;

public abstract class XmlQuery {

	protected String where;
	
	protected abstract String getXmlBegin();
	
	protected abstract String getXmlEnd();
	
	public String getXml() {
		StringBuilder xml = new StringBuilder();
		
		xml.append(getXmlBegin())
		   .append("<max:WHERE>")
		   .append(StringEscapeUtils.escapeXml(where))
		   .append("</max:WHERE>")
		   .append(getXmlEnd());
		
		return xml.toString(); 
	}

	
}
