package petrobras.engenharia.fic.cronovisao.service.croninstance;

import petrobras.engenharia.fic.cronovisao.service.XmlQuery;


public class CronInstanceQuery extends XmlQuery {

	private StringBuilder xmlBegin;
	
	private StringBuilder xmlEnd;
	
	{
		xmlBegin = new StringBuilder();
		xmlBegin.append("<max:QueryMXCRONINSTANCE xmlns:max=\"http://www.ibm.com/maximo\" >")
				.append("<max:MXCRONINSTANCEQuery>");
				

		xmlEnd = new StringBuilder();
		xmlEnd.append("</max:MXCRONINSTANCEQuery>")
			  .append("</max:QueryMXCRONINSTANCE>");
	}
	

	public CronInstanceQuery(String where) {
		this.where = where;
	}
	
	@Override
	protected String getXmlBegin() {
		return xmlBegin.toString();
	}

	@Override
	protected String getXmlEnd() {
		return xmlEnd.toString();
	}

}
