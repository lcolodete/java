package petrobras.engenharia.fic.cronovisao.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;
import petrobras.engenharia.fic.cronovisao.service.jaxb.PreservQueryResponse;
import petrobras.engenharia.fic.cronovisao.service.scheduler.PreservQuery;
import petrobras.engenharia.fic.cronovisao.service.scheduler.PreservServiceDelegate;
import petrobras.engenharia.fic.cronovisao.util.DBConnectionUtil;

public class SchedulerHelper {
	
	private static final Logger LOGGER = Logger.getLogger(SchedulerHelper.class);
	
//	private IServiceDelegate<PreservQueryResponse, String> serviceDelegate = new FakePreservServiceDelegate();
	private IServiceDelegate<PreservQueryResponse, String> serviceDelegate = new PreservServiceDelegate();

	private Map<String, List<CronTaskInstance>> serversAndCrons = new HashMap<String, List<CronTaskInstance>>();
	
	/**
	 * Consulta a tabela TASKSCHEDULER no banco de dados e armazena em um map os servidores e instancias de crons associadas.
	 * 
	 * @param cronInstances
	 * @throws SQLException
	 */
	public void loadServersAndCrons(List<CronTaskInstance> cronInstances) throws SQLException {
		DataSource ficDS = DBConnectionUtil.getDataSource();
		
		Connection con = ficDS.getConnection();

		try {
			for (CronTaskInstance cronInstance : cronInstances) {
				String server = findServerByCronTaskInstance(con, cronInstance);
				
				if (server != null) {
					List<CronTaskInstance> cronsOfServerX = this.serversAndCrons.get(server);
					if (cronsOfServerX == null) {
						cronsOfServerX = new ArrayList<CronTaskInstance>();
						this.serversAndCrons.put(server, cronsOfServerX);
					}
					cronsOfServerX.add(cronInstance);
				}
			}
		} finally {
			if (con != null)
				con.close();
		}
	}
	
	private String findServerByCronTaskInstance(Connection con, CronTaskInstance cronInstance) throws SQLException {
		String serverName = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			LOGGER.info("Executando query...");
			
			ps = con.prepareStatement("select servername from TASKSCHEDULER where taskname = ?");
			ps.setString(1, cronInstance.getFullyQualifiedName());
			
			long begin = System.currentTimeMillis();
			rs = ps.executeQuery();
			long end = System.currentTimeMillis();
			double queryTime = (end-begin)/1000.0;
			
			LOGGER.info("Query executada em "+queryTime+"s");
			
			if (rs.next()) {
				serverName = rs.getString("servername");
				LOGGER.info("servername="+serverName);
			}
			
			return serverName;
			
		} catch (SQLException e) {
			LOGGER.error("Erro ao executar query", e);
			throw e;
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					LOGGER.error("Erro", e);
				}
			
			if (ps != null)
				try {
					ps.close();
				} catch (SQLException e) {
					LOGGER.error("Erro", e);
				}
		}
	}
	
	/**
	 * Acessa o map em memoria para obter a lista de crons associadas
	 * ao servidor dado como parametro.
	 * 
	 * @param serverPrefix servidor no qual estao rodando as crons
	 * @return a lista de crons associadas ao servidor informado
	 */
	public List<CronTaskInstance> getCronsPerServer(String serverPrefix) {
		List<CronTaskInstance> resultList = new ArrayList<CronTaskInstance>();

		resultList = this.serversAndCrons.get(getFullServerName(serverPrefix));
		
		return resultList;
	}
	
	private String getFullServerName(String prefix) {
		String fullServerName = null;
		
		if (prefix.equals("ESC")) {
			fullServerName = "tenerife.petrobras.biz/MXServerESC";
		} else if (prefix.equals("ESC1")) {
			fullServerName = "oviedo.petrobras.biz/MXServerESC1";
		} else if (prefix.equals("BIRT1")) {
			fullServerName = "oviedo.petrobras.biz/MXServerBIRT1";
		}
		
		return fullServerName;
	}
	
	/**
	 * Para cada cron da lista informada, chama um servi�o HTTP para buscar o valor do campo 
	 * Preservacoes a processar.
	 * <br>
	 * OBS: � feita uma chamada HTTP para cada objeto presente na lista.
	 * 
	 * @param crons lista de crons para as quais serao feitas as chamadas
	 */
	public void loadPreservacoesProcessarProximaExecucao(List<CronTaskInstance> crons) {
		for (CronTaskInstance cron : crons) {
			PreservQuery query = new PreservQuery(cron.getEmpreendimento(), cron.getDataFinalAnalise());
			
			Set<PreservQueryResponse> resultSet = this.serviceDelegate.processMessage(query.getXml());
			if (resultSet != null && !resultSet.isEmpty()) {
				PreservQueryResponse preservQueryResponse = resultSet.iterator().next();
				Integer numPreservacoesProcessar = Integer.valueOf(preservQueryResponse.getNumRecords());
				cron.setNumPreservacoesProcessar(numPreservacoesProcessar);
			}
		}
	}

}
