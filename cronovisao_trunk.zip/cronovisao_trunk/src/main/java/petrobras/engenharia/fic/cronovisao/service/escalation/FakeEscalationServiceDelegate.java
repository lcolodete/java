package petrobras.engenharia.fic.cronovisao.service.escalation;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.Escalation;
import petrobras.engenharia.fic.cronovisao.service.jaxb.EscalationQueryResponse;

public class FakeEscalationServiceDelegate implements IServiceDelegate<Escalation, String> {

	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = Logger.getLogger(FakeEscalationServiceDelegate.class);

	@Override
	public Set<Escalation> processMessage(String query) {

		logger.info("Servico sera executado. Conteudo da mensagem : ["+query+"]");
		
		List<Escalation> escalations = null;
		
		try {
			JAXBContext ctx = JAXBContext.newInstance(EscalationQueryResponse.class);
			Unmarshaller unmarshaller = ctx.createUnmarshaller();
			EscalationQueryResponse escalationQueryResponse = (EscalationQueryResponse) unmarshaller.unmarshal(this.getClass().getResourceAsStream("/escalationqueryresponse.xml"));
			
			escalations = escalationQueryResponse.getEscalations();
			
		} catch(JAXBException e) {
			
			Escalation esc1 = new Escalation();
			esc1.setActive("1");
			esc1.setEscalation("FIC_OCULTATTI");
			esc1.setInstancename("ESCFIC_OCULTATTI");
			esc1.setLastrun("2013-12-11T18:03:31-02:00");
			esc1.setObjectname("WORKORDER");
			esc1.setSchedule("10m,*,*,*,*,*,*,*,*,*");
			
			Escalation esc2 = new Escalation();
			esc2.setActive("1");
			esc2.setEscalation("FIC_RECEBITECRT");
			esc2.setInstancename("ESCFIC_RECEBITECRT");
			esc2.setLastrun("2013-12-12T02:00:03-02:00");
			esc2.setObjectname("WORKORDER");
			esc2.setSchedule("1d,0,0,2,*,*,*,*,*,*");
			
			Escalation esc3 = new Escalation();
			esc3.setActive("1");
			esc3.setEscalation("FIC_RPI");
			esc3.setInstancename("ESCFIC_RPI");
			esc3.setLastrun("2013-12-12T12:00:39-02:00");
			esc3.setObjectname("WORKORDER");
			esc3.setSchedule("1h,*,0,*,*,*,*,*,*,*");
			
			escalations = new ArrayList<Escalation>();
			
			escalations.add(esc1);
			escalations.add(esc2);
			escalations.add(esc3);
		}
		
		
		Set<Escalation> escalationSet = new TreeSet<Escalation>();
		
		for (Escalation esc : escalations) {
			
			if (logger.isDebugEnabled()) {
				logger.debug("escalation.active="+esc.getActive());
				logger.debug("escalation.escalation="+esc.getEscalation());
				logger.debug("escalation.instancename="+esc.getInstancename());
				logger.debug("escalation.lastrun="+esc.getLastrun());
				logger.debug("escalation.objectname="+esc.getObjectname());
				logger.debug("escalation.schedule="+esc.getSchedule());
			}
			
			escalationSet.add(esc);
		}

		return escalationSet;
	}

}
