package petrobras.engenharia.fic.cronovisao.service.scheduler;

import java.util.HashSet;
import java.util.Set;

import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.PreservQueryResponse;

public class FakePreservServiceDelegate implements IServiceDelegate<PreservQueryResponse, String> {

	private int count;
	
	@Override
	public Set<PreservQueryResponse> processMessage(String query) {
		PreservQueryResponse stubPreservQueryResponse = new PreservQueryResponse();
		stubPreservQueryResponse.setNumRecords("123"+count++);
		
		Set<PreservQueryResponse> resultSet = new HashSet<PreservQueryResponse>();
		resultSet.add(stubPreservQueryResponse);
		return resultSet;
	}

}
