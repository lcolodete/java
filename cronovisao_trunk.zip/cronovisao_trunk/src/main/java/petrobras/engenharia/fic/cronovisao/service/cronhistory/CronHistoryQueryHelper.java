package petrobras.engenharia.fic.cronovisao.service.cronhistory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;

public class CronHistoryQueryHelper {

	private static Configuracao config = Configuracao.getInstance();
	
	public static String buildWhere(String cronInstanceName, String cronTaskName) {
		
		if (cronInstanceName == null || cronInstanceName.isEmpty())
			throw new IllegalArgumentException("CronInstanceName n�o informado.");
		
		List<String> list = Arrays.asList(cronInstanceName);
		return CronHistoryQueryHelper.buildWhere(list, cronTaskName);
	}
	
	public static String buildWhere(List<String> cronInstanceNames, String cronTaskName) {
		
		if (cronTaskName == null || cronTaskName.isEmpty())
			throw new IllegalArgumentException("CronTaskName n�o informado.");
		
		String clausula = "(crontaskname='" + cronTaskName + "' and instancename='EMPREENDIMENTO' and activity='ACTION' and ENDTIME=(select max(ENDTIME) from CRONTASKHISTORY where crontaskname='" + cronTaskName + "' and instancename='EMPREENDIMENTO' and activity='ACTION' ) )";
		
		StringBuilder strWhere = new StringBuilder();
		for (String instanceName : cronInstanceNames) {
			if (strWhere.length() > 0) {
				strWhere.append(" or ");
			}
			
			strWhere.append(clausula.replaceAll("EMPREENDIMENTO", instanceName));
		}
		
		return strWhere.toString();
	}
	
	public static void main(String[] args) {
		
		//setup
		config.loadProperties("/app.properties");
		
		// Lendo c�digo de externaliza��o utilizado como diret�rio dos arquivos de configura��o da aplica��o no servidor 
		String codigoExternalizacao = config.getCodigoExternalizacao();
		
		// *********** ARQUIVOS DE CONFIGURA��O EXTERNALIZADOS *********** 
		
		// Lendo arquivo de configura��o CONFIG.PROPERTIES
		config.loadProperties(String.format("/%s/config.properties", codigoExternalizacao));

		
		List<String> emps = new ArrayList<String>();
		emps.add("CMTL");
		emps.add("COMPERJ-ETAPA1-IEAROM");
		emps.add("COMPERJ-ETAPA1-IEINTEM");
		
		System.out.println(buildWhere(emps, config.getPmwogenCrontaskname()));
		System.out.println(buildWhere(emps, ""));
	}
}
