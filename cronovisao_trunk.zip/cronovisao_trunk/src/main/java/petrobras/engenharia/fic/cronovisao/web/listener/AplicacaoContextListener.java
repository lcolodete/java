package petrobras.engenharia.fic.cronovisao.web.listener;

import java.net.URL;
import java.text.DateFormat;
import java.util.Date;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;

public class AplicacaoContextListener implements ServletContextListener {

	private static final Logger logger = LogManager.getLogger(AplicacaoContextListener.class);

	@Override
	public void contextInitialized(ServletContextEvent contextEvent) {

		loadProperties();

		startLog4j();
		
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
		logger.info("***************************************************");
		logger.info("**** APLICACAO INICIADA EM " + df.format(new Date()) + " ****");
		logger.info("***************************************************");
	}

	private void loadProperties() {
		Configuracao config = Configuracao.getInstance();
		
		config.loadProperties("/app.properties");
		
		// Lendo c�digo de externaliza��o utilizado como diret�rio dos arquivos de configura��o da aplica��o no servidor 
		String codigoExternalizacao = config.getCodigoExternalizacao();
		
		// *********** ARQUIVOS DE CONFIGURA��O EXTERNALIZADOS *********** 
		
		// Lendo arquivo de configura��o CONFIG.PROPERTIES
		config.loadProperties(String.format("/%s/config.properties", codigoExternalizacao));
	}
	
    private void startLog4j() {

    	Configuracao config = Configuracao.getInstance();
    	
        String log4JPath = config.getLog4JPath();

        URL resource = this.getClass().getResource(log4JPath);

        if (resource != null) {
            PropertyConfigurator.configure(resource);
        } else {
            System.err.println("Log4j: NAO FOI POSSIVEL ENCONTAR O ARQUIVO \""
                    + log4JPath + "\"");
            BasicConfigurator.configure();
        }
    }
    
	@Override
	public void contextDestroyed(ServletContextEvent contextEvent) {
	}

	
}
