package petrobras.engenharia.fic.cronovisao.service.scheduler;

import java.text.DateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.service.XmlQuery;
import petrobras.engenharia.fic.cronovisao.util.DateUtil;

public class PreservQuery extends XmlQuery {

	private static final Logger LOGGER = Logger.getLogger(PreservQuery.class);
	
	private StringBuilder xmlBegin;
	private StringBuilder xmlEnd;
	
	{
		xmlBegin = new StringBuilder();
		xmlBegin.append("<max:QueryMXPRESERV xmlns:max=\"http://www.ibm.com/maximo\" maxItems=\"1\" >")
				.append("<max:MXPRESERVQuery>");
				

		xmlEnd = new StringBuilder();
		xmlEnd.append("</max:MXPRESERVQuery>")
			  .append("</max:QueryMXPRESERV>");
	}

	/**
	 * 
	 * @param empreendimento
	 * @param dataFinalAnalise
	 */
	public PreservQuery(String empreendimento, String dataFinalAnalise) {
		this.buildWhere(empreendimento, dataFinalAnalise);
	}

	private void buildWhere(String empreendimento, String dataFinalAnalise) {
		StringBuilder sb = new StringBuilder();
		sb.append("siteid = '")
		  .append(empreendimento)
		  .append("' AND ")
		  .append("status = 'ATIVO'")
		  .append(" AND ")
		  .append("(pmcounter = 0 ")
		  .append( String.format("OR (fic_data_prox <= %s ", dataFinalAnalise) )
		  .append("OR fic_data_prox IS NULL) ")
		  .append("OR EXISTS ")
		  .append("(SELECT 1 ")
		  .append("FROM fic_preserv ")
		  .append("WHERE siteid = pm.siteid ")
		  .append("AND fic_prvnoreal = 1 ")
		  .append("AND assetnum = pm.assetnum))");
		
		this.where = sb.toString();
		
		if (LOGGER.isDebugEnabled())
			LOGGER.debug("WHERE=["+this.where+"]");
	}
	
	public PreservQuery(String empreendimento, Date dataFinalAnalise) {
		DateFormat df = DateFormat.getDateInstance(DateFormat.DEFAULT, DateUtil.LOCALE_PT_BR);
		String dateStr = df.format(dataFinalAnalise);
		
		StringBuilder toDateBuilder = new StringBuilder();
		toDateBuilder.append("TO_DATE('")
		  			 .append(dateStr)
		  			 .append("' , 'DD/MM/YYYY')");

		this.buildWhere(empreendimento, toDateBuilder.toString());
	}
	
	@Override
	protected String getXmlBegin() {
		return this.xmlBegin.toString();
	}

	@Override
	protected String getXmlEnd() {
		return this.xmlEnd.toString();
	}

}
