package petrobras.engenharia.fic.cronovisao.service.croninstance;

import java.util.Set;
import java.util.TreeSet;

import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

public class FakeCronInstanceServiceDelegate implements IServiceDelegate<CronTaskInstance, String> {

	private static final long serialVersionUID = 1L;

	@Override
	public Set<CronTaskInstance> processMessage(String query) {

		CronTaskInstance cronTaskInstance = new CronTaskInstance();
		cronTaskInstance.setActive("1");
		cronTaskInstance.setCrontaskinstanceid("1784");
		cronTaskInstance.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance.setInstancename("COMPERJ-ETAPA1-TIC");
		cronTaskInstance.setSchedule("1w,0,0,3,*,*,*,6,*,*");
		
		CronTaskInstance cronTaskInstance2 = new CronTaskInstance();
		cronTaskInstance2.setActive("1");
		cronTaskInstance2.setCrontaskinstanceid("1785");
		cronTaskInstance2.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance2.setInstancename("COMPERJ-ETAPA1-IEUT");
		cronTaskInstance2.setSchedule("1w,0,0,3,*,*,*,6,*,*");
		
		CronTaskInstance cronTaskInstance3 = new CronTaskInstance();
		cronTaskInstance3.setActive("1");
		cronTaskInstance3.setCrontaskinstanceid("1158");
		cronTaskInstance3.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance3.setInstancename("IERENEST-IEPQSPE-001");
		cronTaskInstance3.setSchedule("1w,0,0,1,*,*,*,3,*,*");
		
		CronTaskInstance cronTaskInstance4 = new CronTaskInstance();
		cronTaskInstance4.setActive("1");
		cronTaskInstance4.setCrontaskinstanceid("1318");
		cronTaskInstance4.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance4.setInstancename("IETEG-ARLA32");
		cronTaskInstance4.setSchedule("1w,0,15,1,*,*,*,3,*,*");
		

//		CronTaskInstance cronTaskInstance = new CronTaskInstance();
//		cronTaskInstance.setActive("1");
//		cronTaskInstance.setAutoremoval("0");
//		cronTaskInstance.setCrontaskinstanceid("1784");
//		cronTaskInstance.setCrontaskname("PMWoGenCronTask");
//		cronTaskInstance.setDescription("Tarefa Cron de PmWogen");
//		cronTaskInstance.setInstancename("COMPERJ-ETAPA1-TIC");
//		cronTaskInstance.setKeephistory("1");
//		cronTaskInstance.setMaxhistory("1000");
//		cronTaskInstance.setReloadreqtime("2012-03-30T16:46:40-03:00");
//		cronTaskInstance.setRunasuserid("PRV_COMPERJ-ETAPA1-TIC");
//		cronTaskInstance.setSchedule("1w,0,0,3,*,*,*,7,*,*");
//		
//		CronTaskInstance cronTaskInstance2 = new CronTaskInstance();
//		cronTaskInstance2.setActive("1");
//		cronTaskInstance2.setAutoremoval("0");
//		cronTaskInstance2.setCrontaskinstanceid("1785");
//		cronTaskInstance2.setCrontaskname("PMWoGenCronTask");
//		cronTaskInstance2.setDescription("Tarefa Cron de PmWogen");
//		cronTaskInstance2.setInstancename("COMPERJ-ETAPA1-IEUT");
//		cronTaskInstance2.setKeephistory("1");
//		cronTaskInstance2.setMaxhistory("1000");
//		cronTaskInstance2.setReloadreqtime("2012-03-30T16:46:40-03:00");
//		cronTaskInstance2.setRunasuserid("PRV_COMP_IEUT");
//		cronTaskInstance2.setSchedule("1w,0,0,3,*,*,*,7,*,*");
//		
//		CronTaskInstance cronTaskInstance3 = new CronTaskInstance();
//		cronTaskInstance3.setActive("1");
//		cronTaskInstance3.setAutoremoval("0");
//		cronTaskInstance3.setCrontaskinstanceid("1158");
//		cronTaskInstance3.setCrontaskname("PMWoGenCronTask");
//		cronTaskInstance3.setDescription("Tarefa Cron de PmWogen");
//		cronTaskInstance3.setInstancename("IERENEST-IEPQSPE-001");
//		cronTaskInstance3.setKeephistory("1");
//		cronTaskInstance3.setMaxhistory("1000");
//		cronTaskInstance3.setReloadreqtime("2012-03-30T16:46:40-03:00");
//		cronTaskInstance3.setRunasuserid("PRV_IERENEST-IEPQSPE-001");
//		cronTaskInstance3.setSchedule("1w,0,0,1,*,*,*,2,*,*");
//		
//		CronTaskInstance cronTaskInstance4 = new CronTaskInstance();
//		cronTaskInstance4.setActive("1");
//		cronTaskInstance4.setAutoremoval("0");
//		cronTaskInstance4.setCrontaskinstanceid("1318");
//		cronTaskInstance4.setCrontaskname("PMWoGenCronTask");
//		cronTaskInstance4.setDescription("Tarefa Cron de PmWogen");
//		cronTaskInstance4.setInstancename("IETEG-ARLA32");
//		cronTaskInstance4.setKeephistory("1");
//		cronTaskInstance4.setMaxhistory("1000");
//		cronTaskInstance4.setReloadreqtime("2012-03-30T16:46:40-03:00");
//		cronTaskInstance4.setRunasuserid("PRV_IETEG-ARLA32--001");
//		cronTaskInstance4.setSchedule("1w,0,15,1,*,*,*,1,*,*");
//		
//		CronTaskInstance cronTaskInstance5 = new CronTaskInstance();
//		cronTaskInstance5.setActive("1");
//		cronTaskInstance5.setAutoremoval("0");
//		cronTaskInstance5.setCrontaskinstanceid("1318");
//		cronTaskInstance5.setCrontaskname("PMWoGenCronTask");
//		cronTaskInstance5.setDescription("Tarefa Cron de PmWogen");
//		cronTaskInstance5.setInstancename("IETEG-QUINTA");
//		cronTaskInstance5.setKeephistory("1");
//		cronTaskInstance5.setMaxhistory("1000");
//		cronTaskInstance5.setReloadreqtime("2012-03-30T16:46:40-03:00");
//		cronTaskInstance5.setRunasuserid("PRV_IETEG-QUINTA--001");
//		cronTaskInstance5.setSchedule("1w,0,15,1,*,*,*,5,*,*");
//		
//		CronTaskInstance cronTaskInstance6 = new CronTaskInstance();
//		cronTaskInstance6.setActive("1");
//		cronTaskInstance6.setAutoremoval("0");
//		cronTaskInstance6.setCrontaskinstanceid("1318");
//		cronTaskInstance6.setCrontaskname("PMWoGenCronTask");
//		cronTaskInstance6.setDescription("Tarefa Cron de PmWogen");
//		cronTaskInstance6.setInstancename("IETEG-SEXTA");
//		cronTaskInstance6.setKeephistory("1");
//		cronTaskInstance6.setMaxhistory("1000");
//		cronTaskInstance6.setReloadreqtime("2012-03-30T16:46:40-03:00");
//		cronTaskInstance6.setRunasuserid("PRV_IETEG-SEXTA--001");
//		cronTaskInstance6.setSchedule("1w,0,15,1,*,*,*,6,*,*");
//		
//		CronTaskInstance cronTaskInstance7 = new CronTaskInstance();
//		cronTaskInstance7.setActive("1");
//		cronTaskInstance7.setAutoremoval("0");
//		cronTaskInstance7.setCrontaskinstanceid("1318");
//		cronTaskInstance7.setCrontaskname("PMWoGenCronTask");
//		cronTaskInstance7.setDescription("Tarefa Cron de PmWogen");
//		cronTaskInstance7.setInstancename("IETEG-SABADO");
//		cronTaskInstance7.setKeephistory("1");
//		cronTaskInstance7.setMaxhistory("1000");
//		cronTaskInstance7.setReloadreqtime("2012-03-30T16:46:40-03:00");
//		cronTaskInstance7.setRunasuserid("PRV_IETEG-SAB--001");
//		cronTaskInstance7.setSchedule("1w,0,15,1,*,*,*,7,*,*");
		
		
		Set<CronTaskInstance> cronTaskSet = new TreeSet<CronTaskInstance>();
		cronTaskSet.add(cronTaskInstance);
		cronTaskSet.add(cronTaskInstance2);
		cronTaskSet.add(cronTaskInstance3);
		cronTaskSet.add(cronTaskInstance4);
//		cronTaskSet.add(cronTaskInstance5);
//		cronTaskSet.add(cronTaskInstance6);
//		cronTaskSet.add(cronTaskInstance7);


		return cronTaskSet;

	}

}
