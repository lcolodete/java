package petrobras.engenharia.fic.cronovisao.managedbean.scheduler;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import petrobras.engenharia.fic.cronovisao.helper.AgendaHelper;
import petrobras.engenharia.fic.cronovisao.helper.SchedulerHelper;
import petrobras.engenharia.fic.cronovisao.managedbean.pmwogen.AgendaBean;
import petrobras.engenharia.fic.cronovisao.model.Dia;
import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ViewScoped
@ManagedBean
public class SchedulerBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = Logger.getLogger(SchedulerBean.class); 

	private DiaDaSemana diaSelecionado;
	
	private DiaDaSemana[] dias;
	
	private AgendaBean agendaBean;
	
	private DataTable dataTableMXServerESC;
	private DataTable dataTableMXServerESC1; 
	private DataTable dataTableMXServerBIRT1; 
	
	private List<CronTaskInstance> mxServerESCList;
	private List<CronTaskInstance> mxServerESC1List;
	private List<CronTaskInstance> mxServerBIRT1List;
	
	public SchedulerBean() {
	}

	/**
	 * @return the dataTableMXServerESC
	 */
	public DataTable getDataTableMXServerESC() {
		return dataTableMXServerESC;
	}

	/**
	 * @param dataTableMXServerESC the dataTableMXServerESC to set
	 */
	public void setDataTableMXServerESC(DataTable dataTableMXServerESC) {
		this.dataTableMXServerESC = dataTableMXServerESC;
	}

	/**
	 * @return the dataTableMXServerESC1
	 */
	public DataTable getDataTableMXServerESC1() {
		return dataTableMXServerESC1;
	}

	/**
	 * @param dataTableMXServerESC1 the dataTableMXServerESC1 to set
	 */
	public void setDataTableMXServerESC1(DataTable dataTableMXServerESC1) {
		this.dataTableMXServerESC1 = dataTableMXServerESC1;
	}

	public DataTable getDataTableMXServerBIRT1() {
		return dataTableMXServerBIRT1;
	}

	public void setDataTableMXServerBIRT1(DataTable dataTableMXServerBIRT1) {
		this.dataTableMXServerBIRT1 = dataTableMXServerBIRT1;
	}

	@PostConstruct
	public void init() {
		this.dias = DiaDaSemana.values();
		
		FacesContext context = FacesContext.getCurrentInstance();
		Application app = context.getApplication();
		this.agendaBean = app.evaluateExpressionGet(context, "#{agendaBean}", AgendaBean.class);
	}
	
	public void carregarLista() {
		
		logger.debug(">>>>>>>>>>>>>>>>> carregarLista()");
		logger.debug(">>>>>>>>>>>>>>>>> dia="+getDiaSelecionado());
		
		logger.debug(">>>>>>>>>>>>>>>>> ANTES: sortBy="+this.dataTableMXServerESC.getValueExpression("sortBy"));
		
		this.dataTableMXServerESC.setValueExpression("sortBy", null);
		this.dataTableMXServerESC1.setValueExpression("sortBy", null);
		this.dataTableMXServerBIRT1.setValueExpression("sortBy", null);
		
		logger.debug(">>>>>>>>>>>>>>>>> DEPOIS: sortBy="+this.dataTableMXServerESC.getValueExpression("sortBy"));
		
		this.mxServerESCList = null;
		this.mxServerESC1List = null;
		this.mxServerBIRT1List = null;

		List<Dia> agenda = this.agendaBean.getProgramacaoSemanal();
		
		List<CronTaskInstance> cronInstances = AgendaHelper.listaCronTasksAtivasDoDia(agenda, this.diaSelecionado);
		
		if (cronInstances != null && cronInstances.size() > 0) {

			logger.debug("Instancias ativas do dia: "+this.diaSelecionado);
			
			for (CronTaskInstance cronInstance : cronInstances) {
				logger.debug("-> "+cronInstance.getInstancename());
			}
			
			SchedulerHelper helper = new SchedulerHelper();
			
			helper.loadPreservacoesProcessarProximaExecucao(cronInstances);
			
			try {
				helper.loadServersAndCrons(cronInstances);
				this.mxServerESCList = helper.getCronsPerServer("ESC");
				this.mxServerESC1List = helper.getCronsPerServer("ESC1");
				this.mxServerBIRT1List = helper.getCronsPerServer("BIRT1");
			} catch (SQLException e) {
				logger.error("Erro ao acessar banco de dados", e);
			}
		}
	}
	

	public List<CronTaskInstance> getMxServerESCList() {
		return mxServerESCList;
	}

	public List<CronTaskInstance> getMxServerESC1List() {
		return mxServerESC1List;
	}

	public List<CronTaskInstance> getMxServerBIRT1List() {
		return mxServerBIRT1List;
	}

	public DiaDaSemana[] getDias() {
		return dias;
	}

	public DiaDaSemana getDiaSelecionado() {
		return diaSelecionado;
	}

	public void setDiaSelecionado(DiaDaSemana diaSelecionado) {
		this.diaSelecionado = diaSelecionado;
	}
	
}
