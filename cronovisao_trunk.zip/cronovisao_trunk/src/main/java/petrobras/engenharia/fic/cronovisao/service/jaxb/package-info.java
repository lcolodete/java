@XmlSchema(namespace="http://www.ibm.com/maximo", elementFormDefault = XmlNsForm.QUALIFIED)

package petrobras.engenharia.fic.cronovisao.service.jaxb;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
