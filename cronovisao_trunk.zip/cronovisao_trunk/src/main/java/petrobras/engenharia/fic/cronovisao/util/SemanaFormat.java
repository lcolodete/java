package petrobras.engenharia.fic.cronovisao.util;

public class SemanaFormat extends ScheduleFormat {

	public SemanaFormat(String schedule) {
		super(schedule);
		this.textoFrequenciaPrincipal = "semana";
	}
	
	/**
	 * Formata a string schedule para exibi��o em tela.
	 * O foco � exibir a frequencia e o hor�rio de execu��o.
	 * <br/>
	 * <br/>
	 * Exemplo:<br/>
	 * schedule=<code>1w,0,0,3,*,*,*,6,*,*</code>
	 * <br/>
	 * <br/>
	 * O m�todo produz a seguinte String:
	 * <br/>
	 * <br/>
	 * <code>
	 * . A cada 1 semana<br/>
	 * . �s 03:00
	 * </code>
	 * <br/>
	 * <br/>
	 * Regra geral do formato:
	 * <br/>
	 * <br/>
	 * <code>
	 * . A cada N semana (se N > 1, escrever semanas)<br/>
	 * . �s HH:mm:ss (omitir o ss se igual a 0)
	 * </code>
	 * 
	 * 
	 * @return String schedule formatada
	 */
	@Override
	public String format() {

		String formattedStr = "";
		
		//PARTE 1: Frequencia semanal
		
		StringBuilder formattedSb = new StringBuilder();
		String frequenciaPrincipal = formatFrequenciaPrincipal();
		
		//PARTE 2: Hor�rio

		String hora = formatHora();
		
		formattedStr = formattedSb.append(frequenciaPrincipal)
								  .append("<br/>")	// pula linha
								  .append(hora)
								  .toString();
		
		return formattedStr;
	}

}
