package petrobras.engenharia.fic.cronovisao.util;


public class ScheduleUtil {

	/**
	 * Retorna o inteiro que representa o dia da semana.
	 * 
	 * @param schedule
	 * @return inteiro que representa o dia da semana.<br/>
	 * 		   Retorna null caso nao exista o inteiro na String (programacao nao � semanal) 
	 */
	public static Integer getDiaSemanaFromSchedule(String schedule) {

		Integer intDiaSemana = null;
		
		String[] scheduleItems = schedule.split(",");
		
		String diaDaSemana = scheduleItems[7];
		
		if (!"*".equals(diaDaSemana)) {
			intDiaSemana = Integer.valueOf(diaDaSemana);
		}
		
		return intDiaSemana;
	}

	public static boolean isFrequenciaSemanal(String schedule) {
		return ScheduleUtil.isFrequenciaNSemanal(schedule, 1);
	}
	
	public static boolean isFrequenciaQuinzenal(String schedule) {
		return ScheduleUtil.isFrequenciaNSemanal(schedule, 2);
	}
	
	public static boolean isProgramacaoSemanal(String schedule) {
		boolean result = false;
		
		String[] tokens = schedule.split(",");
		
		String frequenciaPrincipal = tokens[0];

		String caracterFrequencia = ScheduleUtil.getCaracterFrequenciaPrincipal(frequenciaPrincipal);

		if (caracterFrequencia.equals(ScheduleFormat.SEMANA)) {
			result = true;
		}
		
		return result;
	}
	
	private static boolean isFrequenciaNSemanal(String schedule, int n) {
		boolean result = false;
		
		String[] scheduleTokens = schedule.split(",");
		
		String frequenciaPrincipal = scheduleTokens[0];

		String caracterFrequencia = ScheduleUtil.getCaracterFrequenciaPrincipal(frequenciaPrincipal);
		
		Integer numFrequencia = ScheduleUtil.getNumFrequenciaPrincipal(frequenciaPrincipal);

		if (caracterFrequencia.equals(ScheduleFormat.SEMANA) && numFrequencia == n) {
			result = true;
		}
		
		return result;
	}
	
	public static String getCaracterFrequenciaPrincipal(String frequenciaPrincipal) {
		//TODO Refactor : ver ScheduleFormat (tem mais 2 ocorrencias la)
		// pega o �ltimo caracter da string frequenciaPrincipal
		String caracterFrequencia = frequenciaPrincipal.charAt(frequenciaPrincipal.length() - 1) + "";
		return caracterFrequencia;
	}
	
	public static Integer getNumFrequenciaPrincipal(String frequenciaPrincipal) {
		return Integer.valueOf(frequenciaPrincipal.substring(0, frequenciaPrincipal.length()-1));
	}
	
}
