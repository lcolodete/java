package petrobras.engenharia.fic.cronovisao.util;

import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;

public class MesFormat extends ScheduleFormat {

	protected MesFormat(String schedule) {
		super(schedule);
		this.textoFrequenciaPrincipal = "mes";
	}

	/**
	 * Exemplo de campo schedule: <code>2M,0,0,15,1,*,*,*,*,*</code>
	 * <br/>
	 * <br/>
	 * <code>
	 * 2M,  -> A cada 2 meses<br/>
	 * 0,   -> Segundo<br/>
	 * 0,   -> Minuto<br/>
	 * 15,  -> Hora: �s 15h<br/>
	 * 1,   -> Dia do mes: No dia 01<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *    -> Nao usado
	 * </code>
	 * 
	 * <br/>
	 * <br/>
	 * Outro exemplo: <code>2M,0,0,7,*,*,*,4,1,*</code> 
	 * <br/>
	 * <br/>
	 * <code>
	 * 2M,  -> A cada 2 meses<br/>
	 * 0,   -> Segundo<br/>
	 * 0,   -> Minuto<br/>
	 * 7,   -> Hora: �s 7h<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * 4,   -> Dia da semana: �s quartas-feiras (Domingo=1, ..., S�bado=7)<br/>
	 * 1,   -> Primeiro ou �ltimo: Primeiro=0, �ltimo=1<br/>
	 * *    -> Nao usado
	 * </code>
	 */
	@Override
	public String format() {
		String formattedStr = "";
		
		//PARTE 1: Frequencia
		
		StringBuilder formattedSb = new StringBuilder();
		String frequenciaPrincipal = formatFrequenciaPrincipal();
		
		//PARTE 2: Dia
		// Sao duas possibilidades (XOR):
		// a) Dia do mes OU
		// b) Dia da semana + (Primeiro ou Ultimo do mes)
		
		StringBuilder diaSb = new StringBuilder();
		
		String[] scheduleTokens = this.schedule.split(",");
		String diaDoMes = scheduleTokens[4];
		
		if (!"*".equals(diaDoMes)) {
			//Op��o a
			diaSb.append(". No dia ")
				 .append(diaDoMes);
		} else {
			//Op��o b
			String diaDaSemana = scheduleTokens[7];
			String primeiroUltimo = scheduleTokens[8];
			
			diaSb.append(". No ");
			if (primeiroUltimo.equals(ScheduleFormat.PRIMEIRO)) {
				diaSb.append("primeiro ");
			} else {
				diaSb.append("�ltimo ");
			}
			
			//a partir do inteiro que representa o dia da semana, descobre qual o enum correspondente
			for (DiaDaSemana diaEnum : DiaDaSemana.values()) {
				if (diaEnum.getId().equals(Integer.valueOf(diaDaSemana))) {
					diaSb.append(diaEnum.toString())
						 .append(" do m�s");
					break;
				}
			}
			
		}
		
		//PARTE 3: Hor�rio

		String hora = formatHora();
		
		formattedStr = formattedSb.append(frequenciaPrincipal)
								  .append("<br/>")	// pula linha
								  .append(diaSb)
								  .append("<br/>")	// pula linha
								  .append(hora)
								  .toString();
		
		return formattedStr;
	}

}
