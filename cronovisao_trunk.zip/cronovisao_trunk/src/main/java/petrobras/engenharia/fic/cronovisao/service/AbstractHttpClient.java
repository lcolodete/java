package petrobras.engenharia.fic.cronovisao.service;

import java.io.Serializable;
import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.config.Configuracao;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.LoggingFilter;

public abstract class AbstractHttpClient implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = LogManager.getLogger(AbstractHttpClient.class);

	private Configuracao configuracao = Configuracao.getInstance();

	protected String servicePath;
	
	private WebResource service; 
			
	protected AbstractHttpClient(String servicePath) {
		this.servicePath = servicePath;
		init();
	}
	
	private void init() {
		
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);

		client.addFilter(new ChangeResponseMediaTypeFilter());
		if (logger.isDebugEnabled()) {
			client.addFilter(new LoggingFilter());
		}

		service = client.resource(getBaseURI());
	}
	
	protected Builder getBuilder() {
		Builder builder = service.path("os").path( getServicePath() )
				.accept(MediaType.APPLICATION_XML)
				.header("MAXAUTH", ServiceUtils.buildAuthHeader());
		
		return builder;
	}

	protected String getServicePath() {
		return servicePath;
	}

	private URI getBaseURI() {
		return UriBuilder.fromUri( configuracao.getUriBaseServico() ).build();
	}

}
