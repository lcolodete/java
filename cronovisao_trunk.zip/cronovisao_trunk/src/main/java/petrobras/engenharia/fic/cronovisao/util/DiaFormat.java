package petrobras.engenharia.fic.cronovisao.util;

public class DiaFormat extends ScheduleFormat {

	protected DiaFormat(String schedule) {
		super(schedule);
		this.textoFrequenciaPrincipal = "dia";
	}

	/**
	 * Exemplo de campo schedule: <code>4d,0,0,18,*,*,*,*,*,*</code>
	 * <br/>
	 * <br/>
	 * <code>
	 * 4d,  -> A cada 4 dias<br/>
	 * 0,   -> Segundo<br/>
	 * 0,   -> Minuto<br/>
	 * 18,  -> Hora: �s 18h<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *    -> Nao usado
	 * </code>
	 * 
	 */
	@Override
	public String format() {
		String formattedStr = "";
		
		StringBuilder formattedSb = new StringBuilder();
		
		//PARTE 1: Frequencia
		
		String frequenciaPrincipal = formatFrequenciaPrincipal();
		
		//PARTE 2: Hor�rio

		String hora = formatHora();
		
		formattedStr = formattedSb.append(frequenciaPrincipal)
								  .append("<br/>")	// pula linha
								  .append(hora)
								  .toString();
		
		return formattedStr;
	}

}
