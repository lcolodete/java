package petrobras.engenharia.fic.cronovisao.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import petrobras.engenharia.fic.cronovisao.model.AgendaPmWoGen;
import petrobras.engenharia.fic.cronovisao.model.Dia;
import petrobras.engenharia.fic.cronovisao.model.DiaDaSemana;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;
import petrobras.engenharia.fic.cronovisao.util.ScheduleUtil;

public class AgendaHelper {

	private static final Logger LOGGER = Logger.getLogger(AgendaHelper.class); 

	/**
	 * Cria a agenda semanal a partir da cole��o recebida.
	 * A agenda � uma lista de objetos <code>Dia</code>.<br>
	 * Cada objeto <code>Dia</code> possui uma cole��o de <code>CronTaskInstance</code>. Essa cole��o � a 
	 * lista de cron tasks que executam no dia da semana representado pelo <code>Dia</code>.<br>
	 *<br>
	 * - Algoritmo:<br>
	 * Para cada cronInstance c<br>
	 * 	pega o campo schedule e obtem o inteiro que representa o dia da semana, i<br>
	 * 	faz intToDia.get(i) e obtem o objeto <code>Dia</code>, d<br>
	 * 	faz <code>d.addCronInstance(c)</code><br>
	 * 
	 * Adiciona cada objeto <code>Dia</code> na lista de retorno
	 * 
	 * 
	 * @param cronInstanceSet cole��o de cron tasks
	 * @return a agenda
	 */
	public static AgendaPmWoGen criaAgenda(Set<CronTaskInstance> cronInstanceSet) {

		AgendaPmWoGen agenda = new AgendaPmWoGen();
		
		Map<Integer, Dia> intToDia = new HashMap<Integer, Dia>();
		
		for (DiaDaSemana diaEnum : DiaDaSemana.values()) {
			intToDia.put(diaEnum.getId(), new Dia(diaEnum));
		}

		List<CronTaskInstance> outrasProgramacoes = new ArrayList<CronTaskInstance>();
		
		for (CronTaskInstance c : cronInstanceSet) {
			if (ScheduleUtil.isProgramacaoSemanal(c.getSchedule())) {
				Integer intDiaSemana = ScheduleUtil.getDiaSemanaFromSchedule(c.getSchedule());
				Dia dia = intToDia.get(intDiaSemana);
				dia.addCronInstance(c);
			} else {
				outrasProgramacoes.add(c);
			}
		}
		
		List<Dia> listDias = new ArrayList<Dia>(intToDia.values());
		
		agenda.setProgramacaoSemanal(listDias);
		agenda.setOutrasProgramacoes(outrasProgramacoes);
		
		return agenda;
	}
	
	/**
	 * Acessa a agenda e retorna as crons do dia informado.
	 * 
	 * @param agenda
	 * @param dia
	 * @param activeOnly se true, retorna somente as crons ativas; se false, retorna todas.
	 * @return
	 */
	public static List<CronTaskInstance> listaCronTasksDoDia(List<Dia> agenda, DiaDaSemana dia, boolean activeOnly) {
		List<CronTaskInstance> listCronInstances = null;
		
		if (agenda != null) {
			Dia diaEncontrado = null;

			for (int i=0; i<agenda.size(); i++) {
				if (agenda.get(i).getDia().equals(dia)) {
					diaEncontrado = agenda.get(i);
					break;
				}
			}
			
			if (diaEncontrado != null) {
				listCronInstances = diaEncontrado.getCronInstances();
				if (activeOnly) {
					List<CronTaskInstance> apenasAtivas = new ArrayList<CronTaskInstance>();
					for (CronTaskInstance c : listCronInstances) {
						if (c.isCronActive()) {
							apenasAtivas.add(c);
						}
					}
					listCronInstances = apenasAtivas;
				}
			}
		}
		
		return listCronInstances;
	}

	public static List<CronTaskInstance> listaCronTasksAtivasDoDia(List<Dia> agenda, DiaDaSemana dia) {
		return AgendaHelper.listaCronTasksDoDia(agenda, dia, true);
	}
	
	public static void main(String[] args) {
		CronTaskInstance cronTaskInstance = new CronTaskInstance();
		cronTaskInstance.setActive("1");
		cronTaskInstance.setCrontaskinstanceid("1784");
		cronTaskInstance.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance.setInstancename("COMPERJ-ETAPA1-TIC");
		cronTaskInstance.setSchedule("1w,0,0,3,*,*,*,7,*,*");
		
		CronTaskInstance cronTaskInstance2 = new CronTaskInstance();
		cronTaskInstance2.setActive("1");
		cronTaskInstance2.setCrontaskinstanceid("1785");
		cronTaskInstance2.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance2.setInstancename("COMPERJ-ETAPA1-IEUT");
		cronTaskInstance2.setSchedule("1w,0,0,3,*,*,*,7,*,*");
		
		CronTaskInstance cronTaskInstance3 = new CronTaskInstance();
		cronTaskInstance3.setActive("1");
		cronTaskInstance3.setCrontaskinstanceid("1158");
		cronTaskInstance3.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance3.setInstancename("IERENEST-IEPQSPE-001");
		cronTaskInstance3.setSchedule("1w,0,0,1,*,*,*,2,*,*");
		
		CronTaskInstance cronTaskInstance4 = new CronTaskInstance();
		cronTaskInstance4.setActive("1");
		cronTaskInstance4.setCrontaskinstanceid("1318");
		cronTaskInstance4.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance4.setInstancename("IETEG-ARLA32");
		cronTaskInstance4.setSchedule("1w,0,15,1,*,*,*,1,*,*");
		
		CronTaskInstance cronTaskInstance5 = new CronTaskInstance();
		cronTaskInstance5.setActive("1");
		cronTaskInstance5.setCrontaskinstanceid("1318");
		cronTaskInstance5.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance5.setInstancename("IETEG-QUINTA");
		cronTaskInstance5.setSchedule("1w,0,15,1,*,*,*,5,*,*");
		
		CronTaskInstance cronTaskInstance6 = new CronTaskInstance();
		cronTaskInstance6.setActive("1");
		cronTaskInstance6.setCrontaskinstanceid("1318");
		cronTaskInstance6.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance6.setInstancename("IETEG-SEXTA");
		cronTaskInstance6.setSchedule("1w,0,15,1,*,*,*,6,*,*");
		
		CronTaskInstance cronTaskInstance7 = new CronTaskInstance();
		cronTaskInstance7.setActive("1");
		cronTaskInstance7.setCrontaskinstanceid("1318");
		cronTaskInstance7.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance7.setInstancename("IETEG-SABADO");
		cronTaskInstance7.setSchedule("1w,0,15,1,*,*,*,7,*,*");

		CronTaskInstance cronTaskInstance8 = new CronTaskInstance();
		cronTaskInstance8.setActive("1");
		cronTaskInstance8.setCrontaskinstanceid("1318");
		cronTaskInstance8.setCrontaskname("PMWoGenCronTask");
		cronTaskInstance8.setInstancename("IETEG-HORA");
		cronTaskInstance8.setSchedule("3h,*,25,*,*,*,*,*,*,*");
		
		
		Set<CronTaskInstance> cronTaskSet = new HashSet<CronTaskInstance>();
		cronTaskSet.add(cronTaskInstance);
		cronTaskSet.add(cronTaskInstance2);
		cronTaskSet.add(cronTaskInstance3);
		cronTaskSet.add(cronTaskInstance4);
		cronTaskSet.add(cronTaskInstance5);
		cronTaskSet.add(cronTaskInstance6);
		cronTaskSet.add(cronTaskInstance7);
		cronTaskSet.add(cronTaskInstance8);

		AgendaPmWoGen agenda = criaAgenda(cronTaskSet);
		List<Dia> dias = agenda.getProgramacaoSemanal();
		List<CronTaskInstance> outrasProgramacoes = agenda.getOutrasProgramacoes();
		System.out.println("Programacao Semanal = " + dias);
		System.out.println("Outras Programa��es = " + outrasProgramacoes);
	}
	
}
