package petrobras.engenharia.fic.cronovisao.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

/**
 * Um objeto desta classe define um dia da semana e possui uma cole��o 
 * de objetos CronTaskInstance.
 * Essa cole��o � a lista de cron tasks que executam no dia da semana
 * definido.
 * 
 * @author UR5G
 *
 */
public class Dia implements Serializable {

	private static final long serialVersionUID = 1L;

	private DiaDaSemana dia;
	
	private List<CronTaskInstance> cronInstances;

	public Dia(DiaDaSemana dia) {
		this.dia = dia;
		this.cronInstances = new ArrayList<CronTaskInstance>();
	}
	
	public List<CronTaskInstance> getCronInstances() {
		return cronInstances;
	}

	public void addCronInstance(CronTaskInstance cronTaskInstance) {
		cronInstances.add(cronTaskInstance);
	}

	public String getName() {
		return dia.toString();
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dia == null) ? 0 : dia.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dia other = (Dia) obj;
		if ( !dia.equals(other.dia) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		return dia.toString() + "->" + this.cronInstances;
	}

	public DiaDaSemana getDia() {
		return dia;
	}

	public void setDia(DiaDaSemana dia) {
		this.dia = dia;
	}

	public List<CronTaskInstance> getCronInstancesSortedByHour() {

		List<CronTaskInstance> sortedList = new ArrayList<CronTaskInstance>(this.cronInstances);
		
		Collections.sort(sortedList, new Comparator<CronTaskInstance>() {
			public int compare(CronTaskInstance o1, CronTaskInstance o2) {
				return o1.getHora().compareTo(o2.getHora());
			}
		});
		
		return sortedList;
	}

}

