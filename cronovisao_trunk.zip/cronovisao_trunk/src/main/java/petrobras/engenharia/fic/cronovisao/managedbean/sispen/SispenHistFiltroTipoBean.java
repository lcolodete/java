package petrobras.engenharia.fic.cronovisao.managedbean.sispen;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.model.LazyDataModel;

import petrobras.engenharia.fic.cronovisao.model.TipoCronSispen;
import petrobras.engenharia.fic.cronovisao.service.IServiceDelegate;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceQuery;
import petrobras.engenharia.fic.cronovisao.service.croninstance.SispenCronInstanceService;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronInstanceQueryByExample;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskHistory;
import petrobras.engenharia.fic.cronovisao.service.jaxb.CronTaskInstance;

@ManagedBean
@ViewScoped
public class SispenHistFiltroTipoBean {

	private static final Logger logger = Logger.getLogger(SispenHistFiltroTipoBean.class);
	
	private DataTable dataTable;

	private IServiceDelegate<CronTaskInstance, CronInstanceQueryByExample> cronInstanceService = new SispenCronInstanceService();
	
	private TipoCronSispen[] tipos = TipoCronSispen.values();
	
	private TipoCronSispen tipoSelecionado;
	
	private Map<TipoCronSispen, Set<CronTaskInstance>> cronInstanceCache = new HashMap<TipoCronSispen, Set<CronTaskInstance>>();
	
	private Map<String, String> cronsAndSites = new HashMap<String, String>();
	
	private LazyDataModel<CronTaskHistory> dataModel;
	
	private final int pageSize = 20;
	
	public SispenHistFiltroTipoBean() {
	}

	private void createDataModel() {
		this.dataModel = new CronHistDataModel();
	}
	
	public void carregarLista() {
		
		if (logger.isDebugEnabled()) {
			logger.debug(">>>>>>>>>>>>>>>>> carregarLista()");
			logger.debug(">>>>>>>>>>>>>>>>> tipo="+getTipoSelecionado());
		}
		
		if (getTipoSelecionado() != null) {
		
			createDataModel();
			
			this.dataTable.setValueExpression("sortBy", null);
			
			Set<CronTaskInstance> cronInstances = cronInstanceCache.get(getTipoSelecionado());
			if (cronInstances == null) {

				SispenCronInstanceQuery sispenQuery = new SispenCronInstanceQuery(getTipoSelecionado().getInternalValue());
				cronInstances = cronInstanceService.processMessage(sispenQuery.getQueryObject());
				
				for (CronTaskInstance cron : cronInstances) {
					cronsAndSites.put(cron.getInstancename(), cron.getParam("EMPREENDIMENTO"));
				}
				
				cronInstanceCache.put(getTipoSelecionado(), cronInstances);
			}
			
		}
		
	}
	
	public TipoCronSispen[] getTipos() {
		return tipos;
	}

	public TipoCronSispen getTipoSelecionado() {
		return tipoSelecionado;
	}

	public void setTipoSelecionado(TipoCronSispen tipoSelecionado) {
		this.tipoSelecionado = tipoSelecionado;
	}

	public DataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(DataTable dataTable) {
		this.dataTable = dataTable;
	}

	public LazyDataModel<CronTaskHistory> getDataModel() {
		return dataModel;
	}

	public int getPageSize() {
		return pageSize;
	}

	public Set<CronTaskInstance> findCronInstancesByTipo() {
		return cronInstanceCache.get(getTipoSelecionado());
	}
	
	public String findEmpreendimentoByCronInstanceName(String instanceName) {
		return cronsAndSites.get(instanceName);
	}
}
