package petrobras.engenharia.fic.cronovisao.service.jaxb;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

import petrobras.engenharia.fic.cronovisao.util.DateUtil;
import petrobras.engenharia.fic.cronovisao.util.ScheduleFormat;
import petrobras.engenharia.fic.cronovisao.util.ScheduleUtil;

public class CronTaskInstance implements Serializable, Comparable<CronTaskInstance> {

	private static final long serialVersionUID = 1L;
	
	private String active;
	private String crontaskinstanceid;
	private String crontaskname;
	private String instancename;
	private String schedule;
	private MaxUser maxUser;
	private List<CronTaskParam> params;

	public CronTaskInstance() {
	}
	
	/**
	 * Data em que a cron sera executada novamente.
	 */
	private Date dataProximaExecucao;
	
	/**
	 * Numero de registros de PM que serao processados na proxima execucao.
	 */
	private Integer numPreservacoesProcessar;
	
	/**
	 * Data final do per�odo de an�lise relativo � pr�xima execu��o.
	 */
	private Date dataFinalAnalise;

	private String empreendimento;
	
	@XmlElement(name="ACTIVE")
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	
	@XmlTransient
	public boolean isCronActive() {
		return active.equals("1") ? true : false;
	}
	
	@XmlTransient
	public String getCrontaskinstanceid() {
		return crontaskinstanceid;
	}
	public void setCrontaskinstanceid(String crontaskinstanceid) {
		this.crontaskinstanceid = crontaskinstanceid;
	}
	
	@XmlElement(name="CRONTASKNAME")
	public String getCrontaskname() {
		return crontaskname;
	}
	public void setCrontaskname(String crontaskname) {
		this.crontaskname = crontaskname;
	}
	
	@XmlElement(name="INSTANCENAME")
	public String getInstancename() {
		return instancename;
	}
	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}
	
	@XmlElement(name="SCHEDULE")
	public String getSchedule() {
		return schedule;
	}
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}
	
	@XmlElement(name="MAXUSER")
	public MaxUser getMaxUser() {
		return maxUser;
	}
	
	public void setMaxUser(MaxUser maxUser) {
		this.maxUser = maxUser;
	}

	@XmlElement(name="CRONTASKPARAM")
	public List<CronTaskParam> getParams() {
		return params;
	}
	
	public void setParams(List<CronTaskParam> params) {
		this.params = params;
	}
	
	@XmlTransient
	public String getEmpreendimento() {
		if (this.empreendimento == null) {
			String defsite = this.maxUser.getDefsite();
			this.empreendimento = (defsite == null ? "" : defsite);
		}
		return this.empreendimento;
	}
	
	public void setEmpreendimento(String siteId) {
		this.empreendimento = siteId;
	}

	@XmlTransient
	public String getUserId() {
		String userId = this.maxUser.getUserid();
		return userId;
	}
	
	@XmlTransient
	public String getHora() {
		ScheduleFormat sf = ScheduleFormat.getInstance(this.schedule);
		String formattedStr = sf.formatHora();
		return formattedStr;
	}
	
	@XmlTransient
	public String getFullyQualifiedName() {
		return this.crontaskname + "." + this.instancename;
	}
	
	@Override
	public String toString() {
		return this.instancename;
	}
	
	@Override
	public int compareTo(CronTaskInstance o) {
		return this.instancename.compareToIgnoreCase(o.getInstancename());
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((crontaskname == null) ? 0 : crontaskname.hashCode());
		result = prime * result
				+ ((instancename == null) ? 0 : instancename.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CronTaskInstance other = (CronTaskInstance) obj;
		if (crontaskname == null) {
			if (other.crontaskname != null)
				return false;
		} else if (!crontaskname.equals(other.crontaskname))
			return false;
		if (instancename == null) {
			if (other.instancename != null)
				return false;
		} else if (!instancename.equals(other.instancename))
			return false;
		return true;
	}

	private Date getDataProximaExecucao() {
		if (this.dataProximaExecucao == null) {
			this.dataProximaExecucao = calculaDataProximaExecucao();
		}
		return this.dataProximaExecucao;
	}
	
	@XmlTransient
	public String getDataProximaExecucaoAsString() {
		DateFormat df = DateFormat.getDateInstance(DateFormat.DEFAULT, DateUtil.LOCALE_PT_BR);
		return df.format(this.getDataProximaExecucao());
	}
	
	@XmlTransient
	public Date getDataFinalAnalise() {
		if (this.dataFinalAnalise == null) {
			this.dataFinalAnalise = calculaDataFinalDeAnalise();
		}
		return this.dataFinalAnalise;
	}
	
	@XmlTransient
	public Integer getNumPreservacoesProcessar() {
		return numPreservacoesProcessar;
	}
	
	public void setNumPreservacoesProcessar(Integer numPreservacoesProcessar) {
		this.numPreservacoesProcessar = numPreservacoesProcessar;
	}

	/**
	 * TODO como tratar crons quinzenais?
	 * 
	 * Retorna a data em que a cron est� programada para executar novamente.
	 * A data retornada � a data da pr�xima execu��o (que � tamb�m a data inicial 
	 * do per�odo de an�lise).
	 * 
	 * @return
	 */
	private Date calculaDataProximaExecucao() {
		int diaDaSemana = ScheduleUtil.getDiaSemanaFromSchedule(this.schedule);
		return DateUtil.calculateDateOfNextDayOfWeek(diaDaSemana);
	}
	
	/**
	 * Calcula a data final do per�odo de an�lise relativo � pr�xima
	 * execu��o.<br>Se a data da proxima execu��o � D, ent�o:<br>
	 * - Para crons com frequencia semanal, retorna D + 6<br>
	 * - Para crons com frequencia quinzenal, retorna D + 13
	 * 
	 * @param cron
	 * @return a data final do periodo de an�lise 
	 */
	private Date calculaDataFinalDeAnalise() {
		Calendar c = Calendar.getInstance(DateUtil.LOCALE_PT_BR);
		c.setTime(this.getDataProximaExecucao());
		
		int delta = 0;
		if (ScheduleUtil.isFrequenciaSemanal(this.getSchedule())) {
			delta = 6;
		} else if (ScheduleUtil.isFrequenciaQuinzenal(this.getSchedule())) {
			delta = 13;
		}
		
		c.add(Calendar.DAY_OF_MONTH, delta);
		
		return c.getTime();
	}

	/**
	 * Given a parameter name, return its associated value.
	 * 
	 * @param name name of the cron parameter
	 * @return
	 */
	public String getParam(String name) {
		String value = null;
		for (CronTaskParam paramObj : this.params) {
			if (paramObj.getName().equals(name)) {
				value = paramObj.getValue();
				break;
			}
		}
		return value;
	}
}
