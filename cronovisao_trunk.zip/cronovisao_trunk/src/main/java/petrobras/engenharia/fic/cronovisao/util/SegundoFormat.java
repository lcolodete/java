package petrobras.engenharia.fic.cronovisao.util;

public class SegundoFormat extends ScheduleFormat {

	protected SegundoFormat(String schedule) {
		super(schedule);
		this.textoFrequenciaPrincipal = "segundo";
	}

	@Override
	public String formatHora() {
		return "N/A";
	}

	/**
	 * Exemplo de campo schedule: <code>59s,*,*,*,*,*,*,*,*,*</code>
	 * <br/>
	 * <br/>
	 * <code>
	 * 59s, -> A cada 59 segundos<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *,   -> Nao usado<br/>
	 * *    -> Nao usado
	 * </code>
	 * 
	 */
	@Override
	public String format() {
		String formattedStr = "";
		
		formattedStr = formatFrequenciaPrincipal();
		
		return formattedStr;
	}

}
