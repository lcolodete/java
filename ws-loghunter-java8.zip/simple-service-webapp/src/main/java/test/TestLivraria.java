package test;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;


public class TestLivraria {

	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(getBaseURI());
		
		TestLivraria test = new TestLivraria();
		test.getCatalogo_Xml(target);
		test.getCatalogo_Json(target);
		
		test.getLivroByIsbn_Xml(target);
		test.getLivroByIsbn_Json(target);
		
//		test.getLivroById_Xml(target);
//		test.getLivroById_Json(target);
	}

	private void getLivroByIsbn_Xml(WebTarget target) {
		System.out.println("--> getLivroByIsbn_Xml");
		WebTarget newTarget = target.path("livraria")
				.path("livro/{isbn}")
				.resolveTemplate("isbn", "1234");
		
		System.out.println(newTarget);
		System.out.println(newTarget.getUri());
		
		String responseStr = newTarget.request()
				.accept(MediaType.APPLICATION_XML)
				.get(String.class);
		System.out.println(responseStr);
	}
	
	private void getLivroByIsbn_Json(WebTarget target) {
		System.out.println("--> getLivroByIsbn_Json");
		WebTarget newTarget = target.path("livraria")
				.path("livro/{isbn}")
				.resolveTemplate("isbn", "9876");
		
		System.out.println(newTarget);
		System.out.println(newTarget.getUri());
		
		String responseStr = newTarget.request()
				.accept(MediaType.APPLICATION_JSON)
				.get(String.class);
		System.out.println(responseStr);
	}

//	private void getLivroById_Xml(WebTarget target) {
//		System.out.println("--> getLivroById_Xml");
//		WebTarget newTarget = target.path("livraria")
//				.path("livro/{id}")
//				.resolveTemplate("id", "1");
//		
//		System.out.println(newTarget);
//		System.out.println(newTarget.getUri());
//		
//		String responseStr =newTarget.request()
//				.accept(MediaType.APPLICATION_XML)
//				.get(String.class);
//		System.out.println(responseStr);
//	}

	private void getCatalogo_Json(WebTarget target) {
		System.out.println("--> getCatalogo_Json");
		String responseStr =
		target.path("livraria")
				.request()
				.accept(MediaType.APPLICATION_JSON)
				.get(String.class);
		System.out.println(responseStr);
	}

	private void getCatalogo_Xml(WebTarget target) {
		System.out.println("--> getCatalogo_Xml"); 
		String responseStr = target.path("livraria")
									.request()
									.accept(MediaType.APPLICATION_XML)
									.get(String.class);
									
		System.out.println(responseStr);
	}

	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/simple-service-webapp/webapi").build();
	}
}
