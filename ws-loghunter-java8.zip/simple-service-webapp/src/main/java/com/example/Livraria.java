package com.example;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("livraria")
public class Livraria {

	private static List<Livro> list = new ArrayList<Livro>();
	
	static {
    	Livro livro1 = new Livro();
    	livro1.setIsbn("1234");
    	livro1.setTitulo("Jurassic Park");

		list.add(livro1);
		
		Livro livro2 = new Livro();
		livro2.setIsbn("9876");
		livro2.setTitulo("Codigo Da Vinci");
		
		list.add(livro2);
	}
	
	@GET
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public List<Livro> getCatalogo() {
		return list;
	}
	
//    @GET @Path("livro/{id}")
//    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
//    public Livro getLivro(@PathParam("id") Integer id) {
//    	Livro livro = list.get(id);
//    	return livro;
//    }

    @GET @Path("livro/{isbn}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Livro getLivroByIsbn(@PathParam("isbn") String isbn) {
    	Livro livroEncontrado = null;
    	for (Livro livro : list) {
    		if (livro.getIsbn().equals(isbn)) {
    			livroEncontrado = livro;    			
    			break;
    		}
    	}
    	return livroEncontrado;
    }

}
