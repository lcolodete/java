package petrobras.ticeng.fic.pmwogen.config;

import java.io.File;

public class CrontaskInstance implements Comparable<CrontaskInstance> {

	private String instanceName;
	private String logFilename;
	private File logFile;
	
	public CrontaskInstance() {
	}
	
	public CrontaskInstance(String instanceName, String logFilename) {
		this.instanceName = instanceName;
		this.logFilename = logFilename;
		this.logFile = new File(logFilename);
	}
	
	/**
	 * Faz o parsing da String informada (que é uma linha do arquivo de configuracao do dia da semana), 
	 * e cria o objeto correspondente.
	 * 
	 * @param s
	 * @return
	 */
	public static CrontaskInstance parse(String s) {
		
		String[] tokens = s.split("=");
		
		String instanceName = tokens[0];
		String logFile = tokens[1];
		
		return new CrontaskInstance(instanceName, logFile);
	}
	
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getLogFilename() {
		return logFilename;
	}

	public void setLogFilename(String logFilename) {
		this.logFilename = logFilename;
	}

	public File getLogFile() {
		return logFile;
	}

	public void setLogFile(File logFile) {
		this.logFile = logFile;
	}
	
	public static void main(String[] args) {
		String testLine = "U-6500 Sistema Dutoviário=/ebusiness/shared/home/PrdExt100_WLSv103/applogs/maximo/logs/cron/U-6500-Sistema-Dutoviario.log";
		
		CrontaskInstance one_instance = parse(testLine);
		
		System.out.println("instanceName="+one_instance.getInstanceName());
		System.out.println("logFilename="+one_instance.getLogFilename());
		System.out.println("logFile="+one_instance.getLogFile().getPath());
	}

	@Override
	public int compareTo(CrontaskInstance o) {
		return this.instanceName.compareTo(o.getInstanceName());
	}

	@Override
	public String toString() {
		return this.logFilename;
	}
}
