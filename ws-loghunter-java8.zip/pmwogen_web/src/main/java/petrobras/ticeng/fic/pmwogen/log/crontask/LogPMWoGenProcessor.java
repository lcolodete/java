package petrobras.ticeng.fic.pmwogen.log.crontask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;

public class LogPMWoGenProcessor {
	
	private static final Logger LOGGER = Logger.getLogger(LogPMWoGenProcessor.class);

	public static class Regex {
		
		public static final String SITE = "site .{3,50} conclu.{1}da";
		private static final String GERAR_ORDEM_DE_SERVICO = "Gerar ordem de servi.{1}o a partir de MPs no "+SITE+" X [\\d\\d]+:[\\d\\d]+ (A|P)M\\.";
		private static final String BMXAA3208I = ".*BMXAA3208I.*";
		
		public static String getRegexGerarOrdemDate(Date targetDate) {
			
			DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("en", "US"));
			
			return GERAR_ORDEM_DE_SERVICO.replace("X", df.format(targetDate));
		}
		
		public static String getRegexGerarOrdem() {
			return GERAR_ORDEM_DE_SERVICO.replace("X", "[\\d\\d]+/[\\d\\d]+/[\\d\\d]+");
		}
	}
	
	public static void main(String[] args) throws ParseException {
		boolean matches = false;
		
		String line = "Gerar ordem de serviço a partir de MPs no site IEABAST-IERM-MODERNIZACAO-ADEQUACAO-001 concluída 5/25/15 10:13 AM.";
		
		Date d = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR")).parse("25/5/15");
		
		if (line.matches(LogPMWoGenProcessor.Regex.getRegexGerarOrdemDate(d))) {
			matches = true;
		}
		
		System.out.println(matches);

		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("en", "US"));
		Date date = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR")).parse("5/12/16");
		System.out.println(df.format(date));
	}
	
	/**
	 * Indica se o resultado do processamento sera gravado em arquivos.
	 */
	private boolean generateOutput = false;
	
	/**
	 * Diretorio no qual os arquivos de saida serao gerados.
	 */
	private String outputDir = null;
	
	private static final String DEFAULT_OUTPUT_DIR = "C:\\Users\\ur5g\\FIC\\Logs\\LogHunter\\pmwogen\\pmwogen_web\\"; 
	
	public LogPMWoGenProcessor() {
		this.setOutputDir(DEFAULT_OUTPUT_DIR);
	}
	
	public String getOutputDir() {
		return outputDir;
	}

	public void setOutputDir(String outputDir) {
		this.outputDir = outputDir;
	}

	public boolean isGenerateOutput() {
		return generateOutput;
	}

	public void setGenerateOutput(boolean generateOutput) {
		this.generateOutput = generateOutput;
	}

	/**
	 * Para cada cron presente em cronInstanceSet, computa as informações de geração de ordens de preservação para a data targetDate.
	 * 
	 * @param targetDate Indica a data que sera procurada no log. Apenas as linhas correspondentes a essa data serão analisadas.
	 * @param cronInstanceSet Crons que terao seus arquivos processados.
	 * @return lista de objetos PMWoGenInfo
	 * @see PMWoGenInfo
	 * 
	 * @throws Exception
	 */
	public List<PMWoGenInfo> processaLogDoDia(final Date targetDate, Set<CrontaskInstance> cronInstanceSet, boolean parallel) {

		Objects.requireNonNull(targetDate);
		
		List<PMWoGenInfo> resultList = new ArrayList<PMWoGenInfo>();
		String now = new SimpleDateFormat("yyyy-MM-dd_HHmmss").format(new Date());
			

		for (CrontaskInstance cronInstance : cronInstanceSet) {
			
			File file = cronInstance.getLogFile();
			String filename = file.getName();
			
			LOGGER.info(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
			
			try (BufferedReader reader = Files.newBufferedReader(Paths.get(cronInstance.getLogFilename()), StandardCharsets.UTF_8)) {
		    	
		    	List<String> lines = new ArrayList<>();
		    	String line = null;

		    	
		    	do {
		    		line = reader.readLine();
		    	} while (!line.matches(LogPMWoGenProcessor.Regex.getRegexGerarOrdemDate(targetDate)));
		    	
		    	lines.add(line);
			    	
				while ( (line = reader.readLine()) != null ) {
					
					if (line.matches(LogPMWoGenProcessor.Regex.getRegexGerarOrdem())) {
						if (line.matches(LogPMWoGenProcessor.Regex.getRegexGerarOrdemDate(targetDate))) {
							lines.add(line);
						} else {
							// mudou o dia
							break;
						}
						
					} else if (line.matches(LogPMWoGenProcessor.Regex.BMXAA3208I)) {
						lines.add(line);
					}
					
				} // Le a proxima linha

		    	Stream<String> linesStream;
		    	if (parallel)
		    		linesStream = lines.parallelStream();
		    	else
		    		linesStream = lines.stream();
		    	
		    	Map<Boolean, List<String>> map =
		    	linesStream.collect(Collectors.partitioningBy(s -> s.matches(LogPMWoGenProcessor.Regex.getRegexGerarOrdemDate(targetDate))));
		    	
		    	List<String> linesGerarOrdem = map.get(true);
		    	
		    	if (linesGerarOrdem != null && !linesGerarOrdem.isEmpty()) {
		    		PMWoGenInfo pmwogenInfo = this.createPMWoGenInfo(linesGerarOrdem.get(0));
		    		GerarOrdemLine last = GerarOrdemLine.parse(linesGerarOrdem.get(linesGerarOrdem.size()-1));
		    		pmwogenInfo.setHoraFim(last.getTime());
		    		pmwogenInfo.setPreservacoes(linesGerarOrdem.size());

		    		Integer ordens = map.get(false).size();
		    			 
		    		pmwogenInfo.setOrdens(ordens);
		    		
					if (this.isGenerateOutput()) {
						try (BufferedWriter out = new BufferedWriter(new FileWriter(this.getOutputDir() + "output_" + filename.replaceFirst("\\.log", "") +"_" + now))) {
							out.write(pmwogenInfo.getSite());
							out.newLine();
							out.newLine();
							
							out.write(">>>>> " + formatDate(last.getDate()));
							out.newLine();
							
							encerraDia(out, pmwogenInfo);
						}
					}
		    		
	    			resultList.add(pmwogenInfo);
		    	}
		    	
				LOGGER.info("**************************");
				LOGGER.info("FIM DO ARQUIVO : "+ filename);
				LOGGER.info("**************************");
				LOGGER.info("");

			} catch (FileNotFoundException e) {
				
				//Se nao encontrar o arquivo, escreve mensagem no log e vai para o proximo
				//Se ocorrer qualquer outro erro, deixa lancar a exception
				
				LOGGER.warn("Arquivo nao encontrado", e);
				continue;
		    	
		    } catch (Exception e) {
		    	e.printStackTrace();
		    }
			
		} // fim for : Le o proximo arquivo
		
		// FIM DE TODOS OS ARQUIVOS

		LOGGER.info("**************************");
		LOGGER.info("  FIM DO PROCESSAMENTO");
		LOGGER.info("**************************");
		LOGGER.info("");
		
		return resultList;
	}
	
	private Date resetTimeFields(Date targetDate) {
		Date ret = null;
		if (targetDate != null) {
			
			Calendar c = Calendar.getInstance();
			c.setTime(targetDate);
			
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			c.set(Calendar.MILLISECOND, 0);
			ret = c.getTime();
		}
		return ret;
	}
	
	private PMWoGenInfo createPMWoGenInfo(String logLine) throws ParseException {
		
		GerarOrdemLine gerarOrdemLine = GerarOrdemLine.parse(logLine);
		
		PMWoGenInfo pmwogenInfo = new PMWoGenInfo();
		pmwogenInfo.setSite(gerarOrdemLine.getSite());
		pmwogenInfo.setDate(this.parseDate(gerarOrdemLine.getDate()));
		pmwogenInfo.setHoraInicio(gerarOrdemLine.getTime());
		return pmwogenInfo;
	}
	
	public List<PMWoGenInfo> processaLogs(Set<CrontaskInstance> cronInstanceSet) throws Exception {

		BufferedReader in = null;
		BufferedWriter out = null;
		
		List<PMWoGenInfo> resultList = new ArrayList<PMWoGenInfo>();

		Date targetDate = null;
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
		String now = df.format(new Date());
			
		try {

			for (CrontaskInstance cronInstance : cronInstanceSet) {
				
				File file = cronInstance.getLogFile();
				String filename = file.getName();
				
				LOGGER.info(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
				
				try {
					in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
				} catch (FileNotFoundException e) {
					
					//Se nao encontrar o arquivo, escreve mensagem no log e vai para o proximo
					//Se ocorrer qualquer outro erro, deixa lancar a exception
					
					LOGGER.warn("Arquivo nao encontrado", e);
					continue;
				}
				
				int hitsGerarOrdem = 0;
				String currentDate = "";
				
				PMWoGenInfo pmwogenInfo = null;
				String line = null;
				
				while ( (line = in.readLine()) != null ) {
					
					if (line.matches(LogPMWoGenProcessor.Regex.getRegexGerarOrdem())) {
						
						GerarOrdemLine logLine = GerarOrdemLine.parse(line);
						String dateFromLine = logLine.getDate();
						Date dateObjFromLine = this.parseDate(dateFromLine);
						
						if (currentDate.isEmpty() || !currentDate.equals(dateFromLine)) {
							
							//encerra o dia
							if (!currentDate.isEmpty()) {
								if (targetDate != null)
									break;

								encerraDia(out, pmwogenInfo);
								resultList.add(pmwogenInfo);
								pmwogenInfo = null;
							}

							if (targetDate != null) {
								if (!dateObjFromLine.equals(targetDate)) {
									continue;
								}
							}
							
							//inicia novo dia
							currentDate = dateFromLine;
							
							pmwogenInfo = new PMWoGenInfo();
							pmwogenInfo.setSite(logLine.getSite());
							pmwogenInfo.setDate(dateObjFromLine);
							pmwogenInfo.setHoraInicio(logLine.getTime());
							pmwogenInfo.setHoraFim(pmwogenInfo.getHoraInicio());

							hitsGerarOrdem++;
							
							if (this.isGenerateOutput()) {
								if (hitsGerarOrdem == 1) {
									out = new BufferedWriter(new FileWriter(this.getOutputDir() + "output_" + filename.replaceFirst("\\.log", "") +"_" + now));
									
									out.write(logLine.getSite());
									out.newLine();
									out.newLine();
								}
								
								out.write(">>>>> " + formatDate(dateFromLine));
								out.newLine();
							}

						} else {
							pmwogenInfo.setHoraFim(logLine.getTime());
						}
						
						pmwogenInfo.setPreservacoes( pmwogenInfo.getPreservacoes() + 1 );
						
					} else if ( pmwogenInfo != null ) {
						
						if (line.matches(LogPMWoGenProcessor.Regex.BMXAA3208I)) {
							pmwogenInfo.setOrdens( pmwogenInfo.getOrdens() + 1 );
						}
					}
					
				} // Le a proxima linha
				
				// FIM DO PROCESSAMENTO DE UMA CRON INSTANCE
				
				if (hitsGerarOrdem > 0) {
					encerraDia(out, pmwogenInfo);
					resultList.add(pmwogenInfo);
					pmwogenInfo = null;
				}
				
				LOGGER.info("**************************");
				LOGGER.info("FIM DO ARQUIVO : "+ filename);
				LOGGER.info("**************************");
				LOGGER.info("");
				
				if (in != null)
					in.close();
				in = null;
				
				if (out != null)
					out.close();
				out = null;
				
			} // Le o proximo arquivo
			
			// FIM DE TODOS OS ARQUIVOS

			LOGGER.info("**************************");
			LOGGER.info("  FIM DO PROCESSAMENTO");
			LOGGER.info("**************************");
			LOGGER.info("");
			
			return resultList;

		} finally {
			if (in != null)
				in.close();
			if (out != null)
				out.close();
		}

	}

	private String formatDate(String date) throws ParseException {
		Date d = this.parseDate(date);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(d);
	}
	
	private Date parseDate(String date) throws ParseException {
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("en"));
		return df.parse(date);
	}

	private void encerraDia(BufferedWriter out, PMWoGenInfo pmwogenInfo) throws IOException {
		if (out != null) {
			out.newLine();
			out.write("PRESERVAÇÕES : " + pmwogenInfo.getPreservacoes());
			out.newLine();
			out.write("ORDENS GERADAS : " + pmwogenInfo.getOrdens());
			out.newLine();
			out.newLine();
			out.write("INÍCIO : " + pmwogenInfo.getHoraInicio());
			out.newLine();
			out.write("FIM : " + pmwogenInfo.getHoraFim());
			out.newLine();
			out.newLine();
			out.flush();
		}
	}

}
