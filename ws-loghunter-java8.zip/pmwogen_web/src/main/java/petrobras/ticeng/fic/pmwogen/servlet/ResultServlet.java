package petrobras.ticeng.fic.pmwogen.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.CrontaskHelper;
import petrobras.ticeng.fic.pmwogen.config.Configuracao;
import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;
import petrobras.ticeng.fic.pmwogen.log.crontask.LogPMWoGenProcessor;
import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;
import petrobras.ticeng.fic.pmwogen.log.jvm.CrontaskRunInfo;
import petrobras.ticeng.fic.pmwogen.log.jvm.LogJVMProcessor;

public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ResultServlet.class);
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOGGER.info("ResultServlet.doGet");

		List<PMWoGenInfo> listCronsComGeracao = null;
		List<CrontaskRunInfo> listCrontaskRunInfo = null;
		
		Configuracao config = Configuracao.getInstance();
		
		String inputDir = config.getInputDir();
		String inputFile = null;

		String dataRequest = request.getParameter("data");
		LOGGER.info("data=["+ dataRequest +"]");
		
		//Caso nao tenha data no request, utiliza a data de hoje
		Date generationDate = null;
		
		if ( dataRequest != null && !dataRequest.isEmpty() ) {
			try {
				generationDate = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR")).parse(dataRequest);
			} catch (ParseException e1) {
				String sErrorMsg = "Data com formato invalido: "+dataRequest;
				LOGGER.error(sErrorMsg, e1);
				
				//Exibe o erro na tela
				request.setAttribute("mensagemTopo", sErrorMsg);
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/date.jsp");
				dispatcher.forward(request, response);

				return;
			}
		} else {
			generationDate = new Date();
		}
		
		Calendar c = Calendar.getInstance();
		c.setTime(generationDate);
		
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);

		inputFile = dayOfWeek+".txt";
		
		BufferedReader inList = null;
		
		int qtdCronsProgramadas = 0;

		Set<CrontaskInstance> cronInstanceSet = new TreeSet<CrontaskInstance>();
		
		try {
			inList = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(inputDir + inputFile), "UTF-8"));
			
			String line = null;
			while ( (line = inList.readLine()) != null ) {
				if (!line.isEmpty() && !line.startsWith("#")) {
					CrontaskInstance cronInstance = CrontaskInstance.parse(line);
					cronInstanceSet.add(cronInstance);
				}
			}
			
			qtdCronsProgramadas = cronInstanceSet.size();
			
			LogPMWoGenProcessor processor = new LogPMWoGenProcessor();
			listCronsComGeracao = processor.processaLogDoDia(generationDate, cronInstanceSet, false);
			
			LOGGER.debug(listCronsComGeracao);
			
		} catch (Exception e) {
			LOGGER.error("Erro em ResultServlet.doGet()", e);
		} finally {
			if (inList != null)
				inList.close();
		}

		try {
			LogJVMProcessor logJVMProcessor = new LogJVMProcessor();
			listCrontaskRunInfo = logJVMProcessor.processaLogDoDia(generationDate);
		} catch (Exception e) {
			LOGGER.error("Erro em ResultServlet.doGet()", e);
		}

		// Setando os valores para o result.jsp
		
		//Quantidade de crons programadas para o dia em questao
		request.setAttribute("cronsDoDia", qtdCronsProgramadas);
		
		//Quantidade de crons com execucao concluida na data informada
//		int qtdCronsConcluidas = listCrontaskRunInfo != null ? listCrontaskRunInfo.size() : 0;
//		request.setAttribute("cronsConcluidas", qtdCronsConcluidas);
		
		CrontaskHelper helper = new CrontaskHelper(listCrontaskRunInfo, cronInstanceSet);
		
		//Lista de crons do dia com execucao concluida
		
		List<CrontaskRunInfo> cronsDoDiaConcluidas = new ArrayList<CrontaskRunInfo>();
		List<CrontaskRunInfo> outrasCronsConcluidas = new ArrayList<CrontaskRunInfo>();
		
		helper.findCrons(cronsDoDiaConcluidas, outrasCronsConcluidas);
		request.setAttribute("listCronsDoDiaConcluidas", cronsDoDiaConcluidas);

		int qtdCronsConcluidas = cronsDoDiaConcluidas != null ? cronsDoDiaConcluidas.size() : 0;
		request.setAttribute("cronsDoDiaConcluidas", qtdCronsConcluidas);
		
		//Quantidade de crons com geracao de ordens na data informada
		int qtdCronsComGeracao = listCronsComGeracao != null ? listCronsComGeracao.size() : 0;
		request.setAttribute("cronsComGeracao", qtdCronsComGeracao);
		
		//Regras para exibicao de alertas na tela
		// qtdCronsProgramadas == qtdCronsConcluidas >= qtdCronsComGeracao
		
		request.setAttribute("mensagemTopo", "");
		
		StringBuilder sMensagens = new StringBuilder();
		
		if (qtdCronsConcluidas < qtdCronsComGeracao) {
			int qtdCronsEmExecucao = qtdCronsComGeracao - qtdCronsConcluidas;
			sMensagens.append(qtdCronsEmExecucao + " crons ainda estao em execucao.");
		}
		
		if (qtdCronsConcluidas < qtdCronsProgramadas) {
			int qtdCronsInvestigar = qtdCronsProgramadas - qtdCronsConcluidas;
			
			if (sMensagens.length() > 0) {
				sMensagens.append("<br/>");
			}
			
			sMensagens.append(qtdCronsInvestigar + " crons podem estar ainda em execucao ou ter falhado.");
		}
		
		request.setAttribute("mensagemTopo", sMensagens.toString());
		
		//Lista de crons com geracao de ordem na data informada
		request.setAttribute("list", listCronsComGeracao);
		
		request.setAttribute("generationDate", generationDate);
		request.setAttribute("currentDate", new Date());

		//Versão da aplicacao exibida no rodape da pagina
		request.setAttribute("versaoAplicacao", config.getVersaoAplicacao());

		//Lista de outras crons concluidas
		request.setAttribute("listOutrasCronsConcluidas", outrasCronsConcluidas);
		
		//Lista de crons programadas (crons do dia)
		request.setAttribute("listCrontaskInstance", cronInstanceSet);

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/result.jsp");
		dispatcher.forward(request, response);
	}

}
