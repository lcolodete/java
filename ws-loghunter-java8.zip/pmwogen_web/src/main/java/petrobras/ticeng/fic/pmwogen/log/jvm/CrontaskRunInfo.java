package petrobras.ticeng.fic.pmwogen.log.jvm;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Classe que contém as informações sobre a execução de uma instancia de PMWoGenCronTask:
 * <br/><br/>
 * serverName : nome da JVM onde a cron executou<br/>
 * cidCron : identificador CID-CRON no log da JVM<br/>
 * instanceName : nome da instancia<br/>
 * duration : tempo de execucao<br/>
 * 
 * @author ur5g
 *
 */
public class CrontaskRunInfo implements Comparable<CrontaskRunInfo> {

	private String hora;
	private String serverName;
	private Integer cidCron;
	private String instanceName;
	private Integer duration;
	private List<String> errors;
	private List<String> warnings;

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public Integer getCidCron() {
		return cidCron;
	}

	public void setCidCron(Integer cidCron) {
		this.cidCron = cidCron;
	}

	public String getInstanceName() {
		return instanceName;
	}
	
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public List<String> getErrors() {
		return errors;
	}
	
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	public List<String> getWarnings() {
		return warnings;
	}

	public void setWarnings(List<String> warnings) {
		this.warnings = warnings;
	}

	public Integer getDuration() {
		return duration;
	}
	
	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getDurationFormatted_hms() {
		Date d = new Date((long)this.getDuration());
		
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		c.setTime(d);
		
		int hora = c.get(Calendar.HOUR_OF_DAY);
		int min = c.get(Calendar.MINUTE);
		int seg = c.get(Calendar.SECOND);
		
		StringBuilder durationStr = new StringBuilder();
		
		if (hora > 0) {
			durationStr.append(hora)
			.append("h");
		}
		if (min > 0) {
			durationStr.append(min)
			.append("m");
		}
		
		durationStr.append(seg)
		.append("s");
		
		return durationStr.toString();
	}
	
	public String getDurationFormatted() {
		Date d = new Date((long)this.getDuration());

		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		c.setTime(d);
		
		int hora = c.get(Calendar.HOUR_OF_DAY);
		int min = c.get(Calendar.MINUTE);
		int seg = c.get(Calendar.SECOND);
		
		StringBuilder durationStr = new StringBuilder();

		//Hora
		StringBuilder horaStr = new StringBuilder();
		if (String.valueOf(hora).length() < 2) {
			horaStr.append("0");
		}
		horaStr.append(hora);
		
		durationStr.append(horaStr)
						.append(":");
		
		//Minuto
		StringBuilder minutoStr = new StringBuilder();
		if (String.valueOf(min).length() < 2) {
			minutoStr.append("0");
		}
		minutoStr.append(min);
		
		durationStr.append(minutoStr)
						.append(":");

		//Segundo
		StringBuilder segundoStr = new StringBuilder();
		if (String.valueOf(seg).length() < 2) {
			segundoStr.append("0");
		}
		segundoStr.append(seg);
		
		durationStr.append(segundoStr);
		
		return durationStr.toString();
	}
	
	public CrontaskRunInfo() {
	}
	
	public CrontaskRunInfo(String hora, String serverName, Integer cidCron, String instanceName, Integer duration) {
		this.hora = hora;
		this.serverName = serverName;
		this.cidCron = cidCron;
		this.instanceName = instanceName;
		this.duration = duration;
	}

	@Override
	public String toString() {
		return String.valueOf(this.cidCron);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((duration == null) ? 0 : duration.hashCode());
		result = prime * result
				+ ((instanceName == null) ? 0 : instanceName.hashCode());
		result = prime * result
				+ ((serverName == null) ? 0 : serverName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CrontaskRunInfo other = (CrontaskRunInfo) obj;
		if (duration == null) {
			if (other.duration != null)
				return false;
		} else if (!duration.equals(other.duration))
			return false;
		if (instanceName == null) {
			if (other.instanceName != null)
				return false;
		} else if (!instanceName.equals(other.instanceName))
			return false;
		if (serverName == null) {
			if (other.serverName != null)
				return false;
		} else if (!serverName.equals(other.serverName))
			return false;
		return true;
	}

	@Override
	public int compareTo(CrontaskRunInfo o) {
		return this.getInstanceName().compareTo(o.getInstanceName());
	}

	public static void main(String[] args) {
		Date d1 = new Date(0L);
		Date d2 = new Date(12341146L);

		System.out.println(d2.getTime()-d1.getTime());
		
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		
		System.out.println("d1");
		c.setTime(d1);
		
		System.out.println(c.get(Calendar.DAY_OF_MONTH));
		System.out.println(c.get(Calendar.MONTH));
		System.out.println(c.get(Calendar.YEAR));
		System.out.println(c.get(Calendar.HOUR_OF_DAY));
		System.out.println(c.get(Calendar.MINUTE));
		System.out.println(c.get(Calendar.SECOND));
		
		System.out.println("d2");
		c.setTime(d2);

		System.out.println(c.get(Calendar.DAY_OF_MONTH));
		System.out.println(c.get(Calendar.MONTH));
		System.out.println(c.get(Calendar.YEAR));
		System.out.println(c.get(Calendar.HOUR_OF_DAY));
		System.out.println(c.get(Calendar.MINUTE));
		System.out.println(c.get(Calendar.SECOND));
		
	}
}
