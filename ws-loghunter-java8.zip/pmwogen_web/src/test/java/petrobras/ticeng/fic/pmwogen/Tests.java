package petrobras.ticeng.fic.pmwogen;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import petrobras.ticeng.fic.pmwogen.log.jvm.CrontaskRunInfo;

public class Tests {

//	public static void main(String[] args) {
//		
//	}
	
	
//	public static void main(String[] args) {
	public static void testDateBeforeAfter(String[] args) {

		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR"));
		try {
			Date dataDesativacaoTropezon = df.parse("7/6/16");
			
			
			Date dataTeste = new Date();
			Calendar c = Calendar.getInstance();
			c.setTime(dataTeste);

			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			c.set(Calendar.MILLISECOND, 0);

			System.out.println("dia="+c.get(Calendar.DAY_OF_MONTH));
			System.out.println("mes="+c.get(Calendar.MONTH));
			System.out.println("ano="+c.get(Calendar.YEAR));
			System.out.println("HOUR_OF_DAY="+c.get(Calendar.HOUR_OF_DAY));
			System.out.println("MINUTE="+c.get(Calendar.MINUTE));
			System.out.println("SECOND="+c.get(Calendar.SECOND));
			System.out.println("MILLISECOND="+c.get(Calendar.MILLISECOND));
			
			Date dataParaComparar = c.getTime();
			
			if (dataParaComparar.after(dataDesativacaoTropezon)) {
				System.out.println("dataTeste é depois de dataDesativacaoTropezon");
			} else if (dataParaComparar.before(dataDesativacaoTropezon)) {
				System.out.println("dataTeste é ANTES de dataDesativacaoTropezon");
			} else
				System.out.println("dataTeste == dataDesativacaoTropezon");
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		List<CrontaskRunInfo> jvmList = new ArrayList<CrontaskRunInfo>();
		
		CrontaskRunInfo c2 = new CrontaskRunInfo();
		c2.setCidCron(2);
		c2.setDuration(11111);
		c2.setInstanceName("teste");
		jvmList.add(c2);
		
		CrontaskRunInfo c1 = new CrontaskRunInfo();
		c1.setCidCron(1);
		c1.setServerName("server");
		jvmList.add(c1);

		CrontaskRunInfo c3 = new CrontaskRunInfo();
		c3.setCidCron(3);
		jvmList.add(c3);

		final Comparator<CrontaskRunInfo> comparator = new Comparator<CrontaskRunInfo>() {
			@Override
			public int compare(CrontaskRunInfo o1, CrontaskRunInfo o2) {
				return o1.getCidCron().compareTo(o2.getCidCron());
			}
		};
		Collections.sort(jvmList, comparator);

		System.out.println(jvmList);
		
		CrontaskRunInfo key = new CrontaskRunInfo();
		key.setCidCron(2);
		key.setDuration(0);
		key.setInstanceName("outro");
		
		System.out.println(Collections.binarySearch(jvmList, key, comparator));
	}
}
