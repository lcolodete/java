package petrobras.fic.loghunter.tcr.test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.LinkedHashMap;

import org.junit.Before;
import org.junit.Test;

import petrobras.ticeng.fic.tcr.json.JSONBuilder;

public class TestJSONBuilder {

	private JSONBuilder builder;
	private LinkedHashMap<String, String> obj1;
	private LinkedHashMap<String, String> obj2;
	private LinkedHashMap<String, String> obj3;
	
	@Before
	public void init() {
		builder = new JSONBuilder();
		obj1 = new LinkedHashMap<>();
		obj2 = new LinkedHashMap<>();
		obj3 = new LinkedHashMap<>();
	}
	
	@Test
	public void toJSONP_OneObjectOneAttribute_BuildsJSONP() {
		//Arrange
		obj1.put("name", "PASADENA");
		
		String expected = "var _id = [{\"name\":\"PASADENA\"}];";
		
		//Act
		builder.addObject(obj1);
		//Assert
		assertThat(builder.toJSONP("id"), is(equalTo(expected)));
	}
	
	@Test
	public void toJSONP_OneObjectTwoAttributes_BuildsJSONP() {
		//Arrange
		obj1.put("name", "PASADENA");
		obj1.put("longitude", "-118.298662");
		
		String expected = "var _id = [{\"name\":\"PASADENA\",\"longitude\":\"-118.298662\"}];";
		
		//Act
		builder.addObject(obj1);
		//Assert
		assertThat(builder.toJSONP("id"), is(equalTo(expected)));
	}
	
	@Test
	public void toJSONP_OneObjectNAttributes_BuildsJSONP() {
		//Arrange
		obj1.put("name", "PASADENA");
		obj1.put("longitude", "-118.298662");
		obj1.put("latitude", "+33.786594");
		
		String expected = "var _id = [{\"name\":\"PASADENA\",\"longitude\":\"-118.298662\",\"latitude\":\"+33.786594\"}];";
		
		//Act
		builder.addObject(obj1);
		//Assert
		assertThat(builder.toJSONP("id"), is(equalTo(expected)));
	}

	@Test
	public void toJSONP_TwoObjects_BuildsJSONP() {
		//Arrange
		obj1.put("name", "PASADENA");
		obj1.put("longitude", "-118.298662");
		obj1.put("latitude", "+33.786594");
		
		obj2.put("name", "ORANGE");
		obj2.put("longitude", "-117.769442");
		obj2.put("latitude", "+33.640302");

		String expected = "var _id = [{\"name\":\"PASADENA\",\"longitude\":\"-118.298662\",\"latitude\":\"+33.786594\"},{\"name\":\"ORANGE\",\"longitude\":\"-117.769442\",\"latitude\":\"+33.640302\"}];";
		
		//Act
		builder.addObject(obj1);
		builder.addObject(obj2);
		
		//Assert
		assertThat(builder.toJSONP("id"), is(equalTo(expected)));
	}
	
	@Test
	public void toJSONP_NObjects_BuildsJSONP() {
		//Arrange
		obj1.put("name", "PASADENA");
		obj1.put("longitude", "-118.298662");
		obj1.put("latitude", "+33.786594");

		obj2.put("name", "ORANGE");
		obj2.put("longitude", "-117.769442");
		obj2.put("latitude", "+33.640302");

		obj3.put("name", "TEST");
		obj3.put("longitude", "-120.769442");
		obj3.put("latitude", "+99.640302");
		
		String expected = "var _id = [{\"name\":\"PASADENA\",\"longitude\":\"-118.298662\",\"latitude\":\"+33.786594\"},{\"name\":\"ORANGE\",\"longitude\":\"-117.769442\",\"latitude\":\"+33.640302\"},{\"name\":\"TEST\",\"longitude\":\"-120.769442\",\"latitude\":\"+99.640302\"}];";
		
		//Act
		builder.addObject(obj1);
		builder.addObject(obj2);
		builder.addObject(obj3);
		
		//Assert
		assertThat(builder.toJSONP("id"), is(equalTo(expected)));
	}
}
