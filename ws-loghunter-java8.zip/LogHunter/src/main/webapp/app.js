//SyntaxError var 1name = "";
var $name = "";
//SyntaxError var -name = "";
var _name = "";
var na$me = "";
var na_me = "";
var na1me = "";
//SyntaxError var na-me = "";
//SyntaxError var na/me = "";

var model = {
	array : getArray()
};

function getArray() {
	return _2017_01_12;
}

function sortTable(sortFunction) {
	model.array.sort(sortFunction);
	//atualiza a tabela
	renderTable();
}

function renderTable() {
	var tableBody = document.getElementById("tableBody");
	tableBody.innerHTML = "";
	
	parseObjects(model.array);
	
	var td_Total = document.getElementById("td_Total");
	td_Total.innerHTML = model.array.length;		
}

function filterTable(filterValue) {
	var filteredArray = model.array.filter(function(obj) {
		if (obj.relatorio.toLowerCase().indexOf(filterValue.toLowerCase()) != -1)
			return true;
		return false;
	});
	model.array = filteredArray;
	renderTable();
}

window.onload = function() {
	renderTable();
	
	var titulo_Tabela = document.getElementById("titulo_Tabela");
	var dataInicio = model.array[0].inicio.substring(0, 10);
	titulo_Tabela.innerHTML = dataInicio.substring(8,10) + "/" + dataInicio.substring(5,7) + "/" + dataInicio.substring(0,4); 
	
	var btnSortDuracaoDesc = document.getElementById("sortDuracaoDesc");
	btnSortDuracaoDesc.onclick = function () {
		function sortDuracaoDesc(x, y) {
			var xDuracao = Number(x.duracaoMilis);
			var yDuracao = Number(y.duracaoMilis);
			return yDuracao - xDuracao;
		}

		sortTable(sortDuracaoDesc);
	};
	var btnSortDuracaoAsc = document.getElementById("sortDuracaoAsc");
	btnSortDuracaoAsc.onclick = function () {
		function sortDuracaoAsc(x, y) {
			var xDuracao = Number(x.duracaoMilis);
			var yDuracao = Number(y.duracaoMilis);
			return xDuracao - yDuracao;
		}

		sortTable(sortDuracaoAsc);
	};
	
	var btnSortDataInicioAsc = document.getElementById("sortDataInicioAsc");
	btnSortDataInicioAsc.onclick = function() {
		function sortDataInicioAsc(x, y) {
			if (x.inicio > y.inicio) {
				return 1;
			} else {
				return -1;
			}
			return 0;
		}

		sortTable(sortDataInicioAsc);
	};
	var btnSortDataInicioDesc = document.getElementById("sortDataInicioDesc");
	btnSortDataInicioDesc.onclick = function() {
		function sortDataInicioDesc(x, y) {
			if (x.inicio > y.inicio) {
				return -1;
			} else {
				return 1;
			}
			return 0;
		}
		
		sortTable(sortDataInicioDesc);
	};
	
	var btnSortTipoAsc = document.getElementById("sortTipoAsc");
	btnSortTipoAsc.onclick = function() {
		function sortTipoAsc(x, y) {
			if (x.tipo > y.tipo) {
				return 1;
			} else {
				return -1;
			}
			return 0;
		}

		sortTable(sortTipoAsc);
	};
	var btnSortTipoDesc = document.getElementById("sortTipoDesc");
	btnSortTipoDesc.onclick = function() {
		function sortTipoDesc(x, y) {
			if (x.tipo > y.tipo) {
				return -1;
			} else {
				return 1;
			}
			return 0;
		}
		
		sortTable(sortTipoDesc);
	};
	
	var btnSortRelatorioAsc = document.getElementById("sortRelatorioAsc");
	btnSortRelatorioAsc.onclick = function() {
		function sortRelatorioAsc(x, y) {
			if (x.relatorio > y.relatorio) {
				return 1;
			} else {
				return -1;
			}
			return 0;
		}

		sortTable(sortRelatorioAsc);
	};
	var btnSortRelatorioDesc = document.getElementById("sortRelatorioDesc");
	btnSortRelatorioDesc.onclick = function() {
		function sortRelatorioDesc(x, y) {
			if (x.relatorio > y.relatorio) {
				return -1;
			} else {
				return 1;
			}
			return 0;
		}
		
		sortTable(sortRelatorioDesc);
	};
	
	var inputFiltroRelatorio = document.getElementById("filtroRelatorio");
	inputFiltroRelatorio.onkeyup = function(e) {
		if (e.key === "Backspace" || e.key === "Delete") {
			model.array = getArray();
		}
		//console.log(e.key);
		
		filterTable(inputFiltroRelatorio.value);
	}
};

function parseObjects(array) {
	var table = document.getElementById("tableBody");
	
	for (var i in array) {
		var obj = array[i];
		addRecordToTable(obj, table);
	}
}

function addRecordToTable(obj, table) {
	var tr = document.createElement("tr");
/*
		for (var i in obj) {
			var td = createColumn(obj[i]);
			tr.appendChild(td);
		}
*/
	//id
	var td = createColumn(obj.id);
	tr.appendChild(td);
	//idBase64
	td = createColumn(obj.idBase64, true);
	tr.appendChild(td);
	//relatorio
	td = createColumn(obj.relatorio);
	tr.appendChild(td);
	//tipo
	td = createColumn(obj.tipo);
	tr.appendChild(td);
	//inicio
	td = createColumn(obj.inicio);
	tr.appendChild(td);
	//fim
	td = createColumn(obj.fim);
	tr.appendChild(td);
	//duracao
	td = createColumn(obj.duracao);
	tr.appendChild(td);
	//duracaoMilis
	td = createColumn(obj.duracaoMilis, true);
	tr.appendChild(td);
	
	table.appendChild(tr);
}

function createColumn(value, isHidden) {
	var col = document.createElement("td");
	col.innerHTML = value;
	if (isHidden) {
		col.setAttribute("class", "displayNone");
	}
	return col;
}
