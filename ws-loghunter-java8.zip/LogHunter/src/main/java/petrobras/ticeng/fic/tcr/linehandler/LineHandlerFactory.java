package petrobras.ticeng.fic.tcr.linehandler;

import petrobras.ticeng.fic.tcr.LogHunter;

public class LineHandlerFactory {

	public static LineHandler getLineHandler(String line) {
		LineHandler handler = null;
		if (line.matches(LogHunter.SEARCH_STRING_EXECUTE)) {
			handler = ExecuteHandler.getInstance(); 
		} else if (line.matches(LogHunter.SEARCH_STRING_SUCCESS)) {
			handler = SuccessHandler.getInstance();
		} else if (line.matches(LogHunter.SEARCH_STRING_FAILURE)) {
			handler = FailureHandler.getInstance();
		} else if (line.matches(LogHunter.SEARCH_STRING_REQUEST_FAILURE)) {
			handler = RequestFailureHandler.getInstance();
		}
		return handler;
	}
}
