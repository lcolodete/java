package petrobras.ticeng.fic.tcr.linehandler;

public class ExecuteHandler extends LineHandler {

	private static ExecuteHandler instance;
	
	private ExecuteHandler() {
	}
	
	@Override
	public void handleLine(String line) {
		this.lines.add(line);
		
		if ((this.lines.size() % 100) == 0) {
			System.out.println("hitsExecute="+this.lines.size());
		}
	}

	public static ExecuteHandler getInstance() {
		if (ExecuteHandler.instance == null)
			ExecuteHandler.instance = new ExecuteHandler();
		return ExecuteHandler.instance;
	}

}
