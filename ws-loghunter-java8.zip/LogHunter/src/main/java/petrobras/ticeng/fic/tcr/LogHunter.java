package petrobras.ticeng.fic.tcr;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import petrobras.ticeng.fic.tcr.json.JSONBuilder;
import petrobras.ticeng.fic.tcr.line.LogLine;
import petrobras.ticeng.fic.tcr.line.LogLineUtil;
import petrobras.ticeng.fic.tcr.line.RequestFailureLine;
import petrobras.ticeng.fic.tcr.linehandler.ExecuteHandler;
import petrobras.ticeng.fic.tcr.linehandler.FailureHandler;
import petrobras.ticeng.fic.tcr.linehandler.LineHandler;
import petrobras.ticeng.fic.tcr.linehandler.LineHandlerFactory;
import petrobras.ticeng.fic.tcr.linehandler.RequestFailureHandler;
import petrobras.ticeng.fic.tcr.linehandler.SuccessHandler;

/**
 * cogserver.log (é o mais recente)
 * cogserver.log.1 até 60 (.60 é o mais antigo)
 * 
 * Ler do 60 em diante
 * 
 * 
 * @author ur5g
 *
 */
public class LogHunter {

//	private static final String DIR = "C:/Users/ur5g/FIC/Logs/2017-01-04/";
	private static final String DIR = "C:/Users/ur5g/FIC/Logs/2017-01-12/";
	private static final String LOG_FILE = "cogserver.log";
	
	public static final String SEARCH_STRING_EXECUTE = ".*Execute	Report (BatchReportService|ReportService)	/content/folder\\[@name='FIC'\\]/package\\[@name='.*?'\\]/report\\[@name='.*?'\\]			<parameters>.*";
	public static final String SEARCH_STRING_SUCCESS = ".*Execute	Report (BatchReportService|ReportService)	/content/folder\\[@name='FIC'\\]/package\\[@name='.*?'\\]/report\\[@name='.*?'\\]	Success		<parameters>.*";
	public static final String SEARCH_STRING_FAILURE = ".*Execute	Report (BatchReportService|ReportService)	/content/folder\\[@name='FIC'\\]/package\\[@name='.*?'\\]/report\\[@name='.*?'\\]	Failure.* 	<parameters>.*";
	public static final String SEARCH_STRING_REQUEST_FAILURE = ".*Request			Failure	<messages>.*";
	
	private static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/out/";
	private static final String OUTPUT_FILE_EXECUTE = "output_execute_";
	private static final String OUTPUT_FILE_SUCCESS = "output_success_";
	private static final String OUTPUT_FILE_FAILURE = "output_failure_";
	private static final String OUTPUT_FILE_REQUEST_FAILURE = "output_request_failure_";
	private static final String OUTPUT_FILE_TOTAIS_POR_DIA = "output_totaisPorDia_";
	private static final String OUTPUT_FILE_SUCESSOS_POR_DIA = "output_sucessosPorDia_";
	private static final String OUTPUT_FILE_SUCESSOS_POR_DIA_JSON = "output_sucessosPorDia_JSON_";
	
	private static final boolean WRITE_INTERMEDIATE_FILES = false;
	
	public static void main(String[] args) throws Exception {
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
		String now = df.format(new Date());
		
		BufferedWriter outExecute = null;
		BufferedWriter outSuccess = null;
		BufferedWriter outFailure = null;
		BufferedWriter outRequestFailure = null;
		
		try (BufferedWriter outTotaisPorDia = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_TOTAIS_POR_DIA + now)), "UTF-8"))) {

			if (WRITE_INTERMEDIATE_FILES) {
				outExecute = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_EXECUTE + now)), "UTF-8"));
				outSuccess = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_SUCCESS + now)), "UTF-8"));
				outFailure = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_FAILURE + now)), "UTF-8"));
				outRequestFailure = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_REQUEST_FAILURE + now)), "UTF-8"));
			}
			
			//success files will always be created 
			BufferedWriter outSucessosPorDia = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_SUCESSOS_POR_DIA + now)), StandardCharsets.ISO_8859_1));
			BufferedWriter outSucessosPorDia_JSON = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_SUCESSOS_POR_DIA_JSON + now)), StandardCharsets.ISO_8859_1));

			File dir = new File(DIR);
			if (dir.isDirectory()) {
				
				String[] files = dir.list();
				List<String> list = Arrays.asList(files);
				for (int i = 60; i>=0; i--) {
					
					String filename = (i > 0 ? LOG_FILE+"."+i : LOG_FILE);
					
					if (list.contains(filename)) {

						System.out.println(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
						
						try (BufferedReader reader = Files.newBufferedReader(Paths.get(DIR, filename), StandardCharsets.ISO_8859_1)) {
							reader.lines()
							.filter(line -> {
								return (line.matches(LogHunter.SEARCH_STRING_EXECUTE) ||
										line.matches(LogHunter.SEARCH_STRING_SUCCESS) ||
										line.matches(LogHunter.SEARCH_STRING_FAILURE) ||
										line.matches(LogHunter.SEARCH_STRING_REQUEST_FAILURE) );
							})
							.forEach(line -> {
								LineHandler handler = LineHandlerFactory.getLineHandler(line);
								handler.handleLine(line);
							});
						}
						
						// FIM DE 1 ARQUIVO
						
						System.out.println("**************************");
						System.out.println("END OF FILE : "+filename);
						System.out.println("**************************");
						System.out.println("");
					}
					
				} // Lê o próximo arquivo

				// FIM DE TODOS OS ARQUIVOS
				
				if (WRITE_INTERMEDIATE_FILES) {
					ExecuteHandler.getInstance().writeResults(outExecute);
					SuccessHandler.getInstance().writeResults(outSuccess);
					FailureHandler.getInstance().writeResults(outFailure);
					RequestFailureHandler.getInstance().writeResults(outRequestFailure);
				}
				
				List<String> failureList = FailureHandler.getInstance().getLines();
				List<String> requestFailureList = RequestFailureHandler.getInstance().getLines();
				List<String> executeList = ExecuteHandler.getInstance().getLines();
				Map<String, Long> execucoesPorDia = groupByAndCount(executeList, LogLineUtil::getDateStr);
				
				//Cria um novo Set ordenado de dias
				List<String> days = execucoesPorDia.keySet().stream().sorted().collect(Collectors.toList());
				
				//Prints a report for each individual day
				days.forEach(key -> {
						System.out.println("Printing totals report for ["+key+"]");
						try {
							writeHeader(outTotaisPorDia, ">>>>>>>> TOTAIS DO DIA : " + key + " <<<<<<<<");
							
							writeHeader(outTotaisPorDia, "EXECUÇÕES POR RELATÓRIO:");
							StringBuilder sb5 = getExecucoesOuFalhasPorRelatorio(key, executeList);
							outTotaisPorDia.write(sb5.toString());
							
							writeHeader(outTotaisPorDia, "EXECUÇÕES POR HORA:");
							Map<String, Long> execucoesPorHora = getLinhasAgrupadas(key, executeList, LogLineUtil::getHour);
							StringBuilder sb6 = buildFromMap(execucoesPorHora);
							outTotaisPorDia.write(sb6.toString());
							
							writeHeader(outTotaisPorDia, "FALHAS POR RELATÓRIO:");
							StringBuilder sb7 = getExecucoesOuFalhasPorRelatorio(key, failureList);
							outTotaisPorDia.write(sb7.length() > 0 ? sb7.toString() : "\nN/A\n");
							
							writeHeader(outTotaisPorDia, "FALHAS POR HORA:");
							Map<String, Long> failureMap = getLinhasAgrupadas(key, failureList, LogLineUtil::getHour);
							StringBuilder sb8 = buildFromMap(failureMap, execucoesPorHora);
							outTotaisPorDia.write(sb8.length() > 0 ? sb8.toString() : "\nN/A\n");
							
							writeHeader(outTotaisPorDia, "FALHAS DE REQUEST POR RELATÓRIO:");
							StringBuilder sb9 = getRequestFailures(key, executeList, requestFailureList);
							outTotaisPorDia.write(sb9.length() > 0 ? sb9.toString() : "\nN/A\n");
							
							outTotaisPorDia.flush();
						} catch (Exception e) {
							e.printStackTrace();
						}
				}); // end of forEach
				
				//Prints final report encompassing the whole period
				String period = days.get(0) + " a " + days.get(days.size()-1);
				
				System.out.println("Printing final report, period : "+period);
				
				writeHeader(outTotaisPorDia, ">>>>>>>> TOTAIS DO PERÍODO : " + period + " <<<<<<<<");

				writeHeader(outTotaisPorDia, "EXECUÇÕES POR DIA:");
				StringBuilder sb = new StringBuilder();
				days.forEach(key -> {
					sb.append(key + " - " + execucoesPorDia.get(key));
					sb.append("\n");
				});
				outTotaisPorDia.write(sb.toString());
				
				writeHeader(outTotaisPorDia, "EXECUÇÕES POR RELATÓRIO:");
				StringBuilder sb2 = getExecucoesOuFalhasPorRelatorio(executeList);
				outTotaisPorDia.write(sb2.toString());
				
				//Manipula a lista de falhas
				writeHeader(outTotaisPorDia, "FALHAS POR DIA:");
				Map<String, Long> falhasPorDia = groupByAndCount(failureList, LogLineUtil::getDateStr);
				StringBuilder sb3 = buildFromMap(falhasPorDia, execucoesPorDia);
				outTotaisPorDia.write(sb3.toString());
				
				writeHeader(outTotaisPorDia, "FALHAS POR RELATÓRIO:");
				StringBuilder sb4 = getExecucoesOuFalhasPorRelatorio(failureList);
				outTotaisPorDia.write(sb4.toString());
				
				outTotaisPorDia.flush();
				
				///////// SUCESSOS COM TEMPOS DE EXECUCAO
				List<String> successList = SuccessHandler.getInstance().getLines();
				
				//build Map<String, List<String>> where (k,v) = (dateStr,List<success lines of the given date>)
				Map<String, List<String>> mapSuccess =
				successList.stream().collect(Collectors.groupingBy(LogLineUtil::getDateStr));

				days.forEach(key -> {
					System.out.println("Printing success report for ["+key+"]");
					try {
						writeHeader(outSucessosPorDia, ">>>>>>>> SUCESSOS DO DIA : "+ key + " <<<<<<<<"); 
						List<String> successOfDay = mapSuccess.get(key);
						StringBuilder sbSuccess = new StringBuilder();
						JSONBuilder jsonBuilder = new JSONBuilder();
						getFilteredStream(key, executeList)
						.forEach(line -> {
							//search success line
							successOfDay.stream()
										.filter(successLine -> {
											return ( LogLine.parseId(successLine).equals(LogLine.parseId(line)) &&
													 LogLine.parseIdBase64(successLine).equals(LogLine.parseIdBase64(line)) );
										})
										.map(LogLine::parse)
										.findFirst()
										.ifPresent(lineFound -> {
											//build success info
											sbSuccess.append("\n");
											sbSuccess.append("Id:       "+lineFound.getId());
											sbSuccess.append("\n");
											sbSuccess.append("IdBase64: "+lineFound.getIdBase64());
											sbSuccess.append("\n");
											sbSuccess.append("Report:   "+lineFound.getReportName());
											sbSuccess.append("\n");
											sbSuccess.append("Tipo:     "+lineFound.getType());
											sbSuccess.append("\n");
											String dataInicio = LogLine.parseDateTimeStr(line);
											sbSuccess.append("Início:   "+dataInicio);
											sbSuccess.append("\n");
											String dataFim = lineFound.getDateTime();
											sbSuccess.append("Fim:      "+dataFim);
											sbSuccess.append("\n");
											long duracaoMilis = calculaDuracao(dataInicio, dataFim);
											String duracao = getDurationFormatted_hms(duracaoMilis);
											sbSuccess.append("Duração:  "+duracao);
											sbSuccess.append("\n");
											
											Map<String, String> attributes = new HashMap<>();
											attributes.put("id", lineFound.getId());
											attributes.put("idBase64", lineFound.getIdBase64());
											attributes.put("relatorio", lineFound.getReportName());
											attributes.put("tipo", lineFound.getType());
											attributes.put("inicio", dataInicio);
											attributes.put("fim", dataFim);
											attributes.put("duracao", duracao);
											attributes.put("duracaoMilis", String.valueOf(duracaoMilis));
											jsonBuilder.addObject(attributes);
										});
						});
						
						outSucessosPorDia.write(sbSuccess.toString());
						outSucessosPorDia.newLine();
						outSucessosPorDia.write("TOTAL: "+mapSuccess.get(key).size());
						outSucessosPorDia.newLine();
						outSucessosPorDia.flush();
						
						outSucessosPorDia_JSON.write(jsonBuilder.toJSONP(key.replace("-", "_")));
						outSucessosPorDia_JSON.newLine();
						outSucessosPorDia_JSON.flush();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}); // end of forEach

				outSucessosPorDia.close();
				outSucessosPorDia_JSON.close();
			}
			
			
		} finally {
			if (outExecute != null)
				outExecute.close();
			if (outSuccess != null)
				outSuccess.close();
			if (outFailure != null)
				outFailure.close();
			if (outRequestFailure != null)
				outRequestFailure.close();
		}
	}
	
	private static StringBuilder getRequestFailures(String dateStr, List<String> executeList, List<String> requestFailureList) {
		
		StringBuilder sb = new StringBuilder();
		
		//build Map<String, List<String>> where (k,v) = (dateStr,List<requestFailure lines of the given date>)
		Map<String, List<String>> mapFailures =
		requestFailureList.stream().collect(Collectors.groupingBy(LogLineUtil::getDateStr));

		List<String> failuresOfDay = mapFailures.get(dateStr);

		if (failuresOfDay != null && !failuresOfDay.isEmpty()) {
			getFilteredStream(dateStr, executeList).forEach(line -> {
				failuresOfDay.stream()
				.filter(failureLine -> {
					return RequestFailureLine.parseId(failureLine).equals(LogLine.parseId(line));
				})
				.map(RequestFailureLine::parse)
				.findFirst()
				.ifPresent(failureLineObj -> {
					sb.append("\n");
					String reportName = LogLine.parseReportName(line);
					sb.append("Relatório: " + reportName);
					sb.append("\n");
					sb.append("ID: " + failureLineObj.getId());
					sb.append("\n");
					sb.append("Data: " + failureLineObj.getDateTime());
					sb.append("\n");
					sb.append("Erro: " + failureLineObj.getErrorMsg());
					sb.append("\n");
				});
			});
		}
		return sb;
	}

	private static long calculaDuracao(String startDate, String endDate) {
		long duracaoMilis = LogLine.parseDateTimeObject(endDate).getTime() - LogLine.parseDateTimeObject(startDate).getTime();
		return duracaoMilis;
	}

	private static String getDurationFormatted_hms(long duracao) {
		Date d = new Date(duracao);
		
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		c.setTime(d);
		
		int hora = c.get(Calendar.HOUR_OF_DAY);
		int min = c.get(Calendar.MINUTE);
		int seg = c.get(Calendar.SECOND);
		int ms = c.get(Calendar.MILLISECOND);
		
		StringBuilder durationStr = new StringBuilder();
		
		if (hora > 0) {
			if (String.valueOf(hora).length() < 2) {
				durationStr.append("0");
			}
			durationStr.append(hora)
			.append("h");
		}
		if (min > 0) {
			if (String.valueOf(min).length() < 2) {
				durationStr.append("0");
			}
			durationStr.append(min)
			.append("m");
		}
		
		if (seg > 0) {
			if (String.valueOf(seg).length() < 2) {
				durationStr.append("0");
			}
			durationStr.append(seg)
			.append("s");
		}
		
		durationStr.append(ms);
		
		return durationStr.toString();
	}

	
	private static StringBuilder buildFromMap(Map<String, Long> targetMap, Map<String, Long> auxMap) {
		//Armazena as chaves em uma lista ordenada, para imprimir em ordem crescente (de dias ou horas)
		List<String> keys = targetMap.keySet().stream().sorted().collect(Collectors.toList());
		
		StringBuilder sb = new StringBuilder();
		keys.forEach(key -> {
						sb.append(key + " - " + targetMap.get(key));
						if (auxMap != null)
							sb.append(" ( "+ calculaTaxaFalhas(targetMap.get(key), auxMap.get(key)) +" )");
						sb.append("\n");
		});
		return sb;
	}
	
	private static StringBuilder buildFromMap(Map<String, Long> map) {
		return buildFromMap(map, null);
	}
	
	/**
	 * 
	 * @param dateStr if present, is used to filter the list. String in the format yyyy-MM-dd
	 * @param list collection of lines : execution or failure
	 * @param function specifies the grouping criteria
	 * @return
	 */
	private static Map<String, Long> getLinhasAgrupadas(String dateStr, List<String> list, Function<String, String> function) {
		Stream<String> stream = null;
		if (dateStr == null) {
			stream = list.stream();
		} else {
			stream = getFilteredStream(dateStr, list);
		}
		
		Map<String, Long> map = groupByAndCount(stream, function);
		return map;
	}
	
	private static StringBuilder getExecucoesOuFalhasPorRelatorio(List<String> list) {
		return getExecucoesOuFalhasPorRelatorio(null, list);
	}
	
	/**
	 * 
	 * @param dateStr String in the format yyyy-MM-dd
	 * @param list
	 * @param failureList
	 */
	private static StringBuilder getExecucoesOuFalhasPorRelatorio(String dateStr, List<String> list) {
		StringBuilder sb = new StringBuilder();
		
		Stream<String> stream = null;
		if (dateStr == null) {
			stream = list.stream();
		} else {
			stream = getFilteredStream(dateStr, list);
		}
		
		Map<String, Long> map = groupByAndCount(stream, LogLine::parseReportName);
		map.entrySet()
			.stream()
			.sorted((e1, e2) -> {
				return (int) (e2.getValue() - e1.getValue()) ;
			})
		   .forEach(entry -> {
						sb.append(getReportWithPadding(entry.getKey()) + "- " + entry.getValue());
						sb.append("\n");
				  });
		
		Long sum = map.values().stream().collect(Collectors.summingLong(n -> n));
		
		sb.append("\n");
		sb.append("TOTAL: "+sum);
		sb.append("\n");
		
		return sb;
	}

	/**
	 * 
	 * @param dateStr String in the format yyyy-MM-dd
	 */
	private static Stream<String> getFilteredStream(String dateStr, List<String> list) {
		Stream<String> stream;
		String[] dateComponents = dateStr.split("-");
		String year = dateComponents[0];
		String month = dateComponents[1]; 
		String day = dateComponents[2];
		
		stream = list.stream()
					 .filter(line -> line.matches(".*"+LogLine.getRegexDateTime(day, month, year)+".*"));
		return stream;
	}

	private static Map<String, Long> groupByAndCount(List<String> list, Function<String, String> groupingFunction) {
		return groupByAndCount(list.stream(), groupingFunction);
	}
	
	private static Map<String, Long> groupByAndCount(Stream<String> stream, Function<String, String> groupingFunction) {
		return stream.collect(Collectors.groupingBy(groupingFunction, Collectors.counting()));

	}

	private static void writeHeader(BufferedWriter out, String header) throws IOException {
		out.newLine();
		out.write(header);
		out.newLine();
	}

	private static String getReportWithPadding(String report) {
		StringBuilder sb = new StringBuilder(report);
		
		if (report.length() < 55) {
			StringBuilder padding = new StringBuilder();
			for (int i = 0; i< 55 - report.length(); i++) {
				padding.append(" ");
			}
			
			sb.append(padding, 0, padding.length());
		}
		return sb.toString();
	}
	
	private static String calculaTaxaFalhas(Long numFailures, Long numExecutions) {
		NumberFormat nf = NumberFormat.getPercentInstance();
		nf.setMaximumFractionDigits(2);
		nf.setMinimumFractionDigits(2);
		
		Double dExecucoes = null;
		Double taxaFalhas = null;
		
		//se nao houve execucoes naquela hora, somente falhas
		//Exemplo: 1 relatorio comecou as 16h53, mas so terminou com falha as 17h49 (e nesse intervalo, nenhum relatorio foi solicitado)
		if (numExecutions == null || numExecutions == 0) {
			taxaFalhas = 1D;
		} else {
			dExecucoes = (double) numExecutions;
			taxaFalhas = numFailures/dExecucoes;
		}
		
		return nf.format(taxaFalhas);
	}
	
}
