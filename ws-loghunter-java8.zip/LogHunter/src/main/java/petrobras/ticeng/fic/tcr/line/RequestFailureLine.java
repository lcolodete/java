package petrobras.ticeng.fic.tcr.line;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import petrobras.ticeng.fic.tcr.util.RegexUtils;

public class RequestFailureLine {
	
	private String dateTime;
	private Date dateTimeObj;
	private String id;
	private String errorMsg;
	private String errorMsgFull;

	public RequestFailureLine(String id, Date dateTimeObj, String dateTime, String errorMsg, String errorMsgFull) {
		this.dateTime = dateTime;
		this.dateTimeObj = dateTimeObj;
		this.id = id;
		this.errorMsg = errorMsg;
		this.errorMsgFull = errorMsgFull;
	}

	public String getId() {
		return this.id;
	}
	
	public String getErrorMsg() {
		return this.errorMsg;
	}
	
	public String getDateTime() {
		return this.dateTime;
	}
	
	@Override
	public String toString() {
		return this.id + " " + this.dateTime + " " + this.errorMsg + " " + this.errorMsgFull;
	}
	
	public static void main(String[] args) throws ParseException {
		String lineToParse = "10.29.170.143:9300	15151	2017-01-03 14:21:23.750	-3	4306B59B498599BE0D454EFA7B2C1BCC248A6542	j44d2h8yhsMyy2dGl2shjqvl8jCddj49qwlCw4jj	0		http-9300-20	DISP	6305	2	Audit.Other.dispatcher.DISP.com.cognos.pogo.handlers.engine.ServiceLookupHandler	Request			Failure	<messages><message><messageString>The server did something wrong</messageString></message><message><messageString>DPR-ERR-2087 The request has exceeded the execution time limit. It will be cancelled.</messageString></message></messages>	cognosViewerDPR-ERR-2082 An error has occurred. Please contact your administrator. The complete error has been logged by CAF with SecureErrorID:2017-01-03-14:21:23.745-#1640";
		RequestFailureLine e = RequestFailureLine.parse(lineToParse);
		
		System.out.println(e);
		
		Date d = e.dateTimeObj;
		
		//Cria um Calendar para inspecionar os campos do objeto Date
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		System.out.println( c.get(Calendar.DAY_OF_MONTH) );
		System.out.println( c.get(Calendar.MONTH) );
		System.out.println( c.get(Calendar.YEAR) );
		System.out.println( c.get(Calendar.HOUR_OF_DAY) );
		
		System.out.println( e.errorMsg );
	}

	public static RequestFailureLine parse(String s) {
		String dateTime = parseDateTimeStr(s);
		Date dateTimeObj = parseDateTimeObject(s);
		String id = parseId(s);
		String errorMsg = parseErrorMsg(s);
		String errorMsgFull = parseErrorMsgFull(s);
		
		RequestFailureLine lineObj = new RequestFailureLine(id, dateTimeObj, dateTime, errorMsg, errorMsgFull);
		return lineObj;
	}

	public static Date parseDateTimeObject(String s) {
		String dateTimeStr = parseDateTimeStr(s);
		Date dateTimeObj = null;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		try {
			dateTimeObj = df.parse(dateTimeStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTimeObj;
	}
	
	public static String parseDateTimeStr(String s) {
		return RegexUtils.find(LogLine.REGEX_DATE_TIME, s);
	}
	
	public static String parseId(String s) {
		String result = "";
		try {
			result = RegexUtils.find("[A-F0-9]{40}", s);
		} catch(Exception e) {
		}
		
		return result;
	}

	private static String parseErrorMsg(String s) {
		
		String errorMsg = null;
		try {
			String reportFound = RegexUtils.find("Failure	<messages>.*</messages>", s);
			String[] reportParts = reportFound.split("Failure	<messages>");
			errorMsg = reportParts[1].split("</messages>")[0].trim();
			
			errorMsg = errorMsg.replaceAll("<message><messageString>", " >> ")
					.replaceAll("</messageString></message>", "");
		} catch (IllegalArgumentException e) {
			errorMsg = "N/A";
		}
		return errorMsg;
	}
	
	private static String parseErrorMsgFull(String s) {
		
		String errorMsg = null;
		try {
			String[] result = s.split("Request			Failure	");
			errorMsg = result[1];
		} catch (IllegalArgumentException e) {
			errorMsg = "N/A";
		}
		return errorMsg;
	}

}
