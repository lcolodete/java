package petrobras.ticeng.fic.tcr.line;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import petrobras.ticeng.fic.tcr.util.RegexUtils;

/**
 * Representa uma linha de execução no arquivo de totais do dia.
 * <br>
 * Exemplo:<br>
 * <br>
 * <code>2015-05-19 14:11:13.201	1F3EFCA3A9E3ED082122EFCBC523B7E110402AF2	report[@name='FIC_FVM']</code>
 * <br><br>
 * A linha tem 3 componentes :<br>
 * <br>
 * 1) Data e hora da execução<br>
 * 2) Identificador da execução (id)<br>
 * 3) Nome do relatório executado<br>
 * 4) Tipo: online ou background<br>
 * 5) Identificador da execução em base64 (idBase64)
 * 
 * @author ur5g
 *
 */
public class LogLine {
	
	public static final String REGEX_DATE_TIME = getRegexDateTime();
	
	private String dateTime;
	private Date dateTimeObj;
	private String id;
	private String reportName;
	private String type;
	private String errorMsg;
	private String idBase64;
	
	public LogLine(String dateTime, Date dateTimeObj, String id, String reportName, String type, String errorMsg, String idBase64) {
		this.dateTime = dateTime;
		this.dateTimeObj = dateTimeObj;
		this.id = id;
		this.reportName = reportName;
		this.type = type;
		this.errorMsg = errorMsg;
		this.idBase64 = idBase64;
	}

	public String getIdBase64() {
		return idBase64;
	}

	protected String getErrorMsg() {
		return errorMsg;
	}

	public String getType() {
		return type;
	}

	public Date getDateTimeObject() {
		return this.dateTimeObj;
	}
	
	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public static LogLine parse(String s) {
		
		String dateTime = parseDateTimeStr(s);
		Date dateTimeObj = parseDateTimeObject(s);
		String id = parseId(s);
		String reportName = parseReportName(s);
		String type = parseType(s);
		String errorMsg = parseErrorMsg(s);
		String idBase64 = parseIdBase64(s);
		
		LogLine executeLine = new LogLine(dateTime, dateTimeObj, id, reportName, type, errorMsg, idBase64); 
		
		return executeLine;
	}

	private static String parseErrorMsg(String s) {
		
		String errorMsg = null;
		try {
			String reportFound = RegexUtils.find("report\\[@name='.*'\\]	.* 	<parameters>", s);
			String[] reportParts = reportFound.split("report\\[@name='.*'\\]");
			errorMsg = reportParts[1].split("<parameters>")[0].trim();
		} catch (IllegalArgumentException e) {
			errorMsg = "N/A";
		}
		return errorMsg;
	}

	public static String parseType(String s) {
		
		String reportFound = RegexUtils.find("Audit.RTUsage.RSVP	Execute	Report .*	/content/folder\\[@name='FIC'\\]", s);

		if (reportFound.contains("BatchReportService"))
			return "background";
		return "online";
	}

	public static Date parseDateTimeObject(String s) {
		String dateTimeStr = parseDateTimeStr(s);
		Date dateTimeObj = null;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		try {
			dateTimeObj = df.parse(dateTimeStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTimeObj;
	}
	
	public static String parseDateTimeStr(String s) {
		return RegexUtils.find(REGEX_DATE_TIME, s);
	}
	
	public static String parseId(String s) {
		return RegexUtils.find("[A-F0-9]{40}", s);
	}
	
	public static String parseIdBase64(String s) {
		
		String reportFound = RegexUtils.find("[A-F0-9]{40}	[A-Za-z0-9]{40}	", s);
		
		String[] reportParts = reportFound.split("[A-F0-9]{40}");
		String idBase64 = reportParts[1].trim();
		
		return idBase64;
	}
	
	public static String parseReportName(String s) {
		String reportFound = RegexUtils.find("report\\[@name='.*?'\\]", s);
		
		String[] reportParts = reportFound.split("=");
		String reportName = reportParts[1].replaceAll("'", "").replace("]", "");
		
		return reportName;
	}

	@Override
	public String toString() {
		return this.dateTime + " " + this.id + " " + this.idBase64 + " " + this.reportName + " " + this.type;
	}

	public static String getRegexDateTime() {
		return getRegexDateTime("[\\d]{2}", "[\\d]{2}", "[\\d]{4}"); 
	}
	
	public static String getRegexDateTime(String... dateParts) {
		String regex = "Y-M-D [\\d]{2}:[\\d]{2}:[\\d]{2}.[\\d]{3}";
		if (dateParts != null && dateParts.length > 0) {
			String day = dateParts[0]; 
			String month = dateParts[1];
			String year = dateParts[2];
			regex = regex.replace("Y", year)
						 .replace("M", month)
						 .replace("D", day);
		}
		return regex;
	}
	
	public static void main(String[] args) throws ParseException {
//		String lineToParse = "10.29.170.61:16310	19458	2015-05-19 15:58:30.313	-3	DA4DA4A6F0DDCCE41DA040D9CDFCFABDDE947CDE	M9dv8jhwCwvM2CMhwqqwCy298GjCw82Ch2Cdd9Mv	M9dv8jhwCwvM2CMhwqqwCy298GjCw82Ch2Cdd9Mv		1609796496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report ReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_CCMPackage']/report[@name='FIC_CCM_COMPLETO']	Failure	RSV-SRV-0066 A soap fault has been returned. RQP-DEF-0112 Query execution time exceeds the 20 second limit specified for the user who has the identity '{All Authenticated Users, Everyone, Authors, Query Users, Consumers, Metrics Authors, Metrics Users, Planning Contributor Users, Controller Users, Analysis Users, PowerPlay Users, Data Manager Authors, Readers, Express Authors, Adaptive Analytics Users, System Administrators, DEFLTREG, ENGEP-IEUEP-II-IECO-P74, ENGEP-IEUEP-II-IECO-P75, ENGEP-IEUEP-II-IECO-P76, ENGEP-IEUEP-II-IECO-P77, EVERYONE, FIC_CONSULTANTE}'. 	<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_CCMPackage']/model[@name='2011-08-15T20:21:03.905Z']]]></item><item name=\"storeID\"><![CDATA[i6EB092EDAC7544028133CB5911E091ED]]></item></parameters>";
//		String lineToParse = "10.29.170.143:9300	11642	2016-12-29 07:34:34.265	-3	E750D3654965271EC66F1493AE9D90FC4870C229	9G2MChwGhll8vCsqd2C9hjlvMvwMhMy9C4vMyy42	9G2MChwGhll8vCsqd2C9hjlvMvwMhMy9C4vMyy42		-430683280	RSVP	6305	3	Audit.RTUsage.RSVP	Execute	Report BatchReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_CADBASPackage']/report[@name='FIC_Cadastro_Geral']			<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_CADBASPackage']/model[@name='2011-08-15T20:19:55.524Z']]]></item><item name=\"storeID\"><![CDATA[iD5224EF590744D738EEA4CA5CF10CB33]]></item></parameters>";
		String lineToParse = "10.29.170.143:9300	15151	2017-01-03 14:21:23.750	-3	4306B59B498599BE0D454EFA7B2C1BCC248A6542	j44d2h8yhsMyy2dGl2shjqvl8jCddj49qwlCw4jj	0		http-9300-20	DISP	6305	2	Audit.Other.dispatcher.DISP.com.cognos.pogo.handlers.engine.ServiceLookupHandler	Request			Failure	<messages><message><messageString>The server did something wrong</messageString></message><message><messageString>DPR-ERR-2087 The request has exceeded the execution time limit. It will be cancelled.</messageString></message></messages>	cognosViewerDPR-ERR-2082 An error has occurred. Please contact your administrator. The complete error has been logged by CAF with SecureErrorID:2017-01-03-14:21:23.745-#1640";
		LogLine e = LogLine.parse(lineToParse);
		
		System.out.println(e);
		
		Date d = e.getDateTimeObject();
		
		//Cria um Calendar para inspecionar os campos do objeto Date
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		System.out.println( c.get(Calendar.DAY_OF_MONTH) );
		System.out.println( c.get(Calendar.MONTH) );
		System.out.println( c.get(Calendar.YEAR) );
		System.out.println( c.get(Calendar.HOUR_OF_DAY) );
		
		System.out.println( LogLineUtil.getDayAndMonth(e) );
		System.out.println( LogLineUtil.getDay(e) );
		System.out.println( LogLineUtil.getHour(e) );
		System.out.println( e.getType() );
		System.out.println( e.getErrorMsg() );
		System.out.println( e.getIdBase64() );
	}
}
