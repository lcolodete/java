package petrobras.ticeng.fic.tcr.line;

import java.util.Calendar;
import java.util.Date;

import petrobras.ticeng.fic.tcr.util.RegexUtils;

public class LogLineUtil {

	public static String getDayAndMonth(LogLine e) {
		return getDayAndMonthStr(e, true);
	}

	private static String getDayAndMonthStr(LogLine e, boolean dayFirst) {
		Date d = e.getDateTimeObject();
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int month = c.get(Calendar.MONTH) + 1;
		String monthStr = Integer.toString(month);
		monthStr = (month < 10) ? "0"+monthStr : monthStr;
		
		String dayStr = LogLineUtil.getDay(e); 

		if (dayFirst) {
			return dayStr+"/"+monthStr;
		}
		return monthStr+"/"+dayStr;
	}
	
	public static String getMonthAndDay(LogLine e) {
		return getDayAndMonthStr(e, false);
	}
	
	/**
	 * Extracts the day and the month from the given line.
	 * 
	 * @param line
	 * @return a String in the following format : MM/DD
	 */
	public static String getMonthAndDay(String line) {
		
		Date d = LogLine.parseDateTimeObject(line);
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int month = c.get(Calendar.MONTH) + 1;
		String monthStr = Integer.toString(month);
		monthStr = (month < 10) ? "0"+monthStr : monthStr;
		
		String dayStr = LogLineUtil.getDay(line);
		
		return monthStr+"/"+dayStr;
	}
	
	/**
	 * Extracts the full date from the given line.
	 * 
	 * @param line
	 * @return String in the format yyyy-MM-dd
	 */
	public static String getDateStr(String line) {
		//extracts date and time
		String dateTimeStr = LogLine.parseDateTimeStr(line);
		//extracts just the date part
		String dateStr = RegexUtils.find("[\\d]{4}-[\\d]{2}-[\\d]{2}", dateTimeStr);
		return dateStr;
	}
	
	public static String getDay(LogLine e) {
		Date d = e.getDateTimeObject();
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int day = c.get(Calendar.DAY_OF_MONTH);
		String dayStr = Integer.toString(day);
		dayStr = (day < 10) ? "0"+dayStr : dayStr; 
		
		return dayStr;
	}
	
	public static String getDay(String line) {
		Date d = LogLine.parseDateTimeObject(line);
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int day = c.get(Calendar.DAY_OF_MONTH);
		String dayStr = Integer.toString(day);
		dayStr = (day < 10) ? "0"+dayStr : dayStr; 
		
		return dayStr;
	}
	
	public static String getHour(LogLine e) {
		Date d = e.getDateTimeObject();
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int hour = c.get(Calendar.HOUR_OF_DAY);
		String hourStr = Integer.toString(hour);
		hourStr = (hour < 10) ? "0"+hourStr : hourStr; 
		
		return hourStr;
	}
	
	/**
	 * Extracts the hour from the given line.
	 * 
	 * @param line
	 * @return
	 */
	public static String getHour(String line) {
		Date d = LogLine.parseDateTimeObject(line);
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int hour = c.get(Calendar.HOUR_OF_DAY);
		String hourStr = Integer.toString(hour);
		hourStr = (hour < 10) ? "0"+hourStr : hourStr; 
		
		return hourStr;
	}
	
}
