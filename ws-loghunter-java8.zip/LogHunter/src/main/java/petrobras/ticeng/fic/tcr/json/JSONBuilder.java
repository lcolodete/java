package petrobras.ticeng.fic.tcr.json;

import java.util.Map;
import java.util.Map.Entry;

public class JSONBuilder {

	private StringBuilder objList = new StringBuilder();
	
	public String toJSONP(String s) {
		StringBuilder jsonP = new StringBuilder();
		jsonP.append("var _"+s+" = [");
		jsonP.append(objList);
		jsonP.append("];");
		return jsonP.toString();
	}
	
	/**
	 * Modifies the underlying StringBuilder by appending the supplied arguments
	 * like so: "name":"value"
	 *  
	 * @param name
	 * @param value
	 */
	private void setAttribute(String name, String value) {
		this.appendWithQuotes(name);
		this.objList.append(":");
		this.appendWithQuotes(value);
	}
	
	/**
	 * Adds a new object to this JSON string.
	 * 
	 * @param attributes
	 */
	public void addObject(Map<String, String> attributes) {
		if (this.objList.length() > 0) 
			this.objList.append(",");
		this.objList.append("{");
		int count = 0;
		for (Entry<String, String> e : attributes.entrySet()) {
			if (count > 0)
				this.objList.append(",");
			this.setAttribute(e.getKey(), e.getValue());
			count++;
		}
		this.objList.append("}");
	}
	
	private void appendWithQuotes(String name) {
		this.objList.append("\"")
		.append(name)
		.append("\"");
	}
}
