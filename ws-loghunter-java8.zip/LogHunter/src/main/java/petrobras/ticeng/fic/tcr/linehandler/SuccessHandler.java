package petrobras.ticeng.fic.tcr.linehandler;

public class SuccessHandler extends LineHandler {

	private static SuccessHandler instance;
	
	private SuccessHandler() {
	}

	@Override
	public void handleLine(String line) {
		this.lines.add(line);
		
		if ((this.lines.size() % 100) == 0) {
			System.out.println("hitsSuccess="+this.lines.size());
		}
	}

	public static SuccessHandler getInstance() {
		if (SuccessHandler.instance == null)
			SuccessHandler.instance = new SuccessHandler();
		return SuccessHandler.instance;
	}

}
