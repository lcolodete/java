package petrobras.ticeng.fic.maximo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

/**
 * Busca uma expressao regular em todos os arquivos indicados no diretorio de entrada.
 * Produz um arquivo de saida com as linhas encontradas.
 * 
 * @author ur5g
 *
 */
public class LogHunter {

//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-11-05/";
	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/";
	
//	private static final String SEARCH_STRING_NoRouteToHostException = ".*java\\.net\\.NoRouteToHostException.*";
	private static final String SEARCH_STRING_BMXAA7732W = ".*BMXAA7732W.*";
	
	private static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/maximo/out/";
	private static final String OUTPUT_FILE = "output_";
	
	private static BufferedWriter out2 = null;
	
	public static void main2(String[] args) {
		String s = "C:/Users/ur5g/FIC/Logs/2018-03-07/ferrol.petrobras.biz_MXServer1_fic_maximo.log2018-03-06";
		System.out.println( s.matches(".*ferrol.*|sabadell.*|mirandes.*|oviedo.*|tenerife.*") );
	}
	
	public static void main(String[] args) throws IOException {
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
		
		String now = df.format(new Date());
		
		out2 = new BufferedWriter(new FileWriter(OUTPUT_DIR + OUTPUT_FILE + now));
			
		Files.walkFileTree(Paths.get(INPUT_DIR), new LogFileVisitor());
	}
	
	static class LogFileVisitor extends SimpleFileVisitor<Path> {
		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {

			System.out.println(">>>>>>>>>>>>>>>>>>>>>> File : " + file.toAbsolutePath());
			System.out.println(">>>>>>>>>>>>>>>>>>>>>> FileName : " + file.getFileName());
			
			if (file.getFileName().toString().matches("ferrol.*|sabadell.*|mirandes.*|oviedo.*|tenerife.*")) {
				int hits = 0;
				
				int lineNumber = 0;
				
				BufferedReader in = null;
				
				try {
					in = new BufferedReader(new InputStreamReader(new FileInputStream(file.toFile()), "UTF-8"));
					
					String line = null;
					
					while ( (line = in.readLine()) != null ) {
						
						lineNumber++;
						if (lineNumber == 1) {
							out2.write(">>>>>>>>>>>>>>>>>>>>>> File : " + file.toAbsolutePath());
							out2.newLine();
						}
						
						if ((lineNumber % 25000) == 0) {
							System.out.println("Processando linha "+lineNumber);
						}
						
						if ( line.matches(SEARCH_STRING_BMXAA7732W) ) {
							
							hits++;
							
//							out2.write("Line "+lineNumber+": "+line);
//							out2.newLine();
						}
						
					} // Le a proxima linha
					
					// FIM DE 1 ARQUIVO
					
				} finally {
					if (in != null)
						in.close();
				}
				
				out2.write("Hits : "+hits);
				out2.newLine();
				out2.newLine();
				
				out2.flush();
				
				System.out.println("**************************");
				System.out.println("Search complete ("+hits+" hits in file \""+ file.toAbsolutePath() +"\")");
				System.out.println("**************************");
				System.out.println("");
			} else {
				System.out.println("File skipped.");
			}
			
			
			return FileVisitResult.CONTINUE;
		}
	}
	
	public static void main3(String[] args) throws Exception {
		
		BufferedReader in = null;
		BufferedWriter out = null; 
		
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
			
			String now = df.format(new Date());
			
			out = new BufferedWriter(new FileWriter(OUTPUT_DIR + OUTPUT_FILE + now));
			
			File dir = new File(INPUT_DIR);
			if (dir.isDirectory()) {
				
				File[] files = dir.listFiles();
				
				Set<File> fileSet = new TreeSet<File>(Arrays.asList(files));
				
				for (File file : fileSet) {
					
					if (file.isFile()) {
					
						int hits = 0;
						
						int lineNumber = 0;
						
						in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
						
						System.out.println(">>>>>>>>>>>>>>>>>>>>>> File : " + file.getName());
						
						String line = null;
						
						while ( (line = in.readLine()) != null ) {
							
							lineNumber++;
							if (lineNumber == 1) {
								out.write(">>>>>>>>>>>>>>>>>>>>>> File : " + file.getName());
								out.newLine();
							}
							
							if ((lineNumber % 25000) == 0) {
								System.out.println("Processando linha "+lineNumber);
							}

//							if ( line.matches(SEARCH_STRING_NoRouteToHostException) ) {
							if ( line.matches(SEARCH_STRING_BMXAA7732W) ) {
								
								hits++;
								
								out.write("Line "+lineNumber+": "+line);
								out.newLine();
								
								if ((hits % 500) == 0) {
									System.out.println("out.flush() => hits="+hits);
									out.flush();
								}
								
								
							}
							
							
						} // Le a proxima linha
						
						// FIM DE 1 ARQUIVO

						out.write("Hits : "+hits);
						out.newLine();
						
						//SEARCH_STRING_NoRouteToHostException
//						out.write("Ocorrencias do erro (hits/2) : "+hits/2);
//						out.newLine();
						
						out.newLine();

						System.out.println("**************************");
						System.out.println("Search complete ("+hits+" hits in file \""+ file +"\")");
						System.out.println("**************************");
						System.out.println("");
						
						if (in != null)
							in.close();
						
						in = null;
					}	
					
					
				} // Le o proximo arquivo

				// FIM DE TODOS OS ARQUIVOS
				
			}
			
			
		} finally {
			if (in != null)
				in.close();
			if (out != null)
				out.close();
		}
		
		
	}
	
	
}


