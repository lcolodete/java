package petrobras.ticeng.fic.tcr.linehandler;

public class FailureHandler extends LineHandler {
	
	private static FailureHandler instance;
	
	private FailureHandler() {
	}
	
	@Override
	public void handleLine(String line) {
		this.lines.add(line);
		
		if ((this.lines.size() % 10) == 0) {
			System.out.println("hitsFailure="+this.lines.size());
		}
	}

	public static FailureHandler getInstance() {
		if (FailureHandler.instance == null) 
			FailureHandler.instance = new FailureHandler();
		return FailureHandler.instance;
	}

}
