package petrobras.ticeng.fic.tcr_apache;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ApacheLogLine implements Comparable<ApacheLogLine> {

	private String user;
	private String JSESSIONID;
	private String reportName;
	private String ipAddress;
	private Date dateTime;
	
	public ApacheLogLine(String user, String jSESSIONID, String reportName, String ipAddress, Date dateTime) {
		this.user = user;
		this.JSESSIONID = jSESSIONID;
		this.reportName = reportName;
		this.ipAddress = ipAddress;
		this.dateTime = dateTime;
	}

	public static ApacheLogLine parse(String s) {
//		String user = parseUser(s);
		String user = parseUser_CAMID(s);
		String JSESSIONID = parseJSESSIONID(s);
		String reportName = parseReportName(s);
		String ipAddress = parseIpAddress(s);
		Date dateTime = parseDateTime(s);
		
		return new ApacheLogLine(user, JSESSIONID, reportName, ipAddress, dateTime);
	}
	
	
	private static Date parseDateTime(String s) {
		Date dateTime = null;
		
		String strDate = find("[\\d]{2}/[\\w]{3}/[\\d]{4}:[\\d]{2}:[\\d]{2}:[\\d]{2}", s); 
		strDate = strDate.replaceAll("/", "-")
				  		 .replaceFirst(":", " ");

		DateFormat df_en_GB = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, new Locale("en", "GB"));
		try {
			dateTime = df_en_GB.parse(strDate);
		} catch (ParseException e) {
			System.out.println("ApacheLogLine.parseDateTime() falhou na seguinte linha: "+s);
			e.printStackTrace();
		}
		
		return dateTime;
	}

	private static String parseIpAddress(String s) {
		String ipAddress = null;
		ipAddress = find("^[\\d]{1,3}\\.[\\d]{1,3}\\.[\\d]{1,3}\\.[\\d]{1,3}", s);
		return ipAddress;
	}

	private static String parseReportName(String s) {
		String reportName = null;
		
		String reportNameFound = find("report%5b%40name%3d%27[\\w\\s]+%27%5d", s);
		String[] reportNameParts = reportNameFound.split("%27");
		reportName = reportNameParts[1].replaceAll("%27%5d", "");
		
		return reportName;
	}

	private static String parseJSESSIONID(String s) {
		String JSESSIONID = null;
		
		String JSESSIONID_found = find("JSESSIONID=.*", s);
		String[] JSESSIONID_parts = JSESSIONID_found.split(";");
		JSESSIONID = JSESSIONID_parts[0].split("=")[1].replaceAll("\"", "");
		
		return JSESSIONID;
	}

	private static String parseUser(String s) {
		String user = null;
		
		try {
			String userFound = find("\\|e_user:.*\\|", s);
			String[] userParts = userFound.split("\\|");
			user = userParts[1].replaceAll("e_user:", "");
		} catch (IllegalArgumentException e) {
			throw e;
		}
		
		return user;
	}
	
	private static String parseUser_CAMID(String s) {
		String user = null;
		
		try {
			String userFound = find("CAMID\\(\\*22maximo\\*3au\\*3a.*\\*22\\)", s);
			String[] userParts = userFound.split("\\*3a");
			user = userParts[2].split("\\*22\\)")[0];
		} catch (IllegalArgumentException e) {
			throw e;
		}
		
		return user;
	}

	private static String find(String regex, String s) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(s);
		
		String field = "";
		
		if (m.find()) {
			field = m.group();
		} else {
			throw new IllegalArgumentException("A regex "+regex+" nao encontrou nenhum resultado.");
		}
		
		return field;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getJSESSIONID() {
		return JSESSIONID;
	}

	public void setJSESSIONID(String jSESSIONID) {
		JSESSIONID = jSESSIONID;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	
	@Override
	public int compareTo(ApacheLogLine o) {
		return this.user.compareToIgnoreCase(o.getUser());
	}

	public static void main(String[] args) throws ParseException {
		Date d = new Date();
		Calendar c = Calendar.getInstance();
		c.set(2015, Calendar.SEPTEMBER, 30);
		
		DateFormat df = DateFormat.getDateInstance(DateFormat.DEFAULT, new Locale("en", "GB"));
		
		DateFormat t = DateFormat.getTimeInstance(DateFormat.DEFAULT, new Locale("en", "GB"));
		
		DateFormat df_en_GB = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, new Locale("en", "GB"));
		
		DateFormat df_pt_BR = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, new Locale("pt", "BR"));
		
		System.out.println(df.format(d));
		System.out.println(df.format(c.getTime()));
		System.out.println("2="+df_en_GB.format(d));
		System.out.println("2="+df_en_GB.format(c.getTime()));
		System.out.println(t.format(d));
		
		String strDate = "30/Oct/2015:22:22:04 -0300";
		
		strDate = strDate.split(" ")[0]
						  .replaceAll("/", "-")
						  .replaceFirst(":", " ");
		
		
		Date dateParsed = df_en_GB.parse(strDate);
		System.out.println(df_pt_BR.format(dateParsed));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((JSESSIONID == null) ? 0 : JSESSIONID.hashCode());
		result = prime * result
				+ ((reportName == null) ? 0 : reportName.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApacheLogLine other = (ApacheLogLine) obj;
		if (JSESSIONID == null) {
			if (other.JSESSIONID != null)
				return false;
		} else if (!JSESSIONID.equals(other.JSESSIONID))
			return false;
		if (reportName == null) {
			if (other.reportName != null)
				return false;
		} else if (!reportName.equals(other.reportName))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ApacheLogLine [user=" + user + ", JSESSIONID=" + JSESSIONID
				+ ", reportName=" + reportName + "]";
	}
	
}

class DateTimeComparator implements Comparator<ApacheLogLine> {
	@Override
	public int compare(ApacheLogLine line1, ApacheLogLine line2) {
		return line1.getDateTime().compareTo(line2.getDateTime());
	}
}
