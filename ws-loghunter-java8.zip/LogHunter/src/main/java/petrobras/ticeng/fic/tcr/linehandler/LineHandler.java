package petrobras.ticeng.fic.tcr.linehandler;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract class LineHandler {

	protected List<String> lines = new ArrayList<>();
	
	public List<String> getLines() {
		return lines;
	}

	public abstract void handleLine(String line);
	
	public void writeResults(BufferedWriter out) {
		this.lines.stream()
				  .forEach(e -> {
							try {
								out.write(e);
								out.newLine();
							} catch (Exception e1) {
								e1.printStackTrace();
							}
				  });
		
		try {
			out.flush();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

}
