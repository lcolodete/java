package petrobras.engenharia.fic.atpf;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Params {

	private String[] paramArray;
	
	private List<String> paramList;
	
	private Iterator<String> i;
	
	private static Params instance;
	
	public static synchronized Params getInstance(String params) {
		if (instance == null) {
			instance = new Params(params);
		}
		return instance;
	}

	private Params(String params) {
		setParams(params);
	}
	
	public void setParams(String params) {
		if (params != null) {
			this.paramArray = params.split(",");
		} else {
			this.paramArray = new String[]{};
		}
		this.paramList = Arrays.asList(paramArray);
	}
	
	public String getNext() {
		if (i == null) {
			return null;
		}
		if (!i.hasNext()){
			return null;
		}
		return this.i.next();
	}
	
	public String getFirst() {
		this.i = paramList.iterator();
		String first = getNext();
		return first;
	}
}
