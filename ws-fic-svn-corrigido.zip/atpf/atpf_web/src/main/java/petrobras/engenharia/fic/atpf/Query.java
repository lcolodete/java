package petrobras.engenharia.fic.atpf;

public class Query {

	/**
	 * � a lista de parametros usada na execu��o da query
	 */
	private String id;
	
	private Long tempoInicio;
	private Long tempoFim;
	
	public Query(String id) {
		this.id = id;
	}
	
	public Long getTempoQuery(){
		return tempoFim - tempoInicio;
	}

	public void setTempoInicio(Long tempoInicio) {
		this.tempoInicio = tempoInicio;
	}

	public void setTempoFim(Long tempoFim) {
		this.tempoFim = tempoFim;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Query other = (Query) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return this.id;
	}
	
}
