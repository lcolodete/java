package petrobras.engenharia.fic.atpf.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.atpf.Config;
import petrobras.engenharia.fic.atpf.EstatisticasRodada;
import petrobras.engenharia.fic.atpf.EstatisticasRodadaHelper;
import petrobras.engenharia.fic.atpf.Params;
import petrobras.engenharia.fic.atpf.Query;
import petrobras.engenharia.fic.atpf.TesteInfo;

public class ExecuteQueryParamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger logger = LogManager.getLogger(ExecuteQueryParamServlet.class);

	private final Config config = Config.getInstance();
	
	/**
	 * DataSource utilizado para obter a conex�o com o banco
	 */
	private DataSource ds;

	private final String FORM_PARAM_USE_PREPARED_STATEMENT = "usePreparedStatement";
	private final String FORM_VALUE_USE_PREPARED_STATEMENT_CHECKED = "y";
	private final String FORM_PARAM_NUMERO_RODADAS = "numeroRodadas";

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		logger.debug(this.getClass().getSimpleName() + " iniciando...");
		
		lookupDataSource();
		
		Date currentDate = new Date();
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, new Locale("pt", "BR"));
		
		logger.info("***********************************************************");
		logger.info("**** " + this.getClass().getSimpleName() + " iniciado em " + df.format(currentDate) + " ****");
		logger.info("***********************************************************");
	}

	private void lookupDataSource() {
		try {
			Context ctx = new InitialContext();
			this.ds = (DataSource) ctx.lookup(config.getDataSourceName());
			logger.debug("DataSource=[" + config.getDataSourceName()+ "], objeto=[" + this.ds + "]");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter pw = response.getWriter();
		
		Date currentDate = new Date();
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, new Locale("pt", "BR"));
		
		pw.print("**************************************");
		pw.print("<br/>");
		pw.print(df.format(currentDate));
		pw.print("<br/>");
		pw.print(this.getClass().getName());
		pw.print("<br/>");
		pw.print("**************************************");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		long begin = 0;
		long end = 0;
		long tempoQuery = 0;
		
		logger.debug(request.getParameter(FORM_PARAM_NUMERO_RODADAS));
		logger.debug(request.getParameter(FORM_PARAM_USE_PREPARED_STATEMENT));
		logger.debug("request.getParameterMap()");
		logger.debug(request.getParameterMap());
//		logger.debug("request.getParameterNames()");
//		logger.debug(request.getParameterNames());
//		logger.debug(request.getParameterValues(FORM_PARAM_QUERY));
		
		String numeroRodadas = request.getParameter(FORM_PARAM_NUMERO_RODADAS);
		String usePreparedStatementStr = request.getParameter(FORM_PARAM_USE_PREPARED_STATEMENT);
		Boolean usePreparedStatement = (FORM_VALUE_USE_PREPARED_STATEMENT_CHECKED.equals(usePreparedStatementStr));
		
		Params params = config.getParams();
		String paramList;
		
		TesteInfo testeInfo;
		EstatisticasRodada estatsRodada;
		HttpSession session = request.getSession();
		
		//TODO Por enquanto esse � o teste para descobrir se pega os primeiros parametros
		if(null != numeroRodadas && !"".equals(numeroRodadas)) {
			testeInfo = new TesteInfo(usePreparedStatement, Integer.parseInt(numeroRodadas));
			
			estatsRodada = new EstatisticasRodada();
			estatsRodada.iniciaRodada();
			
			//armazena o objeto coletor de estatisticas na sessao
			session.setMaxInactiveInterval(1800);//30 min
			session.setAttribute("estatsRodada", estatsRodada);
			
			//TODO criar List<EstatisticasRodada> dentro de TesteInfo? 
			session.setAttribute("testeInfo", testeInfo);
			
			paramList = params.getFirst();
		} else {
			//pega as estatisticas da rodada da sessao
			estatsRodada = (EstatisticasRodada) session.getAttribute("estatsRodada");
			
			testeInfo = (TesteInfo) session.getAttribute("testeInfo");
			
			paramList = params.getNext();
		}

		if (paramList == null || "".equals(paramList)) {
			
			estatsRodada.finalizaRodada();
			
			StringBuilder relatorioBuilder = new StringBuilder();
			relatorioBuilder.append("<h3>Dados do Teste</h3>")
							.append("<div><b>Banco de dados:</b> ")
							.append(config.getDataSourceName())
							.append("</div>")
							.append("<div><b>N�mero de rodadas:</b> ")
							.append(testeInfo.getNumRodadas())
							.append("</div>")
							.append("<div><b>Use PreparedStatement:</b> ")
							.append(testeInfo.getUsePreparedStatement())
							.append("</div>")
							.append("<h3>Rodadas</h3>")
							.append(EstatisticasRodadaHelper.generateReport(estatsRodada));
			
			request.setAttribute("relatorioFinal", relatorioBuilder.toString());
			
			//TODO executar invalidate apenas apos a ultima rodada
			//session.invalidate();
			
			//TODO Quando chegar ao final da lista de parametros, deve verificar se come�a nova rodada
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/relatorioFinal.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		Query q = new Query(paramList);
		
		String sql = config.getQueryParam();
		
		StringBuilder builder = new StringBuilder();
		Boolean ocorreuExcecao = false;
		String msgExcecao = "";
		
		Connection con = null;
		PreparedStatement ps = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			
			String[] paramsArray = paramList.split(";");
			
			logger.info("param[0]="+paramsArray[0]);
			logger.info("param[1]="+paramsArray[1]);

			if (testeInfo.getUsePreparedStatement()) {
				sql = sql.replace("$PARAM0", "?");
				sql = sql.replace("$PARAM1", "?");
				
				ps = con.prepareStatement(sql);
				
				ps.setString(1, paramsArray[0]);
				ps.setString(2, paramsArray[0]);
				ps.setString(3, paramsArray[1]);
				
				begin = System.currentTimeMillis();
				q.setTempoInicio(begin);
				
				rs = ps.executeQuery();
				
				end = System.currentTimeMillis();
				q.setTempoFim(end);

			} else {
				sql = sql.replace("$PARAM0", "'"+paramsArray[0]+"'");
				sql = sql.replace("$PARAM1", "'"+paramsArray[1]+"'");
				
				st = con.createStatement();
				
				begin = System.currentTimeMillis();
				q.setTempoInicio(begin);
				
				rs = st.executeQuery(sql);
				
				end = System.currentTimeMillis();
				q.setTempoFim(end);
			}
			
			tempoQuery = q.getTempoQuery();
			
			logger.info("tempoQuery="+tempoQuery);

			if (!rs.next()) {
				logger.warn("query nao retornou registros");
			}
			
		} catch (SQLException e) {
			logger.error("Erro ao executar SQL", e);
			ocorreuExcecao = true;
			msgExcecao = e.getMessage();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					logger.error("Erro ao fechar PreparedStatement", e);
					ocorreuExcecao = true;
					msgExcecao = e.getMessage();
				}
			}
			if (st != null) {
				try {
					st.close();
				} catch (SQLException e) {
					logger.error("Erro ao fechar Statement", e);
					ocorreuExcecao = true;
					msgExcecao = e.getMessage();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					logger.error("Erro ao fechar Conexao", e);
					ocorreuExcecao = true;
					msgExcecao = e.getMessage();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					logger.error("Erro ao fechar ResultSet", e);
					ocorreuExcecao = true;
					msgExcecao = e.getMessage();
				}
			}
		}

		if (ocorreuExcecao) {
			
			estatsRodada.addQueryFalha(q);
			
			builder.append("Ocorreu um erro ao executar a query")
				   .append("<br/><br/>")
				   .append("Query: ")
				   .append("<br/>")
				   .append("> "+sql)
				   .append("<br/><br/>")
				   .append("Mensagem de erro:")
				   .append("<br/>")
				   .append(msgExcecao);
		} else {
			estatsRodada.addQuerySucesso(q);
			
			builder.append("Query: ")
				   .append("<br/>")
				   .append("> "+sql)
				   .append("<br/><br/>")
				   .append("Par�metros: (" + q + ")")
				   .append("<br/><br/>")
				   .append("Tempo de execu��o: "+ tempoQuery +" ms");
		}
		
		request.setAttribute("queryParamResponse", builder.toString());
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/queryParamResponse.jsp");
		dispatcher.forward(request, response);
	}
}
