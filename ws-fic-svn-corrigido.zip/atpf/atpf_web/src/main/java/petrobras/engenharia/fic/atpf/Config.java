package petrobras.engenharia.fic.atpf;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Config {

	private static Config instance;

	public static final String DATASOURCE_NAME = "datasource_name";
	public static final String CODIGO_EXTERNALIZACAO = "CODIGO_EXTERNALIZACAO";
	public static final String LOG4J_PATH = "log4jpath";
	public static final String QUERY_PARAM = "query_param";
	public static final String PARAMS = "params";

	private static final Logger logger = LogManager.getLogger(Config.class);
	
	private Properties props = new Properties();

	private Config() {
	}
	
	public static synchronized Config getInstance() {
		if (instance == null) {
			instance = new Config();
		}
		return instance;
	}
	
	public void loadProperties(String propertiesFile) throws IOException {
		this.props.load(this.getClass().getResourceAsStream(propertiesFile));
	}

    /**
     * Retorna o valor de uma propriedade do arquivo de configura��o
     * 
     * @param property nome da propriedade
     * @return String Valor da propriedade
     */
    public String getProperty(String property) {
        String retorno = null;
        
        try {
            retorno = this.props.getProperty(property);
            if (retorno == null) {
            	String msg = "propriedade [" + property + "] n�o configurada";
             	throw new IllegalArgumentException(msg);
            }
				
        }
        catch (MissingResourceException e) {
            logger.error(e, e);
        }
        
        return retorno; 
    }

	public Properties getProps() {
		return props;
	}

	public String getDataSourceName() {
		return getProperty(DATASOURCE_NAME);
	}
	
    public String getLog4JPath() {
    	return getProperty(LOG4J_PATH);
    }
	
    public String getCodigoExternalizacao() {
    	return getProperty(CODIGO_EXTERNALIZACAO);
    }
    
    public String getQueryParam() {
    	return getProperty(QUERY_PARAM);
    }
    
    public Params getParams() {
    	return Params.getInstance(getProperty(PARAMS));
    }

	public Map<String,String> getPropertyMap() {
		Map<String, String> propertyMap = new LinkedHashMap<String, String>();
		
		Set<Object> keys = new TreeSet<Object>(this.props.keySet());
		
		Iterator<Object> it = keys.iterator();
		while (it.hasNext()) {
			Object key = it.next();
			propertyMap.put((String)key, (String)this.props.get(key));
		}
		
		return propertyMap;
	}
	
	public static void main(String[] args) {
//		String sParams = "1200;SOP";
		String sParams = "SOP;1200";
		String[] params = sParams.split(";");
		System.out.println(String.format("select * from table where field_0='%2$s' and field_1 = '%1$s' and field_2 = '%1$s'", (Object[])params));
		
		String query = "query10o";
//		Pattern
		System.out.println(query.matches("query(\\d)+"));
	}
}
