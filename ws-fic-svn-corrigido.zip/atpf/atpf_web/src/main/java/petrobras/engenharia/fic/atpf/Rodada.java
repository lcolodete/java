package petrobras.engenharia.fic.atpf;

public class Rodada {
	
	private Integer id;
	private EstatisticasRodada estatsRodada;
	
	public Rodada(Integer id) {
		this.id = id;
		this.estatsRodada = new EstatisticasRodada(); 
	}
	
	public void iniciaRodada() {
		this.estatsRodada.iniciaRodada();
	}
	
	public void finalizaRodada() {
		this.estatsRodada.finalizaRodada();
	}

	public Integer getId() {
		return id;
	}

	public EstatisticasRodada getEstatsRodada() {
		return estatsRodada;
	}

	@Override
	public String toString() {
		return this.id.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rodada other = (Rodada) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
