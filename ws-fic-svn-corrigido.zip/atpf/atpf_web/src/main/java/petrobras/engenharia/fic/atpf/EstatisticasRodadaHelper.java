package petrobras.engenharia.fic.atpf;

import java.text.NumberFormat;

public class EstatisticasRodadaHelper {

	public static String generateReport(EstatisticasRodada estatsRodada) {
		
		StringBuilder builder = new StringBuilder();
		
		builder.append("Dura��o da Rodada: "+estatsRodada.getDuracao() +" ms")
		   	   .append("<br/>")
		   	   .append("Tempo Total executando queries: "+ estatsRodada.getTempoTotalQueries() +" ms")
		   	   .append("<br/>")
		   	   .append("N�mero de queries com sucesso: " + estatsRodada.getNumQueriesSucesso())
		   	   .append("<br/>")
		   	   .append("Tempo M�dio: "+ formatTempoDouble(estatsRodada.getTempoMedioQuery()) +" ms")
		   	   .append("<br/>")
		   	   .append("Tempo M�dio (descartando o tempo m�ximo): "+ formatTempoDouble(estatsRodada.getTempoMedioQuerySemTempoMaximo()) +" ms")
			   .append("<br/>")
			   .append("Tempo M�nimo: "+ estatsRodada.getTempoMinimoQuery() +" ms")
			   .append("<br/>")
			   .append("Query de Tempo M�nimo: "+ estatsRodada.getQueryTempoMinimo())
			   .append("<br/>")
			   .append("Tempo M�ximo: "+ estatsRodada.getTempoMaximoQuery() +" ms")
			   .append("<br/>")
			   .append("Query de Tempo M�ximo: "+ estatsRodada.getQueryTempoMaximo())
			   .append("<br/>")
		   	   .append("N�mero de queries com falha: " + estatsRodada.getNumQueriesFalha())
		   	   .append("<br/>")
		   	   .append("Queries com falha: " + estatsRodada.getQueriesFalha())
		   	   .append("<br/><br/>");
		
		return builder.toString();
	}
	
	private static String formatTempoDouble(Double d) {
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(2);
		return nf.format(d);
	}

	//TESTE
//	public static void main(String[] args) {
//		double d = 3.3333333333333335;
//		System.out.println(EstatisticasRodadaHelper.formatTempoDouble(d));
//	}
}
