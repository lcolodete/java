package petrobras.engenharia.fic.atpf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EstatisticasRodada {

//	duracao da rodada
//	numero de queries com sucesso
//	tempo medio de execucao
//	tempo minimo (e qual query resultou neste tempo)
//	tempo maximo (e qual query resultou neste tempo)
//	numero de queries com falha

	private Long tempoInicioRodada; 
	private Long tempoFimRodada; 
	
	private List<Query> queriesSucesso = new ArrayList<Query>();
	private Long tempoMinimoQuery = null;
	private Query queryTempoMinimo;
	private Long tempoMaximoQuery = null;
	private Query queryTempoMaximo;
	private List<Query> queriesFalha = new ArrayList<Query>();

	public void iniciaRodada() {
		tempoInicioRodada = System.currentTimeMillis();
	}
	
	public void finalizaRodada() {
		tempoFimRodada = System.currentTimeMillis();
	}
	
	public Long getTempoInicioRodada() {
		return tempoInicioRodada;
	}

	public Long getTempoFimRodada() {
		return tempoFimRodada;
	}

	public Long getDuracao() {
		return tempoFimRodada - tempoInicioRodada;
	}
	
	public Integer getNumQueriesFalha() {
		return queriesFalha.size();
	}
	
	public void addQueryFalha(Query query) {
		queriesFalha.add(query);
	}
	
	public List<Query> getQueriesFalha() {
		return queriesFalha;
	}
	
	public void addQuerySucesso(Query query) {
		queriesSucesso.add(query);
	}
	
	public Integer getNumQueriesSucesso() {
		return queriesSucesso.size();
	}

	public List<Query> getQueriesSucesso() {
		return queriesSucesso;
	}

	public Double getTempoMedioQuery() {
		
		if (queriesSucesso.isEmpty()) {
			return 0.0;
		}
		
		Double media = 0.0;
		Long somaTempos = 0L;
		for (Query q : queriesSucesso) {
			somaTempos += q.getTempoQuery();
		}
		media =  (Double.valueOf(somaTempos)) / getNumQueriesSucesso();
		return media;
	}
	
	public Double getTempoMedioQuerySemTempoMaximo() {

		if (queriesSucesso.isEmpty()) {
			return 0.0;
		}

		Double media = 0.0;
		Long somaTempos = 0L;
		Integer numQueries = getNumQueriesSucesso() - 1;
		
		Query qMax = getQueryTempoMaximo();
		
		for (Query q : queriesSucesso) {
			if (!q.equals(qMax)){
				somaTempos += q.getTempoQuery();
			}
		}

		media = (Double.valueOf(somaTempos)) / numQueries;
		return media;
	}
	
	public Long getTempoMinimoQuery() {
		if (queriesSucesso.isEmpty()) {
			return 0L;
		}

		Query qMin = Collections.min(queriesSucesso, new Comparator<Query>(){
			
			public int compare(Query q1, Query q2) {
				int result;
				if (q1.getTempoQuery() < q2.getTempoQuery()) {
					result = -1;
				} else if (q1.getTempoQuery().equals( q2.getTempoQuery() ) ) {
					result = 0;
				} else {
					result = 1;
				}
				return result;
			}
			
		});
		
		this.queryTempoMinimo = qMin; 
		this.tempoMinimoQuery = qMin.getTempoQuery(); 
		
		return tempoMinimoQuery; 
	}
	
	public Query getQueryTempoMinimo() {
		if (tempoMinimoQuery == null) {
			getTempoMinimoQuery();
		}
		return this.queryTempoMinimo; 
	}
	
	public Long getTempoMaximoQuery() {
		if (queriesSucesso.isEmpty()) {
			return 0L;
		}

		Query qMax = Collections.max(queriesSucesso, new Comparator<Query>(){

			public int compare(Query q1, Query q2) {
				int result;
				if (q1.getTempoQuery() < q2.getTempoQuery()) {
					result = -1;
				} else if (q1.getTempoQuery().equals( q2.getTempoQuery() ) ) {
					result = 0;
				} else {
					result = 1;
				}
				return result;
			}
			
		});
		
		this.queryTempoMaximo = qMax; 
		this.tempoMaximoQuery = qMax.getTempoQuery(); 
		
		return tempoMaximoQuery; 
	}

	public Query getQueryTempoMaximo() {
		if (tempoMaximoQuery == null) {
			getTempoMaximoQuery();
		}
		return this.queryTempoMaximo; 
	}
	
	public Long getTempoTotalQueries() {
		Long somaTempos = 0L;
		for (Query q : queriesSucesso) {
			somaTempos += q.getTempoQuery();
		}
		return somaTempos;
	}

}
