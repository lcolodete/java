package petrobras.engenharia.fic.atpf.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.engenharia.fic.atpf.Config;

public class ExecutePreparedStatementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger logger = LogManager.getLogger(ExecutePreparedStatementServlet.class);

	private final Config config = Config.getInstance();
	
	/**
	 * DataSource utilizado para obter a conex�o com o banco
	 */
	private DataSource ds;

	private final String FORM_PARAM_QUERY = "query";

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		logger.debug(this.getClass().getSimpleName() + " iniciando...");
		logger.debug("ServletConfig=["+config+"]");
		
		lookupDataSource();
		
		Date currentDate = new Date();
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, new Locale("pt", "BR"));
		
		logger.info("***********************************************************");
		logger.info("**** " + this.getClass().getSimpleName() + " iniciado em " + df.format(currentDate) + " ****");
		logger.info("***********************************************************");
	}

	private void lookupDataSource() {
		try {
			Context ctx = new InitialContext();
			this.ds = (DataSource) ctx.lookup(config.getDataSourceName());
			logger.debug("DataSource=[" + config.getDataSourceName()+ "], objeto=[" + this.ds + "]");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter pw = response.getWriter();
		
		Date currentDate = new Date();
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, new Locale("pt", "BR"));
		
		pw.print("**************************************");
		pw.print("<br/>");
		pw.print(df.format(currentDate));
		pw.print("<br/>");
		pw.print(this.getClass().getName());
		pw.print("<br/>");
		pw.print("**************************************");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		long begin = 0;
		long end = 0;
		
//		logger.debug(request.getParameter(FORM_PARAM_QUERY));
//		logger.debug(request.getParameterMap());
//		logger.debug(request.getParameterNames());
//		logger.debug(request.getParameterValues(FORM_PARAM_QUERY));
		
		String sql = config.getQueryParam();
		
		StringBuilder builder = new StringBuilder();
		
		Boolean ocorreuExcecao = false;
		String msgExcecao = "";
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = ds.getConnection();
			
			ps = con.prepareStatement(sql);
			
			ps.setString(1, "1210.23");
			ps.setString(2, "1210.23");
			ps.setString(3, "SSOP");
			
			begin = System.currentTimeMillis();
			
			rs = ps.executeQuery();
			
			end = System.currentTimeMillis();

			if (!rs.next()) {
				logger.warn("query nao retornou registros");
			}
			
		} catch (SQLException e) {
			logger.error("Erro ao executar SQL", e);
			ocorreuExcecao = true;
			msgExcecao = e.getMessage();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					logger.error("Erro ao fechar PreparedStatement", e);
					ocorreuExcecao = true;
					msgExcecao = e.getMessage();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					logger.error("Erro ao fechar Conexao", e);
					ocorreuExcecao = true;
					msgExcecao = e.getMessage();
				}
			}
		}

		if (ocorreuExcecao) {
			builder.append("Ocorreu um erro ao executar a query")
				   .append("<br/><br/>")
				   .append("Query: ")
				   .append("<br/>")
				   .append("> "+sql)
				   .append("<br/><br/>")
				   .append("Mensagem de erro:")
				   .append("<br/>")
				   .append(msgExcecao);
		} else {
			long queryTime = end - begin;
			
			builder.append("Query: ")
					.append("<br/>")
					.append("> "+sql)
					.append("<br/><br/>")
					.append("Tempo de execu��o: "+ queryTime +" ms");
		}
		
		request.setAttribute("queryUnicaResponse", builder.toString());
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/queryUnicaResponse.jsp");
		dispatcher.forward(request, response);
	}
}
