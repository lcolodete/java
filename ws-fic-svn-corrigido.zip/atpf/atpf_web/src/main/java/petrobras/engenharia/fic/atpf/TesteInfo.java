package petrobras.engenharia.fic.atpf;

import java.util.LinkedList;

public class TesteInfo {

	private Integer numRodadas;
	private Boolean usePreparedStatement;
	private LinkedList<Rodada> rodadas;
	
	public TesteInfo(Boolean usePreparedStatement, Integer numRodadas) {
		this.usePreparedStatement = usePreparedStatement;
		this.numRodadas = numRodadas;
		this.rodadas = new LinkedList<Rodada>();
	}

	public Boolean getUsePreparedStatement() {
		return usePreparedStatement;
	}

	public Integer getNumRodadas() {
		return numRodadas;
	}

	public Rodada iniciaNovaRodada() throws IllegalStateException {
		if (hasNextRodada()) {
			Rodada rodadaAtual = getRodadaAtual();
			Integer idNovaRodada;
			if (rodadaAtual == null) {
				idNovaRodada = 1;
			} else {
				idNovaRodada = rodadaAtual.getId() + 1;
			}
			Rodada novaRodada = new Rodada(idNovaRodada);
			novaRodada.iniciaRodada();
			this.rodadas.add(novaRodada);
			return novaRodada;
		} else {
			throw new IllegalStateException("Numero maximo de rodadas foi excedido");
		}
	}
	
	public void finalizaRodadaAtual() {
		getRodadaAtual().finalizaRodada(); 
	}
	
	public Rodada getRodadaAtual() {
		if (this.rodadas.isEmpty()) {
			return null;
		}
		return this.rodadas.getLast();
	}
	
	public Boolean hasNextRodada() {
		Boolean hasNext = false;
		if (this.rodadas.size() < this.numRodadas) {
			hasNext = true;
		}
		return hasNext;
	}
	
	public LinkedList<Rodada> getRodadas() {
		return this.rodadas;
	}
}
