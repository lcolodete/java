package petrobras.engenharia.fic.atpf.test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import petrobras.engenharia.fic.atpf.Params;

public class TestParams {

	String paramsApp = "1200;SOP,1210;SOP,1210.01;SSOP,1210.02;SSOP,1210.03;SSOP,1210.04;SSOP,1210.05;SSOP,1210.06;SSOP,1210.07;SSOP,1210.08;SSOP,1210.09;SSOP,1210.10;SSOP,1210.11;SSOP,1210.12;SSOP,1210.13;SSOP,1210.14;SSOP,1210.15;SSOP,1210.16;SSOP,1210.17;SSOP,1210.18;SSOP,1210.19;SSOP,1210.20;SSOP,1210.21;SSOP,1210.22;SSOP,1210.23;SSOP";
	Params paramsToTest;
	
	@Before
	public void setUp() throws Exception {
		paramsToTest = Params.getInstance(paramsApp);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void getNext_deveRetornarElementoAposPrimeiro() {
		paramsToTest.setParams("a,b");
		paramsToTest.getFirst();
		assertEquals("b", paramsToTest.getNext());
	}
	
	@Test
	public void getNext_devePercorrerAteOFimDaLista() {
		paramsToTest.setParams("a,b,c");
		paramsToTest.getFirst();
		assertEquals("b", paramsToTest.getNext());
		assertEquals("c", paramsToTest.getNext());
	}
	
	@Test
	public void getNext_deveRetornarNullAposUltimoElemento() {
		paramsToTest.setParams("a,b");
		paramsToTest.getFirst();
		assertEquals("b", paramsToTest.getNext());
		assertEquals(null, paramsToTest.getNext());
	}
	
	@Test
	public void getNext_deveRetornarNullSeGetFirstNaoForChamado() {
		paramsToTest.setParams("a,b");
		assertEquals(null, paramsToTest.getNext());
	}
	
	@Test
	public void getNext_deveRetornarNullSeGetFirstForChamadoEListaVazia() {
		paramsToTest.setParams("");
		paramsToTest.getFirst();
		assertEquals(null, paramsToTest.getNext());
	}

	@Test
	public void getFirst_deveRetornarPrimeiroElemento() {
		paramsToTest.setParams("a,b");
		
		assertEquals("a", paramsToTest.getFirst());
	}
	
	@Test
	public void getFirst_deveRetornarVazioSeListaVazia() {
		paramsToTest.setParams("");
		
		assertEquals("", paramsToTest.getFirst());
	}
	
	@Test
	public void getFirst_deveRetornarNullSeListaNull() {
		paramsToTest.setParams(null);
		
		assertEquals(null, paramsToTest.getFirst());
	}

}
