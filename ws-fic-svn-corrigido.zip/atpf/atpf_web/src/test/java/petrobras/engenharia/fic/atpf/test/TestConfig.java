package petrobras.engenharia.fic.atpf.test;

import static org.junit.Assert.assertEquals;

import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import petrobras.engenharia.fic.atpf.Config;

public class TestConfig {

	private Config config;
	
	@Before
	public void setUp() throws Exception {
		config = Config.getInstance();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetPropertyMap() {
		config.getProps().put("query3", "3");
		config.getProps().put("query1", "1");
		config.getProps().put("query2", "2");
		System.out.println(config.getProps());
		System.out.println(config.getPropertyMap());
		
		Set<Entry<String,String>> entries = config.getPropertyMap().entrySet();
		Integer i = 1;
		for (Entry<String,String> e : entries) {
			String key = e.getKey();
			
			System.out.println("key="+key);
			
			assertEquals("query"+i, key);
			i++;
		}
		
		Iterator<Entry<String,String>> it = entries.iterator();
		i = 1;
		while(it.hasNext()){
			Entry<String,String> entry = it.next();
			String entryStr = entry.toString(); 
			
			System.out.println("entry=["+entryStr+"]");
			
			assertEquals("query"+i+"="+i, entryStr);
			i++;
		}
	}

}
