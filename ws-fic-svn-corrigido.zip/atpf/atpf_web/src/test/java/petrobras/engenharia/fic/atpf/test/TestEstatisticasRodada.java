package petrobras.engenharia.fic.atpf.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import petrobras.engenharia.fic.atpf.EstatisticasRodada;
import petrobras.engenharia.fic.atpf.Query;

public class TestEstatisticasRodada {

	private EstatisticasRodada estatsRodada;
	
	@Before
	public void setUp() throws Exception {
		estatsRodada = new EstatisticasRodada();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void addQueryFalha() {
		assertTrue(estatsRodada.getQueriesFalha().isEmpty());
		
		estatsRodada.addQueryFalha(new Query("1"));
		
		assertFalse(estatsRodada.getQueriesFalha().isEmpty());
		assertEquals(1, estatsRodada.getNumQueriesFalha());
	}
	
	@Test
	public void addQuerySucesso() {
		assertTrue(estatsRodada.getQueriesSucesso().isEmpty());
		
		estatsRodada.addQuerySucesso(new Query("A"));
		estatsRodada.addQuerySucesso(new Query("B"));
		
		assertFalse(estatsRodada.getQueriesSucesso().isEmpty());
		assertEquals(2, estatsRodada.getNumQueriesSucesso());
	}
	
	@Test
	public void testGetTempoMedioQuery() {
		Query q1 = new Query("q1");
		Query q2 = new Query("q2");
		
		q1.setTempoInicio(10L);
		q1.setTempoFim(21L);//duracao = 11
		
		q2.setTempoInicio(0L);
		q2.setTempoFim(40L);//duracao = 40
		
		estatsRodada.addQuerySucesso(q1);
		estatsRodada.addQuerySucesso(q2);
		
		assertEquals(25.5, estatsRodada.getTempoMedioQuery(), 0);
	}

	@Test
	public void testGetTempoMedioQuerySemTempoMaximo() {
		Query q1 = new Query("q1");
		Query q2 = new Query("q2");
		Query q3 = new Query("q3");
		
		q1.setTempoInicio(10L);
		q1.setTempoFim(14L);//duracao = 4
		
		q2.setTempoInicio(5L);
		q2.setTempoFim(10L);//duracao = 5
		
		q3.setTempoInicio(30L);
		q3.setTempoFim(42L);//duracao = 12
		
		estatsRodada.addQuerySucesso(q1);
		estatsRodada.addQuerySucesso(q2);
		estatsRodada.addQuerySucesso(q3);
		
		assertEquals(4.5, estatsRodada.getTempoMedioQuerySemTempoMaximo(), 0);
	}

	@Test
	public void testGetTempoMinimoQuery() {
		Query q1 = new Query("q1");
		Query q2 = new Query("q2");
		Query q3 = new Query("q3");
		
		q1.setTempoInicio(10L);
		q1.setTempoFim(22L);//duracao = 12
		
		q2.setTempoInicio(5L);
		q2.setTempoFim(6L);//duracao = 1
		
		q3.setTempoInicio(30L);
		q3.setTempoFim(34L);//duracao = 4
		
		estatsRodada.addQuerySucesso(q1);
		estatsRodada.addQuerySucesso(q2);
		estatsRodada.addQuerySucesso(q3);
		
		assertEquals(1, estatsRodada.getTempoMinimoQuery());
		assertEquals(q2, estatsRodada.getQueryTempoMinimo());
	}

	@Test
	public void testGetTempoMaximoQuery() {
		Query q1 = new Query("q1");
		Query q2 = new Query("q2");
		Query q3 = new Query("q3");
		
		q1.setTempoInicio(10L);
		q1.setTempoFim(22L);//duracao = 12
		
		q2.setTempoInicio(5L);
		q2.setTempoFim(6L);//duracao = 1
		
		q3.setTempoInicio(30L);
		q3.setTempoFim(34L);//duracao = 4
		
		estatsRodada.addQuerySucesso(q1);
		estatsRodada.addQuerySucesso(q2);
		estatsRodada.addQuerySucesso(q3);
		
		assertEquals(12, estatsRodada.getTempoMaximoQuery());
		assertEquals(q1, estatsRodada.getQueryTempoMaximo());
	}

	@Test
	public void getQueryTempoMaximo() {
		Query q1 = new Query("q1");
		Query q2 = new Query("q2");
		Query q3 = new Query("q3");
		
		q1.setTempoInicio(10L);
		q1.setTempoFim(22L);//duracao = 12
		
		q2.setTempoInicio(5L);
		q2.setTempoFim(18L);//duracao = 13
		
		q3.setTempoInicio(30L);
		q3.setTempoFim(40L);//duracao = 10

		estatsRodada.addQuerySucesso(q1);
		estatsRodada.addQuerySucesso(q2);
		estatsRodada.addQuerySucesso(q3);

		assertEquals(q2, estatsRodada.getQueryTempoMaximo());
	}
	
	@Test
	public void getQueryTempoMinimo() {
		Query q1 = new Query("q1");
		Query q2 = new Query("q2");
		Query q3 = new Query("q3");
		
		q1.setTempoInicio(10L);
		q1.setTempoFim(22L);//duracao = 12
		
		q2.setTempoInicio(5L);
		q2.setTempoFim(18L);//duracao = 13
		
		q3.setTempoInicio(30L);
		q3.setTempoFim(40L);//duracao = 10

		estatsRodada.addQuerySucesso(q1);
		estatsRodada.addQuerySucesso(q2);
		estatsRodada.addQuerySucesso(q3);

		assertEquals(q3, estatsRodada.getQueryTempoMinimo());
	}
	
	@Test
	public void getTempoTotalQueries() {
		Query q1 = new Query("q1");
		Query q2 = new Query("q2");
		Query q3 = new Query("q3");
		
		q1.setTempoInicio(10L);
		q1.setTempoFim(22L);//duracao = 12
		
		q2.setTempoInicio(5L);
		q2.setTempoFim(18L);//duracao = 13
		
		q3.setTempoInicio(30L);
		q3.setTempoFim(40L);//duracao = 10

		estatsRodada.addQuerySucesso(q1);
		estatsRodada.addQuerySucesso(q2);
		estatsRodada.addQuerySucesso(q3);

		assertEquals(35L, estatsRodada.getTempoTotalQueries());
	}
}
