package petrobras.engenharia.fic.atpf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import petrobras.engenharia.fic.atpf.Rodada;
import petrobras.engenharia.fic.atpf.TesteInfo;

public class TestTesteInfo {

	private TesteInfo teste;
	
	@Before
	public void setUp() throws Exception {
		teste = new TesteInfo(true, 10);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIniciaRodada() {
		Rodada r1 = teste.iniciaNovaRodada();
		assertEquals(1, teste.getRodadaAtual().getId());
		assertEquals(1, r1.getId());
		assertEquals(r1, teste.getRodadaAtual());
		
		Rodada r2 = teste.iniciaNovaRodada();
		assertEquals(2, r2.getId());
		assertFalse(r2.equals(r1));
		assertTrue(r2.getId() > r1.getId());
	}

	@Test(expected=IllegalStateException.class)
	public void iniciaNovaRodada_deveLancarExcecaoSeCriarMaisRodadasDoQueONumeroMaximo() {
		teste = new TesteInfo(true, 2);
		teste.iniciaNovaRodada();
		teste.iniciaNovaRodada();
		teste.iniciaNovaRodada();
	}
	
	@Test
	public void testFinalizaRodada() {
		Rodada novaRodada = teste.iniciaNovaRodada();
		assertTrue(novaRodada.getEstatsRodada().getTempoInicioRodada() > 0);
		assertNull(novaRodada.getEstatsRodada().getTempoFimRodada());
		teste.finalizaRodadaAtual();
		assertNotNull(novaRodada.getEstatsRodada().getTempoFimRodada());
		assertTrue(novaRodada.getEstatsRodada().getTempoFimRodada() > 0);
	}

	@Test
	public void testGetRodadaAtual() {
		assertNull(teste.getRodadaAtual());
		teste.iniciaNovaRodada();
		assertNotNull(teste.getRodadaAtual());
		assertEquals(1, teste.getRodadaAtual().getId());
		teste.iniciaNovaRodada();
		teste.iniciaNovaRodada();
		assertEquals(3, teste.getRodadaAtual().getId());
	}

	@Test
	public void testHasNextRodada() {
		teste = new TesteInfo(true, 3);
		assertTrue(teste.hasNextRodada());
		teste.iniciaNovaRodada();
		assertTrue(teste.hasNextRodada());
		teste.iniciaNovaRodada();
		assertTrue(teste.hasNextRodada());
		teste.iniciaNovaRodada();
		assertFalse(teste.hasNextRodada());
	}

}
