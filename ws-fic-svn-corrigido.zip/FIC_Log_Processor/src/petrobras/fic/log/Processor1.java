package petrobras.fic.log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Este Processor busca a String "[WARN] BMXAA6720W" no arquivo de log de entrada e cria
 * um arquivo de saida com os resultados.
 * 
 * Da documentacao da IBM em http://pic.dhe.ibm.com/infocenter/tivihelp/v49r1/index.jsp?topic=%2Fcom.ibm.support.mbs.doc%2Fmessages%2FBMXAA6720W.html:
 * 
 * BMXAA6720W
 * 
 * USER = ({0}) SPID = ({1}) app ({2}) object ({3}) : {4} (execution took {5} milliseconds)
 * 
 * Explanation
 * 
 * The SQL exectued by the user for the application and corresponding mbo along with the execution time for the SQL 
 * 
 * @author UR5G
 *
 */
public class Processor1 {

	private static final Boolean _SYSOUT = false;  
	
	static final String LOG_FILE = "C:/Users/ur5g/FIC/Logs/2013-01-17_MxServer - CMp01MgdLieu/Cmp01MgdLieu.out";
	static final String SEARCH_STRING = "[WARN] BMXAA6720W";
	static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/Log_Processor/out/";
	static final String OUTPUT_FILENAME = "Processor1_out_";
//	static final String EXECUTION_TOOK = "(execution took";
	static final String EXECUTION_TOOK = "(a execu��o demorou";
	static final String SEPARATOR = "^";
	
	public static void main(String[] args) throws Exception {
		
		BufferedReader in = null;
		BufferedWriter out = null;
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(LOG_FILE), "UTF-8"));
			
//			Map<String, Charset> charsets = Charset.availableCharsets();
//			for (Map.Entry<String, Charset> e : charsets.entrySet()) {
//				System.out.println("charset.name="+e.getKey()+", charset.Charset="+e.getValue());
//			}
//			
//			System.out.println("default charset: "+Charset.defaultCharset());
//			
//			
			
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
			String date = df.format(new Date());
			
			out = new BufferedWriter(new FileWriter(OUTPUT_DIR + OUTPUT_FILENAME + date));
			
			int hits = 0;
			String line = null;
			StringBuilder sbLine = null;
			boolean lineContainsExecutionTook = false;
			boolean lineContainsSearchString = false;
			while ( (line = in.readLine()) != null ) {
				
				if (line.contains(SEARCH_STRING)) {
					lineContainsSearchString = true;
					hits++;
					
					sbLine = new StringBuilder(line);
					
					//insere separador em 2 lugares da linha:
					// 1. antes da String SEARCH_STRING
					// 2. antes da String EXECUTION_TOOK
					
					int separatorPos = line.indexOf(SEARCH_STRING) - 1;
					sbLine.replace(separatorPos, separatorPos+1, SEPARATOR);
					
					if (line.contains(EXECUTION_TOOK)) {
						lineContainsExecutionTook = true;
						separatorPos = line.indexOf(EXECUTION_TOOK) - 1;
						sbLine.replace(separatorPos, separatorPos+1, SEPARATOR);
					} else {
						lineContainsExecutionTook = false;
					}
					
					if (_SYSOUT) {
						System.out.println(sbLine);
					}
					
					out.write(sbLine.toString());
					out.newLine();
					
					if ((hits % 250) == 0) {
						System.out.println("out.flush() => hits="+hits);
						out.flush();
					}
				}
				
				if (lineContainsSearchString && !lineContainsExecutionTook) {
					//TODO Ler as proximas linhas ate encontrar uma linha com EXECUTION_TOOK
					
				}
				
			}
			System.out.println("**************************");
			System.out.println("Search \""+SEARCH_STRING+"\" ("+hits+" hits in file \""+ LOG_FILE +"\")");
			System.out.println("**************************");
		} finally {
			in.close();
			out.close();
		}
		
		
	}
	
}
