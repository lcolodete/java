var view = {
	displayMessage : function (msg) {
		var messageArea = document.getElementById("messageArea");
		if (messageArea) {
			messageArea.innerHTML = msg;
		}
	},
	displayHit : function(location) {
		var cell = document.getElementById(location);
		if (cell) {
			cell.setAttribute("class", "hit");
		}
	},
	displayMiss : function(location) {
		var cell = document.getElementById(location);
		if (cell) {
			cell.setAttribute("class", "miss");
		}
	}
};

/*
view.displayMiss("00");
view.displayHit("34");
view.displayMiss("55");
view.displayHit("12");
view.displayMiss("25");
view.displayHit("26");

view.displayMessage("Tap tap, is this thing on?");


var ships = [
	{ locations : ["06", "16", "26"], hits : ["hit", "", ""] },
	{ locations : ["24", "34", "44"], hits : ["", "", ""] },
	{ locations : ["10", "11", "12"], hits : ["", "", ""] }
];

for (var i in ships) {
	var ship = ships[i];
	var locations = ship.locations;
	for (var j in locations) {
		var loc = locations[j];
		var cell = document.getElementById(loc);
		if (cell) {
			cell.setAttribute("style", "background-color : grey");
		}
	}
}
*/

var model = {
	boardSize : 7,
	numShips : 4,
	shipLength : 3,
	shipsSunk : 0,
	ships : [],
	fire : function(guess) {
		for (var i = 0; i < this.numShips; i++) {
			var ship = this.ships[i];
			var locations = ship.locations;
			var hits = ship.hits;
			var index = locations.indexOf(guess);
			if (index >= 0) {
//			for (var j = 0; j < locations.length; j++) {
//				var loc = locations[j];
//				if (loc == guess) {
//					hits[j] = "hit";
					if (hits[index] === "hit") {
						view.displayMessage("Location already hit. Try again!");
						return false;
					}
					hits[index] = "hit";
					view.displayHit(guess);
					if (this.isSunk(ship)) {
						view.displayMessage("You sank my battleship!");
						this.shipsSunk++;
					} else {
						view.displayMessage("HIT!");
					}
					return true;
//				}
			}
		}
		view.displayMiss(guess);
		view.displayMessage("You missed.");
		return false;
	},
	isSunk : function(ship) {
		for (var i in ship.hits) {
			if (ship.hits[i] !== "hit")
				return false;
		}
		return true;
	},
	generateShipLocations : function() {
	
		for (var i = 0; i < this.numShips; i++) {
			var ship = {
				locations : [0, 0, 0], 
				hits : ["", "", ""]
			};
			this.ships.push(ship);
		}
		
		var locations;
		for (var i = 0; i < this.numShips; i++) {
			do {
				locations = this.generateShip();
			} while (this.collision(locations));
			this.ships[i].locations = locations;
		}
	},
	generateShip : function() {
		var direction = Math.floor(Math.random() * 2);
		var row;
		var col;
		if (direction === 1) {
			//horizontal
			row = Math.floor(Math.random() * this.boardSize);
			col = Math.floor(Math.random() * ((this.boardSize - this.shipLength) + 1));
		} else {
			//vertical
			row = Math.floor(Math.random() * ((this.boardSize - this.shipLength) + 1));
			col = Math.floor(Math.random() * this.boardSize);
		}
		
		var newShipLocations = [];
		for (var i = 0; i < this.shipLength; i++) {
			if (direction === 1) {
				newShipLocations.push(row + "" + (col + i));
			} else {
				newShipLocations.push((row + i) + "" + col);
			}
		}
		return newShipLocations;
	},
	collision : function(locations) {
		for (var i = 0; i < this.numShips; i++) {
			var ship = this.ships[i];
			for (var j = 0; j < locations.length; j++) {
				if (ship.locations.indexOf(locations[j]) >= 0) {
					return true;
				}
			}
		}
		return false;
	}
};

/*
model.fire("53");

model.fire("06");
model.fire("16");
model.fire("26");

model.fire("34");
model.fire("24");
model.fire("44");

model.fire("12");
model.fire("11");
model.fire("10");

console.log(model.generateShip());
console.log(model.generateShip());
console.log(model.generateShip());
*/

var controller = {
	guesses : 0,
	isGameOver : false,
	processGuess : function(guess) {
		if (this.isGameOver) {
			alert("Game Over! Reload the page to restart the game.");
		} else {
			var loc = parseGuess(guess);
			if (loc) {
				this.guesses++;
				if (model.fire(loc)) {
					//check to see if all ships were sunk
					if (model.shipsSunk == model.numShips) {
						//game over!
						view.displayMessage("You sank all my battleships in " + this.guesses + " guesses");
						this.isGameOver = true;
					}
				}
				
			}
		}
	}
};

function parseGuess(guess) {
	var ret = null;
	if (guess) {
		guess = guess.trim();
		
		if (guess.length == 2) {
			var first = guess.charAt(0).toUpperCase();
			var second = guess.charAt(1);
			
			var letters = ["A", "B", "C", "D", "E", "F", "G"];
			var index = letters.indexOf(first);
			if (index >= 0) {				
				if (!isNaN(second) && second >= 0 && second < model.boardSize) {
					ret = index + second;
				}
			}
		}
	}
	return ret;

}

/*
var testGuess = "c0";
console.log(testGuess+"="+parseGuess(testGuess));

console.log(parseGuess("A0"));
console.log(parseGuess("B6"));
console.log(parseGuess("G3"));
console.log(parseGuess("H0"));
console.log(parseGuess("A7"));
*/

/*
controller.processGuess("A0");

controller.processGuess("A6");
controller.processGuess("B6");
controller.processGuess("C6");

controller.processGuess("C4");
controller.processGuess("D4");
controller.processGuess("E4");

controller.processGuess("B0");
controller.processGuess("B1");
controller.processGuess("B2");

controller.processGuess("B3");
*/

function init() {
	var fireButton = document.getElementById("fireButton");
	fireButton.onclick = handleFireButton;
	
	var guessInput = document.getElementById("guessInput");
	guessInput.onkeypress = handleKeyPress;
	
	model.generateShipLocations();
	
	for (var i in model.ships) {
		console.log(model.ships[i].locations);
	}
}

window.onload = init;

function handleFireButton() {
	// get the player's guess from the form
	// and pass it to the controller
	var guessInput = document.getElementById("guessInput");
	if (guessInput) {
		var guess = guessInput.value;
		console.log("Guess="+guess);
		controller.processGuess(guess);
		guessInput.value = "";
	}
}

function handleKeyPress(e) {
	var fireButton = document.getElementById("fireButton");
	if (e.keyCode === 13) {
		fireButton.click();
		return false;
	}
}
