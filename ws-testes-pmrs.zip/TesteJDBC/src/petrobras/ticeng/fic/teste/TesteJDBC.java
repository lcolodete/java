package petrobras.ticeng.fic.teste;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.pool.OracleDataSource;

public class TesteJDBC {
	
	public static void main(String[] args) throws SQLException {
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			
			System.out.println(System.getProperty("java.util.logging.config.file"));
			
			OracleDataSource ds = new OracleDataSource();
			
			String url = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=zurg.petrobras.com.br)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=FICH.petrobras.com.br)))";
			
			ds.setURL(url);
			
			System.out.println("Connecting...");
			con = ds.getConnection("FIC", "Cnc7Qx_whj");
			
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM maxsession");
			
			while (rs.next()) {
				System.out.println(rs.getObject("userid").toString() + " - " + rs.getObject("issystem").toString() + " - " + rs.getObject("logindatetime").toString());
			}
			
		} finally {
			if (rs != null)
				rs.close();
			
			if (stmt != null)
				stmt.close();
			
			if (con != null)
				con.close();

		}
	}
	
}