package petrobras.ticeng.fic.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import petrobras.ticeng.fic.doclinks.filter.UserAgentInfo;

public class TestUserAgentInfo {

	private UserAgentInfo userAgentInfo;
	
	@Before
	public void setup() {
		userAgentInfo = new UserAgentInfo(null, "text/html, application/xhtml+xml, */*");
	}

	@After
	public void tearDown() {
	}
	
	@Test
	public void shouldDetectIE_IfUserAgentIE9() {

		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectIE_IfUserAgentIE9");
		
		userAgentInfo.setUserAgent("Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)");
		
		System.out.println(userAgentInfo);
		
		Assert.assertTrue("IE not detected", userAgentInfo.detectMSIE());
		Assert.assertTrue("IE 9 not detected", userAgentInfo.detectMSIE9());
		
		userAgentInfo.setUserAgent("Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; InfoPath.3)");
		
		System.out.println(userAgentInfo);
		
		Assert.assertTrue("IE not detected", userAgentInfo.detectMSIE());
		Assert.assertTrue("IE 7 not detected", userAgentInfo.detectMSIE7());
		
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectChrome());
		Assert.assertFalse(userAgentInfo.detectFirefox());
	}
	
	@Test
	public void shouldDetectIE_IfUserAgentIE10() {
		
		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectIE_IfUserAgentIE10");
		
		userAgentInfo.setUserAgent("Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)");
		
		System.out.println(userAgentInfo);
		
		Assert.assertTrue("IE not detected", userAgentInfo.detectMSIE());
		
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectChrome());
		Assert.assertFalse(userAgentInfo.detectFirefox());
	}
	
	@Test
	public void shouldDetectIE_IfUserAgentIE11() {
		
		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectIE_IfUserAgentIE11");
		
		userAgentInfo.setUserAgent("Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko");
		
		System.out.println(userAgentInfo);
		
		Assert.assertTrue("IE not detected", userAgentInfo.detectMSIE());
		
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectChrome());
		Assert.assertFalse(userAgentInfo.detectFirefox());
	}
	
	@Test
	public void shouldDetectChrome() {
		
		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectChrome");
		
		userAgentInfo.setUserAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36");
		
		System.out.println(userAgentInfo);
		
		Assert.assertTrue("Chrome not detected", userAgentInfo.detectChrome());
		
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectMSIE());
		Assert.assertFalse(userAgentInfo.detectFirefox());
	}
	
	@Test
	public void shouldDetectFirefox() {
		
		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectFirefox");
		
		userAgentInfo.setUserAgent("Mozilla/5.0 (Windows NT 6.1; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0");
		
		System.out.println(userAgentInfo);
		
		Assert.assertTrue("Firefox not detected", userAgentInfo.detectFirefox());
		
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectMSIE());
		Assert.assertFalse(userAgentInfo.detectChrome());
	}
	
	@Test
	public void shouldDetectUnknown_UnknownUserAgent() {
		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectUnknown_UnknownUserAgent");
		
		userAgentInfo.setUserAgent("xxx");
		
		System.out.println(userAgentInfo);
		
		Assert.assertFalse(userAgentInfo.detectMSIE());
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectChrome());
		Assert.assertFalse(userAgentInfo.detectFirefox());
	}
	
	@Test
	public void shouldDetectUnknown_EmptyUserAgent() {
		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectUnknown_EmptyUserAgent");
		
		userAgentInfo.setUserAgent("");
		
		System.out.println(userAgentInfo);
		
		Assert.assertFalse(userAgentInfo.detectMSIE());
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectChrome());
		Assert.assertFalse(userAgentInfo.detectFirefox());
	}
	
	@Test
	public void shouldDetectUnknown_NullUserAgent() {
		System.out.println("--------------------------------------------------------");
		System.out.println("shouldDetectUnknown_NullUserAgent");
		
		userAgentInfo.setUserAgent(null);
		
		System.out.println(userAgentInfo);
		
		Assert.assertFalse(userAgentInfo.detectMSIE());
		Assert.assertFalse(userAgentInfo.detectMSIE9());
		Assert.assertFalse(userAgentInfo.detectChrome());
		Assert.assertFalse(userAgentInfo.detectFirefox());
	}
}
