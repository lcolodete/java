package petrobras.ticeng.fic;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestRegex {

	public static void main(String[] args) {
		
		String responseBenvindo = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\">\r\n" + 
				"<html lang=\"pt\">\r\n" + 
				"<head>\r\n" + 
				"	<link rel=\"apple-touch-icon\" href=\"../images/maximo-icon.png\"/>\r\n" + 
				"	<link rel=\"shortcut icon\" href=\"../images/maximo-icon.ico\"/>\r\n" + 
				"	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n" + 
				"	<meta http-equiv=\"Expires\" content=\"0\" />\r\n" + 
				"	<meta name=\"viewport\" content=\"width=320, initial-scale=1.0\" />\r\n" + 
				"	<meta name=\"format-detection\" content=\"telephone=no\" />\r\n" + 
				"	<title>Bem-vindo a FIC - Ferramenta de Integra��o & Comissionamento; insira suas informa��es.</title>\r\n" + 
				"	<link href=\"css/login.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n" + 
				"	<link href=\"css/tivoli09/login.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n" + 
				"</head>\r\n" + 
				"\r\n" + 
				"<body onload=\"checkForRefresh()\">\r\n" + 
				"	<div role=\"main\">\r\n" ;

		
		System.out.println(responseBenvindo);
		
		System.out.println("===================================================================================================");
		
		String responseCadastrosBasicos = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n" + 
				"<html lang=\"pt\">\r\n" + 
				"	<head>\r\n" + 
				"		\r\n" + 
				"		<title>Cadastros B�sicos</title>\r\n" + 
				"		<link rel=\"stylesheet\" type=\"text/css\" href=\"../webclient/javascript/dojo-20150109-1054/dojo/resources/dojo.css\"/>\r\n" + 
				"		<link rel=\"stylesheet\" type=\"text/css\" href=\"../webclient/javascript/dojo-20150109-1054/dojox/html/resources/ellipsis.css\"/>\r\n" + 
				"		<link rel=\"stylesheet\" type=\"text/css\" href=\"../webclient/javascript/dojo-20150109-1054/dijit/themes/tundra/tundra.css\"/>\r\n" + 
				"		<link id=\"csslink\" rel=\"stylesheet\" type=\"text/css\" href=\"http://ficd-cipd.petrobras.com.br/maximo/webclient/skins/skins-20150630-1823/tivoli09/css/maximo.css\"/>\r\n" + 
				"		<link rel=\"shortcut icon\" href=\"../webclient/skins/skins-20150630-1823/tivoli09/images/maximo-icon.ico\"/>\r\n" + 
				"		<link rel=\"apple-touch-icon\" href=\"../webclient/skins/skins-20150630-1823/tivoli09/images/maximo-icon.png\"/> \r\n" + 
				"		<meta http-equiv=\"imagetoolbar\" content=\"no\"/>\r\n" + 
				"		<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>\r\n" + 
				"		<meta http-equiv=\"Content-Script-Type\" content=\"text/javascript\"/>\r\n" + 
				"		<meta name=\"viewport\" content=\"width=480, initial-scale=1.0\"/>\r\n" + 
				"		<meta name=\"format-detection\" content=\"telephone=no\"/>\r\n" ;
		
		System.out.println(responseCadastrosBasicos);
		
		
		Pattern p = Pattern.compile("<title>((Cadastros B�sicos)|(Basic Data)|(Registros B�sicos))</title>");
		Matcher m = p.matcher(responseCadastrosBasicos);
		
		String field = "";
		
		if (m.find()) {
			field = m.group();
		} else {
			throw new IllegalArgumentException("A regex nao encontrou nenhum resultado.");
		}

		System.out.println(field);
	}
}
