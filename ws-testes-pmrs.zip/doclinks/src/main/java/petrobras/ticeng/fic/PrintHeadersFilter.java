package petrobras.ticeng.fic;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class PrintHeadersFilter implements Filter {

	private ServletContext context;
	
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		RequestDispatcher dispatcher = this.context.getRequestDispatcher("/headers.jsp");
		dispatcher.forward(request, response);

	}

	@Override
	public void init(FilterConfig fc) throws ServletException {
		this.context = fc.getServletContext();
	}

}
