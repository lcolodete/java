package petrobras.ticeng.fic.doclinks.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class CheckRefererFilter implements Filter {
	
	private static final Logger logger = LogManager.getLogger(CheckRefererFilter.class);

	private ServletContext context;
	
	@Override
	public void destroy() {
	}

	/**
	 * O header "Referer" tem que existir e seu valor deve conter o mesmo serverName que o requestURL.
	 * FUNCIONA: Firefox, Chrome
	 * NAO FUNCIONA: IE9 e IE11
	 * Por esse motivo, somente executa a regra caso o browser n�o seja IE.
	 * Exemplo:
	 * Referer: http://fic.petrobras.com.br/maximo/ui/?event=loadapp&value=fic_fvi&uisessionid=474&csrftoken=b1n11qclqbqu6n7mlro7t3hbt9
	 * 
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		logger.info("CheckRefererFilter.doFilter >>> INICIO");
		
		HttpServletRequest httpRequest = (HttpServletRequest) request;

		//////////////////////// INICIO - testes
		
//		logger.info("getRequestURI()="+httpRequest.getRequestURI()); //getRequestURI()=/doclinks/testCookie.htm
		logger.info("getRequestURL()="+httpRequest.getRequestURL().toString()); //getRequestURL()=http://localhost:8088/doclinks/testCookie.htm
//		logger.info("getContextPath()="+httpRequest.getContextPath()); //getContextPath()=/doclinks
		
		String requestURL = httpRequest.getRequestURL().toString();
		int pos = requestURL.lastIndexOf("/") + 1;
		String resourceName = requestURL.substring(pos);
		
		logger.info("resourceName="+resourceName);
		
		//TODO remover
		if (resourceName.endsWith(".jsp")) {
//			RequestDispatcher dispatcher = this.context.getRequestDispatcher("/headers.jsp");
//			dispatcher.forward(request, response);
			RequestDispatcher dispatcher = this.context.getRequestDispatcher("/"+resourceName);
			dispatcher.forward(request, response);
			return;
		}
		
		//////////////////////// FIM - testes
		
		UserAgentInfo userAgentInfo = new UserAgentInfo(httpRequest);
		
		if (!userAgentInfo.detectMSIE()) {
			
			String serverName = httpRequest.getServerName();
			
			String referer = httpRequest.getHeader("Referer");
			boolean sameServer = false;
			
			// Caso o Referer tenha sido enviado pelo browser, faz a verifica��o
			if (referer != null && !referer.isEmpty()) {
				
				String semHttps = referer.split("http[s]?://")[1];
				String refererServerName = semHttps.split("/maximo/")[0];
				
				if (refererServerName.equals(serverName)) {
					sameServer = true;
				}
			}
			
			if (referer == null || referer.isEmpty() || !sameServer) {
				logger.error("CheckRefererFilter.doFilter >>> Request negado : Referer nulo ou desconhecido, URL="+requestURL);
				return;
			}
		}

		chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig fc) throws ServletException {
		this.context = fc.getServletContext();
	}

}
