package petrobras.ticeng.fic.doclinks.config;

import java.io.Serializable;
import java.util.MissingResourceException;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Configuracao implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = LogManager.getLogger(Configuracao.class);
	
	public static final String AMBIENTE = "AMBIENTE";
	public static final String VERSAO_APLICACAO = "VERSAO_APLICACAO";
	public static final String LOG4J_PATH = "log4jpath";
	public static final String SERVER_NAME = "serverName";
	
	private static Configuracao config;
	
	private Properties properties;
	
	private Configuracao() {
		this.properties = new Properties();
	}
	
	public static Configuracao getInstance() {
		if (config == null) {
			config = new Configuracao();
		}
		return config;
	}
	
	public void loadProperties(String propertiesFile) {
    	try {
            this.properties.load(Configuracao.getInstance().getClass().getResourceAsStream(propertiesFile));
        } catch (Exception e) {
           	logger.error(e, e);
        }
	}
	
    /**
     * Retorna o valor de uma propriedade do arquivo de configura��o
     * 
     * @param property nome da propriedade
     * @return String Valor da propriedade
     */
    private String getProperty(String property) {
        String retorno = null;
        
        try {
            retorno = this.properties.getProperty(property);
            if (retorno == null) {
            	String msg = "propriedade [" + property + "] n�o configurada";
             	throw new IllegalArgumentException(msg);
            }
				
        }
        catch (MissingResourceException e) {
            logger.error(e, e);
        }
        
        return retorno; 
    }
    
    public String getAmbiente() {
    	return getProperty(Configuracao.AMBIENTE);
    }
    
    public String getVersaoAplicacao() {
    	return getProperty(Configuracao.VERSAO_APLICACAO);
    }
    
    public String getLog4JPath() {
    	return getProperty(Configuracao.LOG4J_PATH);
    }
    
    public String getServerName() {
    	return getProperty(Configuracao.SERVER_NAME);
    }
    
}
