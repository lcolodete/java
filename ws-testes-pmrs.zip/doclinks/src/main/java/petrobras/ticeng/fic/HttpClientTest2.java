package petrobras.ticeng.fic;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.util.EntityUtils;

public class HttpClientTest2 {

    public final static void main(String[] args) throws Exception {
//        CloseableHttpClient httpclient = HttpClients.createDefault();
    	
    	
    	// Create a local instance of cookie store
    	CookieStore cookieStore = new BasicCookieStore();
    	// Populate cookies if needed
    	BasicClientCookie cookie = new BasicClientCookie("JSESSIONID", "hMSgVJJHLWPb1JLyCX5Rnzqfm32R8N1gWVK61XGFB1T1GSCZZBCC!-701745875");
    	cookie.setDomain("ficd-cipd.petrobras.com.br");
//    	cookie.setDomain("localhost");
    	cookie.setPath("/");
    	cookieStore.addCookie(cookie);
    	// Set the store
    	CloseableHttpClient httpclient = HttpClients.custom()
    	        .setDefaultCookieStore(cookieStore)
    	        .build();

    	
        try {
//            HttpGet httpget = new HttpGet("http://localhost:8088/doclinks/ANEXO.txt");
//            httpget.setHeader("Referer", "http://localhost/maximo/xxx");

        	HttpGet httpget = new HttpGet("http://ficd-cipd.petrobras.com.br/maximo/ui/?event=loadapp&value=fic_cadbas");
        	
            System.out.println("Executing request " + httpget.getRequestLine());

            // Create a custom response handler
            ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

                @Override
                public String handleResponse(
                        final HttpResponse response) throws ClientProtocolException, IOException {
                    int status = response.getStatusLine().getStatusCode();
                    if (status >= 200 && status < 300) {
                        HttpEntity entity = response.getEntity();
                        
                        BufferedReader in = null; 
                        StringBuilder sb = new StringBuilder();
                        try {
                        	in = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
                        	String line = "";
                        	int nLines = 0;
                        	while ( (line = in.readLine()) != null && nLines < 20 ) {
                        		nLines ++;
//                        		System.out.println(">>>>>> "+ line);
                        		sb.append(line);
                        	}
                        	
                        } finally {
                        	if (in != null)
                				in.close();
                        }
                        
//                        return entity != null ? EntityUtils.toString(entity) : null;
                        return entity != null ? sb.toString() : null;
                    } else {
                        throw new ClientProtocolException("Unexpected response status: " + status);
                    }
                }

            };
            String responseBody = httpclient.execute(httpget, responseHandler);
            System.out.println("----------------------------------------");
            System.out.println(responseBody);
        } finally {
            httpclient.close();
        }
    }

}