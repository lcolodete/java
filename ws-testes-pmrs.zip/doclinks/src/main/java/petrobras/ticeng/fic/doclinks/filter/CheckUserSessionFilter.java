package petrobras.ticeng.fic.doclinks.filter;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class CheckUserSessionFilter implements Filter {

	private static final Logger logger = LogManager.getLogger(CheckUserSessionFilter.class);
	
	private static final String _JSESSIONID = "JSESSIONID";
	
	private FilterConfig fc;
	private ServletContext sc;
	
	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		logger.info("CheckUserSessionFilter.doFilter >>> INICIO");
		
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		Cookie[] cookies = httpRequest.getCookies();

		boolean foundJSESSIONID = false;
		String jSessionId = null;
		
		if (cookies != null && cookies.length > 0) {
			
			for (Cookie c : cookies) {
				logger.info(c.getPath() + " - " + c.getName() + " - " + c.getValue());
				if (c.getName().equals(CheckUserSessionFilter._JSESSIONID)) {
					foundJSESSIONID = true;
					jSessionId = c.getValue();
				}
			}
		}
		
		String errorMsg;
		
		if (foundJSESSIONID) {
			
			//Verifica se o JSESSIONID recebido corresponde a um usuario logado na FIC
			// Se carregar a tela da aplicacao Cadastros B�sicos, ent�o est� logado!
			
			HttpClient httpClient = new HttpClient();
			
			boolean usuarioLogado = false;
			
			try {
				usuarioLogado = httpClient.isUsuarioLogado(jSessionId);
				
				if (usuarioLogado) {
					chain.doFilter(request, response);
					return;
				}
				
				errorMsg = "Usu�rio n�o est� logado";
			} catch (Exception e) {
				errorMsg = "Erro ao verificar se usu�rio est� logado: " + e.getMessage();
			}
			
		} else {
			errorMsg = "JSESSIONID n�o recebido";
		}
		
		logger.error("CheckUserSessionFilter.doFilter >>> Request negado : " + errorMsg + ", URL="+httpRequest.getRequestURL().toString());
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		this.fc = filterConfig;
		this.sc = this.fc.getServletContext();
	}

	public static void main(String[] args) {
		
		//Referer: http://fic.petrobras.com.br/maximo/ui/?event=loadapp&value=fic_fvi&uisessionid=474&csrftoken=b1n11qclqbqu6n7mlro7t3hbt9
		
		String referer = "http://fic.petrobras.com.br/maximo/ui/?event=loadapp&value=fic_fvi&uisessionid=474&csrftoken=b1n11qclqbqu6n7mlro7t3hbt9";
		System.out.println("Referer="+referer);
		
		String regex = "http[s]?://[\\w\\.\\-]+/maximo/.*";
		
		boolean b = referer.matches(regex);
		
		System.out.println(b);
		
		Pattern p = Pattern.compile("http[s]?://");
		Matcher m = p.matcher(referer);
		m.find();
		System.out.println(m.group());
		System.out.println(m.start());
		System.out.println(m.end());
		System.out.println(referer.split("http[s]?://")[1]);
		
		String semHttps = "fic.petrobras.com.br/maximo/ui/?event=loadapp&value=fic_fvi&uisessionid=474&csrftoken=b1n11qclqbqu6n7mlro7t3hbt9";
		System.out.println(semHttps.split("/maximo/")[0]);
		
	}
}
