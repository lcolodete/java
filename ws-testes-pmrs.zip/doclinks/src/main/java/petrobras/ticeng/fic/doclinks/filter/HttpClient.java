package petrobras.ticeng.fic.doclinks.filter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.ticeng.fic.doclinks.config.Configuracao;

public class HttpClient {
	
	private static final Logger logger = LogManager.getLogger(HttpClient.class);
	
	private Configuracao config = Configuracao.getInstance();
	
	public HttpClient() {
	}

    public boolean isUsuarioLogado(String jSessionId) throws Exception {
    	
    	// Create a local instance of cookie store
    	CookieStore cookieStore = new BasicCookieStore();
    	// Populate cookies
    	BasicClientCookie cookie = new BasicClientCookie("JSESSIONID", jSessionId);
    	
    	String serverName = config.getServerName();
    	
    	cookie.setDomain(serverName);
    	cookie.setPath("/");
    	cookieStore.addCookie(cookie);
    	// Set the store
    	CloseableHttpClient httpclient = HttpClients.custom()
    	        .setDefaultCookieStore(cookieStore)
    	        .build();

    	
        try {
        	StringBuilder sUrl = new StringBuilder();
        	sUrl.append("http://")
        		.append(serverName)
        		.append("/maximo/ui/?event=loadapp&value=fic_cadbas");
        	
        	HttpGet httpget = new HttpGet(sUrl.toString());
        	
        	logger.info("Executing request " + httpget.getRequestLine());

            // Create a custom response handler
            ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

                @Override
                public String handleResponse(final HttpResponse response) throws ClientProtocolException, IOException {
                    int status = response.getStatusLine().getStatusCode();
                    if (status == 200) {
                        HttpEntity entity = response.getEntity();
                        
                        BufferedReader in = null; 
                        StringBuilder sb = new StringBuilder();
                        try {
                        	in = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
                        	String line = "";
                        	int nLines = 0;
                        	
                        	// Le somente as 20 primeiras linhas do HTML recebido, � o suficiente 
                        	while ( (line = in.readLine()) != null && nLines < 20 ) {
                        		nLines ++;
                        		sb.append(line);
                        	}
                        	
                        } finally {
                        	if (in != null)
                				in.close();
                        }
                        
                        return entity != null ? sb.toString() : null;
                    } else {
                        throw new ClientProtocolException("Unexpected response status: " + status);
                    }
                }

            };
            String responseBody = httpclient.execute(httpget, responseHandler);
            logger.info("----------------------------------------");
            logger.info(responseBody);
            
            boolean usuarioLogado = false;
            
    		Pattern p = Pattern.compile("<title>((Cadastros B�sicos)|(Basic Data)|(Registros B�sicos))</title>");
    		Matcher m = p.matcher(responseBody);
    		
    		if (m.find()) {
    			usuarioLogado = true;
    		}
            
            return usuarioLogado;
            
        } finally {
            httpclient.close();
        }
    }

}