package petrobras.fic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PerformanceCheck {

	private final static String INPUT_FILE = "C:\\Users\\ur5g\\FIC\\Logs\\2018-02-08\\tenerife.petrobras.biz_MXServerBIRT_fic_maximo.log2018-02-07";
	
	public static void main(String[] args) {
		new PerformanceCheck().run();
		
//		double base = Math.random()*10000;
//		double exp = Math.random()*100;
//		
//
//		System.out.println(base);
//		System.out.println(exp);
//		System.out.println( Math.pow(base, exp) );
//		System.out.println(Math.random());
//		System.out.println(Math.random());
//		System.out.println(Math.random());
	}

	private String inputFile;
	
	private void run() {

		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		long begin = System.currentTimeMillis();
		System.out.println(">> INICIO : "+df.format(new Date()));
		
		BufferedWriter writer = null;
		BufferedReader reader = null;
		
		try {
			
			writer = new BufferedWriter( new FileWriter( "output_"+(new SimpleDateFormat("yyyy-MM-dd_HHmmss").format(new Date())) ) );
			
			reader = new BufferedReader(new FileReader(inputFile));
			
			String line = null;
			while ( (line = reader.readLine()) != null ) {
				
				if (line.length() > 72) {
					
					for (int i = 0; i < 1000; i++) {
						String s1 = line.substring(0, 24);
						String s2 = line.substring(24, 44);
						String s3 = line.substring(44, 60);
						String s4 = line.substring(62, 72);
						
						s2 += s1;
						s3 += s2;
						s4 += s3;
												
						String s5 = s1 + s2 + s3 + s4 + i;
					}
				}
				
				for (int i = 0; i < 1000; i++) {
					double base = Math.random()*10000;
					double exp = Math.random()*100;
					Math.pow(base, exp);
				}
				
				writer.write(line);
				writer.newLine();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null)
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			if (reader != null)
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		
		long end = System.currentTimeMillis();
		System.out.println(">> FIM : "+df.format(new Date()));
		System.out.println("Duracao (ms): " + (end - begin));
	}

	public PerformanceCheck() {
		this.inputFile = System.getProperty("input_file");
		System.out.println("input_file=["+this.inputFile+"]");
		if (this.inputFile == null)
			this.inputFile = INPUT_FILE;
		

	}

}
