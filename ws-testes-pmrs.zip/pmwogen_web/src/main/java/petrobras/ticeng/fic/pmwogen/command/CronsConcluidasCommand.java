package petrobras.ticeng.fic.pmwogen.command;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;
import petrobras.ticeng.fic.pmwogen.helper.CrontaskHelper;
import petrobras.ticeng.fic.pmwogen.log.crontask.LogPMWoGenProcessor;
import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;
import petrobras.ticeng.fic.pmwogen.log.jvm.CrontaskRunInfo;
import petrobras.ticeng.fic.pmwogen.log.jvm.LogJVMProcessor;

public class CronsConcluidasCommand {

	private static final Logger LOGGER = Logger.getLogger(CronsConcluidasCommand.class);
	
	private Date generationDate;
	
	private List<CrontaskRunInfo> cronsProgramadasConcluidas = new ArrayList<CrontaskRunInfo>();
	private List<CrontaskRunInfo> outrasCronsConcluidas = new ArrayList<CrontaskRunInfo>();

	private Set<CrontaskInstance> cronsProgramadas;
	
	public CronsConcluidasCommand() {
	}
	
	public void execute() throws IOException {
		List<CrontaskRunInfo> listCrontaskRunInfo = null;
		try {
			LogJVMProcessor logJVMProcessor = new LogJVMProcessor();
			listCrontaskRunInfo = logJVMProcessor.processaLogDoDia(generationDate);
		} catch (Exception e) {
			LOGGER.error("Erro em ResultServlet.doGet()", e);
		}
		
		CrontaskHelper helper = new CrontaskHelper(listCrontaskRunInfo, cronsProgramadas);
		helper.findCrons(cronsProgramadasConcluidas, outrasCronsConcluidas);
	}

	public List<CrontaskRunInfo> getCronsProgramadasConcluidas() {
		return cronsProgramadasConcluidas;
	}

	public List<CrontaskRunInfo> getOutrasCronsConcluidas() {
		return outrasCronsConcluidas;
	}

	public void setGenerationDate(Date generationDate) {
		this.generationDate = generationDate;
	}

	public void setCronsProgramadas(Set<CrontaskInstance> cronsProgramadas) {
		this.cronsProgramadas = cronsProgramadas;
	}
}
