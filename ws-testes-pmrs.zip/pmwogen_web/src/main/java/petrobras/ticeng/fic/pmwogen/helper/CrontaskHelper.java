package petrobras.ticeng.fic.pmwogen.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;
import petrobras.ticeng.fic.pmwogen.log.jvm.CrontaskRunInfo;

public class CrontaskHelper {

	private List<CrontaskRunInfo> listCrontaskRunInfo;
	private List<CrontaskInstance> listCrontaskInstance;
	
	public CrontaskHelper(List<CrontaskRunInfo> listCrontaskRunInfo, Set<CrontaskInstance> setCrontaskInstance) {
		this.listCrontaskRunInfo = listCrontaskRunInfo;
		this.listCrontaskInstance = new ArrayList<CrontaskInstance>(setCrontaskInstance);
		Collections.sort(this.listCrontaskInstance);
	}
	
	/**
	 * Dada a cronInstance, retorna as informações sobre a execução da mesma.
	 *  
	 * @param cronInstance
	 * @return objeto CrontaskRunInfo contendo as informações sobre a execução da instancia informada
	 */
	public CrontaskRunInfo findCrontaskRunInfo(CrontaskInstance cronInstance) {
		
		CrontaskRunInfo runInfoFound = null;
		
		for (CrontaskRunInfo runInfo : this.listCrontaskRunInfo) {
			if (runInfo.getInstanceName().equals(cronInstance.getInstanceName())) {
				runInfoFound = runInfo;
				break;
			}
		}
		
		return runInfoFound;
	}

	public void findCrons(List<CrontaskRunInfo> cronsDoDia, List<CrontaskRunInfo> outrasCrons) {

		CrontaskInstance key = new CrontaskInstance();
		
		for (CrontaskRunInfo crontaskRunInfo : this.listCrontaskRunInfo) {
			key.setInstanceName(crontaskRunInfo.getInstanceName());
			
			int index = Collections.binarySearch(this.listCrontaskInstance, key);
			
			if (index >= 0) {
				cronsDoDia.add(crontaskRunInfo);
			} else {
				outrasCrons.add(crontaskRunInfo);
			}
		}
		
	}
}
