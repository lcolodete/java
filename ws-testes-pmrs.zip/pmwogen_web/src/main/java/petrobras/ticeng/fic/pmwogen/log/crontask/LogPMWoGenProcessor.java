package petrobras.ticeng.fic.pmwogen.log.crontask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;

public class LogPMWoGenProcessor {
	
	private static final Logger LOGGER = Logger.getLogger(LogPMWoGenProcessor.class);

	public static class Regex {
		
		public static final String SEARCH_STRING_SITE = "site .{3,50} conclu.{1}da";
		
		private static final String SEARCH_STRING_GERAR_ORDEM_DE_SERVICO = "Gerar ordem de servi.{1}o a partir de MPs no "+SEARCH_STRING_SITE+" [\\d\\d]+/[\\d\\d]+/[\\d\\d]+ [\\d\\d]+:[\\d\\d]+ (A|P)M\\.";
		private static final String SEARCH_STRING_BMXAA3208I = ".*BMXAA3208I.*";
		private static final String SEARCH_STRING_Exception = ".*Exception.*";
		private static final String SEARCH_STRING_BMX_Error = ".*BMX[A-Z0-9]{6}E.*";
		private static final String SEARCH_STRING_BMX_Warning = ".*BMX[A-Z0-9]{6}W.*";
		private static final String SEARCH_STRING_BMXAA3212E = ".*BMXAA3212E.*";
	}
	
	public static void main(String[] args) {
		boolean matches = false;
		
		String line = "Gerar ordem de serviço a partir de MPs no site IEABAST-IERM-MODERNIZACAO-ADEQUACAO-001 concluída 5/25/15 10:13 AM.";
		
		if (line.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_GERAR_ORDEM_DE_SERVICO)) {
			matches = true;
		}
		
		System.out.println(matches);

		matches = false;
		
		String lineException = "InvocationTargetException accessing generateWorkOrderInformation : null : psdi.util.MXApplicationException: BMXAA5626E - Site IERENEST-IEHDT-JEY-001 não é válido porque está inativo.";
		
		String lineError = "BMXAA3212E - Erro ao gerar ordem para a Preservação 7926.";
		String lineWarning = "BMXAA8229W - O registro PM :  Site=COMPERJ-IEUT MP=108018 foi atualizado por outro usuário. Suas alterações não foram salvas. Atualize o registro e tente novamente.";
		
		if (lineWarning.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_BMX_Warning)) {
			matches = true;
		}
		System.out.println(matches);
		
		matches = false;
		
		String lineErroAoGerarOrdem = "BMXAA3212E - Erro ao gerar ordem para a Preservação 8414.";
		if (lineErroAoGerarOrdem.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_BMXAA3212E)) {
			matches = true;
		}
		System.out.println(matches);
	}
	
	public static void main2(String[] args) throws ParseException {
		LogPMWoGenProcessor processor = new LogPMWoGenProcessor();
		Date inicio = processor.parseDate("2/3/15");
		
		Date d = processor.parseDate("2/4/15");
		Date outro = processor.parseDate("2/4/15");
		
		Date fim = processor.parseDate("2/6/15");
		
		System.out.println(d.before(fim));
		System.out.println(d.before(inicio));
		
		System.out.println(d.after(fim));
		System.out.println(d.after(inicio));
		System.out.println(d.equals(fim));
		System.out.println(d.equals(inicio));
		
		System.out.println(d.equals(outro));
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
		
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		System.out.println( df.format(c.getTime()) );

	}

	/**
	 * Indica se o resultado do processamento sera gravado em arquivos.
	 */
	private boolean generateOutput = false;
	
	/**
	 * Diretorio no qual os arquivos de saida serao gerados.
	 */
	private String outputDir = null;
	
	private static final String DEFAULT_OUTPUT_DIR = "C:\\Users\\ur5g\\FIC\\Logs\\LogHunter\\pmwogen\\pmwogen_web\\"; 
	
	public LogPMWoGenProcessor() {
		this.setOutputDir(DEFAULT_OUTPUT_DIR);
	}
	
	public String getOutputDir() {
		return outputDir;
	}

	public void setOutputDir(String outputDir) {
		this.outputDir = outputDir;
	}

	public boolean isGenerateOutput() {
		return generateOutput;
	}

	public void setGenerateOutput(boolean generateOutput) {
		this.generateOutput = generateOutput;
	}

	/**
	 * Para cada cron presente em cronInstanceSet, computa as informações de geração de ordens de preservação para a data targetDate.
	 * 
	 * @param targetDate Se informada, indica a data que sera procurada no log. Apenas as informacoes dessa data serao retornadas.
	 * @param cronInstanceSet Crons que terao seus arquivos processados.
	 * @return lista de objetos PMWoGenInfo
	 * @see PMWoGenInfo
	 * 
	 * @throws Exception
	 */
	public List<PMWoGenInfo> processaLogDoDia(Date targetDate, Set<CrontaskInstance> cronInstanceSet) throws Exception {

		BufferedReader in = null;
		BufferedWriter out = null;
		
		List<PMWoGenInfo> resultList = new ArrayList<PMWoGenInfo>();
		
		if (targetDate != null) {
			
			Calendar c = Calendar.getInstance();
			c.setTime(targetDate);
			
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			c.set(Calendar.MILLISECOND, 0);
			targetDate = c.getTime();
		}
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
		String now = df.format(new Date());
			
		try {

			for (CrontaskInstance cronInstance : cronInstanceSet) {
				
				File file = cronInstance.getLogFile();
				String filename = file.getName();
				
				LOGGER.info(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
				
				try {
					in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
				} catch (FileNotFoundException e) {
					
					//Se nao encontrar o arquivo, escreve mensagem no log e vai para o proximo
					//Se ocorrer qualquer outro erro, deixa lancar a exception
					
					LOGGER.warn("Arquivo nao encontrado", e);
					continue;
				}
				
				int hitsGerarOrdem = 0;
				String currentDate = "";
				
				PMWoGenInfo pmwogenInfo = null;
				String line = null;
				
				while ( (line = in.readLine()) != null ) {
					
					//TODO Se targetDate != null, usar uma regex contendo a data. Caso contrario, usar a regex generica.
					if (line.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_GERAR_ORDEM_DE_SERVICO)) {
						
						GerarOrdemLine logLine = GerarOrdemLine.parse(line);
						String dateFromLine = logLine.getDate();
						Date dateObjFromLine = this.parseDate(dateFromLine);
						
						if (currentDate.isEmpty() || !currentDate.equals(dateFromLine)) {
							
							//encerra o dia
							if (!currentDate.isEmpty()) {
								if (targetDate != null)
									break;

								encerraDia(out, pmwogenInfo);
								resultList.add(pmwogenInfo);
								pmwogenInfo = null;
							}

							if (targetDate != null) {
								if (!dateObjFromLine.equals(targetDate)) {
									continue;
								}
							}
							
							//inicia novo dia
							currentDate = dateFromLine;
							
							pmwogenInfo = new PMWoGenInfo();
							pmwogenInfo.setSite(logLine.getSite());
							pmwogenInfo.setDate(dateObjFromLine);
							pmwogenInfo.setHoraInicio(logLine.getTime());
							pmwogenInfo.setHoraFim(pmwogenInfo.getHoraInicio());
//							pmwogenInfo.setErros(new ArrayList<String>());

							hitsGerarOrdem++;
							
							if (this.isGenerateOutput()) {
								if (hitsGerarOrdem == 1) {
									out = new BufferedWriter(new FileWriter(this.getOutputDir() + "output_" + filename.replaceFirst("\\.log", "") +"_" + now));
									
									out.write(logLine.getSite());
									out.newLine();
									out.newLine();
								}
								
								out.write(">>>>> " + formatDate(dateFromLine));
								out.newLine();
							}

						} else {
							pmwogenInfo.setHoraFim(logLine.getTime());
						}
						
						pmwogenInfo.setPreservacoes( pmwogenInfo.getPreservacoes() + 1 );
						
					} else if ( pmwogenInfo != null ) {
						
						if (line.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_BMXAA3208I)) {
							pmwogenInfo.setOrdens( pmwogenInfo.getOrdens() + 1 );
						}
//						else if (	line.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_BMX_Error) || 
//									line.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_BMX_Warning) || 
//									line.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_Exception) ) {
//							
//							if (line.matches(LogPMWoGenProcessor.Regex.SEARCH_STRING_BMXAA3212E)) {
//								pmwogenInfo.setPreservacoesComErro( pmwogenInfo.getPreservacoesComErro() + 1 );
//							}
//							pmwogenInfo.getErros().add(line);
//						}
					}
					
				} // Le a proxima linha
				
				// FIM DO PROCESSAMENTO DE UMA CRON INSTANCE
				
				if (hitsGerarOrdem > 0) {
					encerraDia(out, pmwogenInfo);
					resultList.add(pmwogenInfo);
					pmwogenInfo = null;
				}
				
				LOGGER.info("**************************");
				LOGGER.info("FIM DO ARQUIVO : "+ filename);
				LOGGER.info("**************************");
				LOGGER.info("");
				
				if (in != null)
					in.close();
				in = null;
				
				if (out != null)
					out.close();
				out = null;
				
			} // Le o proximo arquivo
			
			// FIM DE TODOS OS ARQUIVOS

			LOGGER.info("**************************");
			LOGGER.info("  FIM DO PROCESSAMENTO");
			LOGGER.info("**************************");
			LOGGER.info("");
			
			return resultList;

		} finally {
			if (in != null)
				in.close();
			if (out != null)
				out.close();
		}
	}
	
	public List<PMWoGenInfo> processaLogs(Set<CrontaskInstance> cronInstanceSet) throws Exception {
		return this.processaLogDoDia(null, cronInstanceSet);
	}

	private String formatDate(String date) throws ParseException {
		Date d = this.parseDate(date);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(d);
	}
	
	private Date parseDate(String date) throws ParseException {
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("en"));
		return df.parse(date);
	}

	private void encerraDia(BufferedWriter out, PMWoGenInfo pmwogenInfo) throws IOException {
		if (out != null) {
			out.newLine();
			out.write("PRESERVAÇÕES : " + pmwogenInfo.getPreservacoes());
			out.newLine();
			out.write("ORDENS GERADAS : " + pmwogenInfo.getOrdens());
			out.newLine();
			out.newLine();
			out.write("INICIO : " + pmwogenInfo.getHoraInicio());
			out.newLine();
			out.write("FIM : " + pmwogenInfo.getHoraFim());
			out.newLine();
			out.newLine();
			out.flush();
		}
	}

}
