package petrobras.ticeng.fic.pmwogen.command;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.config.Configuracao;
import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;

public class CronsProgramadasCommand {

	private static final Logger LOGGER = Logger.getLogger(CronsProgramadasCommand.class);
	
	private Set<CrontaskInstance> cronsProgramadas = new TreeSet<CrontaskInstance>();

	private Date generationDate;
	
	public CronsProgramadasCommand() {
	}
	
	public void execute() {
		Configuracao config = Configuracao.getInstance();
		
		Calendar c = Calendar.getInstance();
		c.setTime(generationDate);
		
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);

		String inputDir = config.getInputDir();
		String inputFile = dayOfWeek+".txt";
		
		try (BufferedReader inList = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(inputDir + inputFile), "UTF-8"))) {
			
			String line = null;
			while ( (line = inList.readLine()) != null ) {
				if (!line.isEmpty() && !line.startsWith("#")) {
					CrontaskInstance cronInstance = CrontaskInstance.parse(line);
					cronsProgramadas.add(cronInstance);
				}
			}
			
		} catch (Exception e) {
			LOGGER.error("Erro em ResultServlet.doGet()", e);
		}
	}

	public Set<CrontaskInstance> getCronsProgramadas() {
		return cronsProgramadas;
	}

	public void setGenerationDate(Date generationDate) {
		this.generationDate = generationDate;
	}

}
