package petrobras.ticeng.fic.pmwogen.log.crontask;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;

/**
 * Informações sobre a geracao de ordens de preservacao de um determinado site em uma determinada data.
 * 
 * @author ur5g
 *
 */
public class PMWoGenInfo {

	private static final Logger LOGGER = Logger.getLogger(PMWoGenInfo.class);
	
	private String site;
	private Date date;
	
	private Integer preservacoes = 0;
	private Integer ordens = 0;
	private String horaInicio = null;
	private String horaFim = null;
	
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Integer getPreservacoes() {
		return preservacoes;
	}
	public void setPreservacoes(Integer preservacoes) {
		this.preservacoes = preservacoes;
	}
	public Integer getOrdens() {
		return ordens;
	}
	public void setOrdens(Integer ordens) {
		this.ordens = ordens;
	}
	public String getHoraInicio() {
		return horaInicio;
	}
	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}
	public String getHoraFim() {
		return horaFim;
	}
	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append("[")
		  .append(this.getSite())
		  .append(",")
		  .append(this.getDate())
		  .append(",")
		  .append(this.getPreservacoes())
		  .append(",")
		  .append(this.getOrdens())
		  .append(",")
		  .append(this.getHoraInicio())
		  .append(",")
		  .append(this.getHoraFim())
		  .append("]");
		
		return sb.toString();
	}

	/**
	 * Retorna true se a geracao de ordens terminou após às 7h da manhã.
	 * 
	 * @return
	 */
	public boolean isTerminouApos7DaManha() {
		boolean bTerminouApos7DaManha = false;
		
		DateFormat dfS = DateFormat.getTimeInstance(DateFormat.SHORT, new Locale("en"));
		Date parsedDate = null;
		try {
			parsedDate = dfS.parse(this.getHoraFim());
		} catch (ParseException e) {
			LOGGER.warn("Ocorreu um erro no parsing da horaFim: "+this.getHoraFim(), e);
			return false;
		}
		
		Calendar c = Calendar.getInstance();
		c.setTime(parsedDate);
		int hour = c.get(Calendar.HOUR_OF_DAY);
		
		bTerminouApos7DaManha = hour >= 7 ? true : false;
		
		return bTerminouApos7DaManha;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((horaFim == null) ? 0 : horaFim.hashCode());
		result = prime * result + ((horaInicio == null) ? 0 : horaInicio.hashCode());
		result = prime * result + ((ordens == null) ? 0 : ordens.hashCode());
		result = prime * result + ((preservacoes == null) ? 0 : preservacoes.hashCode());
		result = prime * result + ((site == null) ? 0 : site.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PMWoGenInfo other = (PMWoGenInfo) obj;
		if (horaFim == null) {
			if (other.horaFim != null)
				return false;
		} else if (!horaFim.equals(other.horaFim))
			return false;
		if (horaInicio == null) {
			if (other.horaInicio != null)
				return false;
		} else if (!horaInicio.equals(other.horaInicio))
			return false;
		if (ordens == null) {
			if (other.ordens != null)
				return false;
		} else if (!ordens.equals(other.ordens))
			return false;
		if (preservacoes == null) {
			if (other.preservacoes != null)
				return false;
		} else if (!preservacoes.equals(other.preservacoes))
			return false;
		if (site == null) {
			if (other.site != null)
				return false;
		} else if (!site.equals(other.site))
			return false;
		return true;
	}
	
	
}
