package petrobras.ticeng.fic.pmwogen.log.crontask;

import java.text.ParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Representa uma linha de log.
 * 
 * Exemplo:
 * 
 * Gerar ordem de serviço a partir de MPs no site ENGEP-IEUEP-II-IECO-P74 concluída 2/3/15 2:15 AM.
 * 
 * A linha tem 3 componentes :
 * 
 * 1) Site. Ex: ENGEP-IEUEP-II-IECO-P74
 * 2) Data. Ex: 2/3/15
 * 3) Hora. Ex: 2:15 AM
 * 
 * @author ur5g
 *
 */
public class GerarOrdemLine {

	private String site;
	private String date;
	private String time;

	public String getSite() {
		return this.site;
	}

	public String getDate() {
		return this.date;
	}

	public String getTime() {
		return this.time;
	}

	public GerarOrdemLine(String site, String date, String time) {
		this.site = site;
		this.date = date;
		this.time = time;
	}

	public static GerarOrdemLine parse(String s) {
		
		String site = GerarOrdemLine.parseSite(s);
		String date = GerarOrdemLine.parseDate(s);
		String time = GerarOrdemLine.parseTime(s);
		
		GerarOrdemLine logLine = new GerarOrdemLine(site, date, time); 
		
		return logLine;
	}

	private static String parseSite(String s) {
		String site = GerarOrdemLine.find(LogPMWoGenProcessor.Regex.SEARCH_STRING_SITE, s);
		
		site = site.replaceFirst("site", "")
					.replaceFirst("conclu.{1}da", "")
					.trim();
		
		return site;
	}
	
	private static String parseDate(String s) {
		return GerarOrdemLine.find("[\\d\\d]+/[\\d\\d]+/[\\d\\d]+", s);
	}

	private static String parseTime(String s) {
		return GerarOrdemLine.find("[\\d\\d]+:[\\d\\d]+ (A|P)M", s);
	}
	
	private static String find(String regex, String s) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(s);
		
		String field = "";
		
		if (m.find()) {
			field = m.group();
		} else {
			throw new IllegalArgumentException("A regex "+regex+" nao encontrou nenhum resultado.");
		}
		
		return field;
	}

	
	public static void main(String[] args) throws ParseException {
		String lineToParse = "Gerar ordem de serviço a partir de MPs no site ENGEP-IEUEP-II-IECO-P74 concluída 2/3/15 2:15 AM.";
		GerarOrdemLine line = GerarOrdemLine.parse(lineToParse);
		
		System.out.println("line.site="+line.getSite());
		System.out.println("line.date="+line.getDate());
		System.out.println("line.time="+line.getTime());
	}
}
