package petrobras.ticeng.fic.pmwogen.helper;

import java.util.List;
import java.util.Set;

import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;
import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;
import petrobras.ticeng.fic.pmwogen.log.jvm.CrontaskRunInfo;

public class MessageBuilder {

	public MessageBuilder() {
		// TODO Auto-generated constructor stub
	}

	public String buildMensagemTopo(List<CrontaskRunInfo> cronsProgramadasConcluidas, 
									List<PMWoGenInfo> listCronsComGeracao, 
									Set<CrontaskInstance> cronsProgramadas) {
		
		StringBuilder sMensagens = new StringBuilder();
		
		int qtdCronsConcluidas = cronsProgramadasConcluidas != null ? cronsProgramadasConcluidas.size() : 0;
		
		int qtdCronsComGeracao = listCronsComGeracao != null ? listCronsComGeracao.size() : 0;
		
		int qtdCronsProgramadas = cronsProgramadas != null ? cronsProgramadas.size() : 0;
		
		if (qtdCronsConcluidas < qtdCronsComGeracao) {
			int qtdCronsEmExecucao = qtdCronsComGeracao - qtdCronsConcluidas;
			sMensagens.append(qtdCronsEmExecucao + " crons ainda estao em execucao.");
		}
		
		if (qtdCronsConcluidas < qtdCronsProgramadas) {
			int qtdCronsInvestigar = qtdCronsProgramadas - qtdCronsConcluidas;
			
			if (sMensagens.length() > 0) {
				sMensagens.append("<br/>");
			}
			
			sMensagens.append(qtdCronsInvestigar + " crons podem estar ainda em execucao ou ter falhado.");
		}
		
		return sMensagens.toString();
	}

}
