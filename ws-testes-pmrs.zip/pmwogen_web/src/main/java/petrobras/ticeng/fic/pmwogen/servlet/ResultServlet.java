package petrobras.ticeng.fic.pmwogen.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.command.CronsComGeracaoCommand;
import petrobras.ticeng.fic.pmwogen.command.CronsConcluidasCommand;
import petrobras.ticeng.fic.pmwogen.command.CronsProgramadasCommand;
import petrobras.ticeng.fic.pmwogen.config.Configuracao;
import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;
import petrobras.ticeng.fic.pmwogen.helper.MessageBuilder;
import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;
import petrobras.ticeng.fic.pmwogen.log.jvm.CrontaskRunInfo;

public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(ResultServlet.class);
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOGGER.info("ResultServlet.doGet");

		String dataRequest = request.getParameter("data");
		LOGGER.info("data=["+ dataRequest +"]");
		
		//Caso nao tenha data no request, utiliza a data de hoje
		Date generationDate = null;
		
		if ( dataRequest != null && !dataRequest.isEmpty() ) {
			try {
				generationDate = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR")).parse(dataRequest);
			} catch (ParseException e1) {
				String sErrorMsg = "Data com formato invalido: "+dataRequest;
				LOGGER.error(sErrorMsg, e1);
				
				//Exibe o erro na tela
				request.setAttribute("mensagemTopo", sErrorMsg);
				
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/date.jsp");
				dispatcher.forward(request, response);

				return;
			}
		} else {
			generationDate = new Date();
		}
		
		
		//Chama o objeto Command
		
		CronsProgramadasCommand cronsProgramadasCommand = new CronsProgramadasCommand();
		cronsProgramadasCommand.setGenerationDate(generationDate);
		cronsProgramadasCommand.execute();
		Set<CrontaskInstance> cronsProgramadas = cronsProgramadasCommand.getCronsProgramadas();
		
		CronsConcluidasCommand command = new CronsConcluidasCommand();
		command.setGenerationDate(generationDate);
		command.setCronsProgramadas(cronsProgramadas);
		command.execute();
		
		CronsComGeracaoCommand cronComGeracaoCommand = new CronsComGeracaoCommand();
		cronComGeracaoCommand.setGenerationDate(generationDate);
		cronComGeracaoCommand.setCronsProgramadas(cronsProgramadas);
		cronComGeracaoCommand.execute();
		
		// Setando os valores para o result.jsp

		//Quantidade de crons programadas para o dia em questao
		int qtdCronsProgramadas = 0;
		qtdCronsProgramadas = cronsProgramadas.size();
		request.setAttribute("cronsDoDia", qtdCronsProgramadas);
		
		//Quantidade de crons programadas com execucao concluida
		List<CrontaskRunInfo> cronsProgramadasConcluidas = command.getCronsProgramadasConcluidas();
		int qtdCronsConcluidas = cronsProgramadasConcluidas != null ? cronsProgramadasConcluidas.size() : 0;
		request.setAttribute("cronsDoDiaConcluidas", qtdCronsConcluidas);
		
		//Lista de crons do dia com execucao concluida
		request.setAttribute("listCronsDoDiaConcluidas", cronsProgramadasConcluidas);
		
		//Quantidade de crons com geracao de ordens na data informada
		List<PMWoGenInfo> listCronsComGeracao = cronComGeracaoCommand.getCronsComGeracaoNaData();
		int qtdCronsComGeracao = listCronsComGeracao != null ? listCronsComGeracao.size() : 0;
		request.setAttribute("cronsComGeracao", qtdCronsComGeracao);
		
		//Lista de crons com geracao de ordem na data informada
		request.setAttribute("list", listCronsComGeracao);
		
		request.setAttribute("generationDate", generationDate);
		request.setAttribute("currentDate", new Date());

		//Versão da aplicacao exibida no rodape da pagina
		request.setAttribute("versaoAplicacao", Configuracao.getInstance().getVersaoAplicacao());

		//Lista de outras crons concluidas
		request.setAttribute("listOutrasCronsConcluidas", command.getOutrasCronsConcluidas());
		
		//Lista de crons programadas (crons do dia)
		request.setAttribute("listCrontaskInstance", cronsProgramadas);

		request.setAttribute("mensagemTopo", "");
		MessageBuilder messageBuilder = new MessageBuilder();
		request.setAttribute("mensagemTopo", messageBuilder.buildMensagemTopo(cronsProgramadasConcluidas, 
																			  listCronsComGeracao, 
																			  cronsProgramadas));

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/result.jsp");
		dispatcher.forward(request, response);
	}

}
