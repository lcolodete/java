package petrobras.ticeng.fic.pmwogen.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;

public class TestServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    public TestServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("TestServlet.doGet");
		
		
//		List<String> fooList = new ArrayList<String>();
//		fooList.add("ola");
//		fooList.add("mundo");
//		fooList.add("!!!");
//		
//		request.setAttribute("list", fooList);
		
		List<PMWoGenInfo> pmwogenInfoList = new ArrayList<PMWoGenInfo>();
		
		PMWoGenInfo p1 = new PMWoGenInfo();
		p1.setSite("IERENEST-IEDACR-CMCO-002");
		p1.setHoraInicio("1:40 AM");
		p1.setHoraFim("5:49 AM");
		
		pmwogenInfoList.add(p1);
		
		PMWoGenInfo p2 = new PMWoGenInfo();
		p2.setSite("IERENEST-IEDACR-CMCO-002");
		p2.setHoraInicio("9:44 AM");
		p2.setHoraFim("12:02 PM");
		
		pmwogenInfoList.add(p2);

		PMWoGenInfo p3 = new PMWoGenInfo();
		p3.setSite("IERENEST-IEDACR-CMCO-002");
		p3.setHoraInicio("13:04 PM");
		p3.setHoraFim("13:33 PM");
		
		pmwogenInfoList.add(p3);
		
		PMWoGenInfo p4 = new PMWoGenInfo();
		p4.setSite("IERENEST-IEDACR-CMCO-001");
		p4.setHoraInicio("02:04 AM");
		p4.setHoraFim("03:39 AM");
		
		pmwogenInfoList.add(p4);

		request.setAttribute("list", pmwogenInfoList);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/for.jsp");
		dispatcher.forward(request, response);
	}
}