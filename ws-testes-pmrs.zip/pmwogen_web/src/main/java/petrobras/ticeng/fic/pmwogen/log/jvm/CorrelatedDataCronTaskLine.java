package petrobras.ticeng.fic.pmwogen.log.jvm;

import java.text.ParseException;

import petrobras.ticeng.fic.pmwogen.regex.RegexUtils;

/**
 * Representa uma linha do arquivo de log da JVM de escalation. 
 * <br/><br/>
 * Exemplo:
 * <br/><br/>
 * 03 Sep 2015 03:26:48:591 [INFO] [MXServerESC] [CID-CRON-1436] Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:IERENEST-IEDACR-CMDES-001 ElapsedTime:5207518 ms  END
 * <br/><br/>
 * A linha tem 4 componentes :
 * <br/>
 * 1) Hora. Ex: 03:26:48
 * 2) ServerName. Ex: MXServerESC<br/>
 * 3) CID-CRON. Ex: CID-CRON-1436<br/>
 * 4) InstanceName. Ex: ENGGE-IEEI-IEINFRA-CMEDISE-001<br/>
 * 5) ElapsedTime. Ex: 11476<br/>
 * 
 * @author ur5g
 *
 */
public class CorrelatedDataCronTaskLine {

	private String hora;
	private String serverName;
	private String cidCron;
	private String instanceName;
	private Integer elapsedTime;

	public String getHora() {
		return this.hora;
	}
	
	public String getServerName() {
		return this.serverName;
	}
	
	public String getCidCron() {
		return this.cidCron;
	}

	public String getInstanceName() {
		return this.instanceName;
	}

	public Integer getElapsedTime() {
		return this.elapsedTime;
	}

	public CorrelatedDataCronTaskLine(String hora, String serverName, String cidCron, String instanceName, Integer elapsedTime) {
		this.hora = hora;
		this.serverName = serverName;
		this.cidCron = cidCron;
		this.instanceName = instanceName;
		this.elapsedTime = elapsedTime;
	}

	public static CorrelatedDataCronTaskLine parse(String s) {
		
		String hora = CorrelatedDataCronTaskLine.parseHora(s);
		String serverName = CorrelatedDataCronTaskLine.parseServerName(s);
		String cidCron = CorrelatedDataCronTaskLine.parseCidCron(s);
		String instanceName = CorrelatedDataCronTaskLine.parseInstanceName(s);
		Integer elapsedTime = CorrelatedDataCronTaskLine.parseElapsedTime(s);
		
		CorrelatedDataCronTaskLine logLine = new CorrelatedDataCronTaskLine(hora, serverName, cidCron, instanceName, elapsedTime); 
		
		return logLine;
	}

	private static String parseHora(String s) {
		String hora = RegexUtils.find("\\d{2}:\\d{2}:\\d{2}", s);
		return hora;
	}
	
	private static String parseServerName(String s) {
		String serverName = RegexUtils.find("\\[MXServer\\w+\\]", s);
		
		serverName = serverName.replaceFirst("\\[", "")
				.replaceFirst("\\]", "")
				.trim();
		return serverName;
	}
	
	private static String parseCidCron(String s) {
		String cidCron = RegexUtils.find("\\[CID-CRON-\\d+\\]", s);
		
		cidCron = cidCron.replaceFirst("\\[CID-CRON-", "")
							   .replaceFirst("\\]", "")
							   .trim();
		return cidCron;
	}

	private static String parseInstanceName(String s) {
		String instanceName = RegexUtils.find("InstanceName:.{3,50} ElapsedTime", s);
		
		instanceName = instanceName.replaceFirst("InstanceName:", "")
								   .replaceFirst("ElapsedTime", "")
								   .trim();
		
		return instanceName;
	}
	
	private static Integer parseElapsedTime(String s) {
		String elapsedTimeStr = RegexUtils.find("ElapsedTime:\\d+ ms", s);

		elapsedTimeStr = elapsedTimeStr.replaceFirst("ElapsedTime:", "")
									   .replaceFirst("ms", "")
									   .trim();
		
		return Integer.valueOf(elapsedTimeStr);
	}
	
	public static void main(String[] args) throws ParseException {
//		String lineToParse = "Line 25026: 03 Sep 2015 02:37:43:125 [INFO] [MXServerESC] [CID-CRON-1456] Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:ENG-AB_IELOG_IEPDD_OCVAP_I/II ElapsedTime:1962216 ms  END";
		String lineToParse = "Line 34208: 03 Sep 2015 03:26:48:591 [INFO] [MXServerESC1] [CID-CRON-1436] Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:IERENEST-IEDACR-CMDES-001 ElapsedTime:5207518 ms  END";
		CorrelatedDataCronTaskLine line = CorrelatedDataCronTaskLine.parse(lineToParse);
		
		System.out.println("Hora="+line.getHora());
		System.out.println("ServerName="+line.getServerName());
		System.out.println("CID-CRON="+line.getCidCron());
		System.out.println("InstanceName="+line.getInstanceName());
		System.out.println("ElapsedTime="+line.getElapsedTime());
		
		boolean matches = false;
		
		if (lineToParse.matches(LogJVMProcessor.SEARCH_STRING_Correlated_data_PMWoGenCronTask)) {
			matches = true;
		}
		
		System.out.println(matches);
		

	}
	
}
