package petrobras.ticeng.fic.pmwogen.log.jvm;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.config.Configuracao;
import petrobras.ticeng.fic.pmwogen.regex.RegexUtils;

/**
 * Classe que sabe como ler e processar logs de JVMs.
 * 
 * @author ur5g
 *
 */
public class LogJVMProcessor {
	
	private static final Logger LOGGER = Logger.getLogger(LogJVMProcessor.class);

	public static final String SEARCH_STRING_Correlated_data_PMWoGenCronTask = ".*\\[MXServer\\w+\\] \\[CID-CRON-\\d+\\] Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:.{3,50} ElapsedTime:\\d+ ms  END";

	private static final String SEARCH_STRING_ERROR_WARN_CID_CRON = ".*\\[(ERROR|WARN)\\] \\[MXServer\\w+\\] \\[CID-CRON-(Y)\\].*";
	
	/**
	 * Nos arquivos de log das JVMs de escalation, faz uma busca pela linha que marca o fim da execucao das crons 
	 * de PMWoGen ({@link LogJVMProcessor#SEARCH_STRING_Correlated_data_PMWoGenCronTask}).<br/>
	 * Cada linha encontrada torna-se um objeto CrontaskRunInfo.
	 * 
	 * @param targetDate indica a data dos logs que serao processados. Somente os arquivos dessa data serao pesquisados (terminados por AAAA-MM-DD). 
	 * @return lista de objetos CrontaskRunInfo
	 * @throws Exception
	 */
	public List<CrontaskRunInfo> processaLogDoDia(Date targetDate) throws Exception {

		BufferedReader in = null;
		
		List<CrontaskRunInfo> resultList = new ArrayList<CrontaskRunInfo>();

		Calendar c = Calendar.getInstance();
		c.setTime(targetDate);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		targetDate = c.getTime();
		
		Date today = new Date();
		c.setTime(today);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		today = c.getTime();

		//Se targetDate for igual a hoje, nao precisa apendar nada
		String targetDateStr = "";
		if (!targetDate.equals(today)) {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			targetDateStr = df.format(targetDate);
		}

		try {

			Configuracao config = Configuracao.getInstance();
			String[] filenames = config.getLogsJvmsEscalation().split(",");
			
			DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR"));
			Date dataDesativacaoTropezon = df.parse("3/6/16");

			for (String filename : filenames) {

				if (targetDate.before(dataDesativacaoTropezon)) {
					if (filename.contains("MXServerBIRT1")) {
						filename = filename.replace("oviedo", "tropezon");
					} else if (filename.contains("MXServerBIRT")) {
						filename = filename.replace("tenerife", "tropezon");
					}
				}
				
				filename = filename + targetDateStr;
				
				LOGGER.info(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
				
				in = new BufferedReader(new InputStreamReader(new FileInputStream(config.getApplogsPath()+filename), "UTF-8"));
				
				List<CrontaskRunInfo> jvmList = new ArrayList<CrontaskRunInfo>();
				
				CrontaskRunInfo cronRunInfo = null;
				String line = null;
				StringBuilder cidCronBuilder = new StringBuilder();
				
				while ( (line = in.readLine()) != null ) {
					
					if (line.matches(LogJVMProcessor.SEARCH_STRING_Correlated_data_PMWoGenCronTask)) {
						
						CorrelatedDataCronTaskLine logLine = CorrelatedDataCronTaskLine.parse(line);
						
						String hora = logLine.getHora();
						String serverName = logLine.getServerName();
						String cidCron = logLine.getCidCron();
						String instanceName = logLine.getInstanceName();
						Integer duration = logLine.getElapsedTime();

						// Ignora a linha se ElapsedTime menor que 1000 ms
						// Faz isso para nao retornar em resultList linhas como abaixo:
						//08 Sep 2015 10:07:07:862 [INFO] [MXServerESC] [CID-CRON-18] Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:SA-1346-A ElapsedTime:28 ms  END
						//08 Sep 2015 10:07:07:907 [INFO] [MXServerESC] [CID-CRON-19] Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:SA-1346-A ElapsedTime:19 ms  END
						// Elas aparecem no log quando a JVM é reiniciada
						if (duration >= 1000) {
							
							//monta regex a partir dos CID-CRONS em jvmList
							if (cidCronBuilder.length() > 0) {
								cidCronBuilder.append("|");
							}
							cidCronBuilder.append(cidCron);

							cronRunInfo = new CrontaskRunInfo(hora, serverName, Integer.valueOf(cidCron), instanceName, duration);
							jvmList.add(cronRunInfo);
						}
					}
					
				} // Le a proxima linha

				if (in != null)
					in.close();
				in = null;

				final Comparator<CrontaskRunInfo> comparator = new Comparator<CrontaskRunInfo>() {
					@Override
					public int compare(CrontaskRunInfo o1, CrontaskRunInfo o2) {
						return o1.getCidCron().compareTo(o2.getCidCron());
					}
				};
				Collections.sort(jvmList, comparator);
				
				// Abre novamente para leitura, para procurar os erros e warnings das crons em jvmList
				in = new BufferedReader(new InputStreamReader(new FileInputStream(config.getApplogsPath()+filename), "UTF-8"));
				
				String regex_Error_Warning = LogJVMProcessor.SEARCH_STRING_ERROR_WARN_CID_CRON.replaceAll("Y", cidCronBuilder.toString());
				
				while ( (line = in.readLine()) != null ) {
					
					if (line.matches(regex_Error_Warning)) {
						//extrai da linha: error ou warning, CID-CRON
						Integer cidCronLine = Integer.valueOf(parseCidCron(line));
						String errorLine = parseError(line);
						String warningLine = parseWarning(line);
						
						// dado o CID-CRON, encontra o objeto CrontaskRunInfo na jvmList
						//Busca binaria
						CrontaskRunInfo cronInfoSearch = new CrontaskRunInfo();
						cronInfoSearch.setCidCron(cidCronLine);

						int indexFound = Collections.binarySearch(jvmList, cronInfoSearch, comparator);
						
						CrontaskRunInfo cronInfoFound = jvmList.get(indexFound);
						
						// se erro, adiciona na lista de erros
						// se warning, adiciona na lista de warnings
						if (!errorLine.isEmpty()) {
							List<String> errorList = cronInfoFound.getErrors();
							if (errorList == null) {
								errorList = new ArrayList<String>();
								cronInfoFound.setErrors(errorList);
							}
							
							errorList.add(line);
						} else if (!warningLine.isEmpty()) {
							List<String> warningList = cronInfoFound.getWarnings();
							if (warningList == null) {
								warningList = new ArrayList<String>();
								cronInfoFound.setWarnings(warningList);
							}
							
							warningList.add(warningLine);
						}
					}
					
				} // Le a proxima linha
				
				// FIM DE 1 ARQUIVO
				
				LOGGER.info("**************************");
				LOGGER.info("FIM DO ARQUIVO : "+filename);
				LOGGER.info("**************************");
				LOGGER.info("");
				
				if (in != null)
					in.close();
				in = null;
				
				resultList.addAll(jvmList);
			} // Le o proximo arquivo
			
			// FIM DE TODOS OS ARQUIVOS

			LOGGER.info("**************************");
			LOGGER.info("  FIM DO PROCESSAMENTO"    );
			LOGGER.info("**************************");
			LOGGER.info("");
			
			Collections.sort(resultList);
			
			return resultList;

		} finally {
			if (in != null)
				in.close();
		}
	}

	//teste
	public static void main(String[] args) {

		final String REGEX_ERROR_WARN = ".*\\[(ERROR|WARN)\\] \\[MXServer\\w+\\] \\[CID-CRON-(2565|9999|888|7)\\].*";
		
		String lineToParse_ERROR = "08 Jul 2016 01:00:05:214 [ERROR] [MXServerESC] [CID-CRON-9999] InvocationTargetException accessing generateWorkOrderInformation : null : psdi.util.MXApplicationException: BMXAA6199E - Plano de Trabalho ZSINS02768 não é válido, seu status não é ativo ou não é válido neste site.";
		
		String lineToParse_WARN = "08 Jul 2016 01:00:03:666 [WARN] [MXServerESC] [CID-CRON-2565] BMXAA6720W - USER = (PRV_IEEPT-IEPSA-P69N-001) SPID = (866) aplicativo (null) objeto (PM) : select * from pm  where ((siteid = 'IEEPT-IEPSA-P69N-001' and status = 'ATIVO' and (pmcounter = 0 or (fic_data_prox <= (sysdate +6) or fic_data_prox is null) or exists (select 1 from fic_preserv where siteid= pm.siteid and fic_prvnoreal = 1 and assetnum = pm.assetnum))) and (siteid ='IEEPT-IEPSA-P69N-001') and (parent is null)) and (exists ( select siteid from siteauth a,groupuser b  where a.groupname=b.groupname  and b.userid =  'PRV_IEEPT-IEPSA-P69N-001'  and a.siteid = pm.siteid))  (a execução demorou 1481 milissegundos)";
		
		boolean matches_ERROR = false;
		boolean matches_WARN = false;
		
		if (lineToParse_ERROR.matches(REGEX_ERROR_WARN)) {
			matches_ERROR = true;
		}
		
		if (lineToParse_WARN.matches(REGEX_ERROR_WARN)) {
			matches_WARN = true;
		}
		
		System.out.println("ERROR="+matches_ERROR);
		System.out.println("WARN="+matches_WARN);
		
		System.out.println(parseCidCron(lineToParse_ERROR));
		System.out.println(parseCidCron(lineToParse_WARN));
		
		System.out.println("ERROR=["+parseError(lineToParse_ERROR)+"]");
		System.out.println("ERROR=["+parseError(lineToParse_WARN)+"]");
		
		System.out.println("WARN=["+parseWarning(lineToParse_WARN)+"]");
		System.out.println("WARN=["+parseWarning(lineToParse_ERROR)+"]");
	}
	
	private static String parseCidCron(String s) {
		String cidCron = RegexUtils.find("\\[CID-CRON-\\d+\\]", s);
		
		cidCron = cidCron.replaceFirst("\\[CID-CRON-", "")
				.replaceFirst("\\]", "")
				.trim();
		return cidCron;
	}
	private static String parseError(String s) {
		String error = RegexUtils.find("\\[ERROR\\]", s);
		
		error = error.replaceFirst("\\[", "")
				.replaceFirst("\\]", "")
				.trim();
		return error;
	}
	private static String parseWarning(String s) {
		String warning = RegexUtils.find("\\[WARN\\]", s);
		
		warning = warning.replaceFirst("\\[", "")
							   .replaceFirst("\\]", "")
							   .trim();
		return warning;
	}


}
