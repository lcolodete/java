package petrobras.ticeng.fic.pmwogen.log.crontask;

import java.io.File;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;

/**
 * Processa logs de cron tasks de Geracao de Ordens de Preservação (PMWoGenCronTask).
 * Para cada cron task, produz um arquivo contendo:
 * 
 *  Nome da cron
 *  
 *  >>>> Data DD/MM/AA 
 *  Ordens geradas: NNN
 *  Inicio: DD/MM/AA
 *  Fim: DD/MM/AA
 *  
 *  Exemplo:
 *  
 *  IERENEST-IEDACR-CMCO-002
 *  
 *  >>>>>> 3/16/15
 *  ORDENS GERADAS: 816
 *  INICIO : 1:40 AM
 *  FIM: 3:55 AM
 *  
 *  >>>>>> 3/23/15 
 *  ORDENS GERADAS: 7324
 *  INICIO : 1:40 AM
 *  FIM: 9:46 AM
 *  
 *  >>>>>> 5/25/15 
 *  ORDENS GERADAS: 7015
 *  INICIO : 1:40 AM
 *  FIM: 10:13 AM
 *  
 * 
 * @author ur5g
 *
 */
public class RunLogProcessor {

//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/pmwogen/in_2015-08-31_SEG/download/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/pmwogen/in_2015-08-25_TER/download/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/pmwogen/in_2015-08-26_QUA/download/";
	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2016-12-14/cron/";
	
	private static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/pmwogen/out/";
	
	public static void main(String[] args) throws Exception {

		File dir = new File(INPUT_DIR);
		if (dir.isDirectory()) {
			
			String[] files = dir.list();
			
			Set<CrontaskInstance> cronInstanceSet = new HashSet<CrontaskInstance>();
			for (String fileName : files) {
				cronInstanceSet.add( new CrontaskInstance(null, INPUT_DIR+fileName) );
			}
			
			LogPMWoGenProcessor processor = new LogPMWoGenProcessor();
			processor.setGenerateOutput(true);
			processor.setOutputDir(OUTPUT_DIR);
			
			System.out.println("-- BEGIN : "+new Date());
			System.out.println("cronInstanceSet="+cronInstanceSet);
			long startTime = System.currentTimeMillis();
			
//			//HOJE
//			List<PMWoGenInfo> list = processor.processaLogDoDia(new Date(), cronInstanceSet);
			
			//DATA ESPECIFICA
			Date d = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR")).parse("5/12/16");
			List<PMWoGenInfo> list = processor.processaLogDoDia(d, cronInstanceSet);
			
//			//TODAS AS DATAS
//			List<PMWoGenInfo> list = processor.processaLogs(cronInstanceSet);
			
			long endTime = System.currentTimeMillis();
			
			System.out.println("-- END : "+new Date());

			System.out.printf("%s took %dms%n", "Old", (endTime - startTime));
//			System.out.println(list);
		}
	}
	
}
