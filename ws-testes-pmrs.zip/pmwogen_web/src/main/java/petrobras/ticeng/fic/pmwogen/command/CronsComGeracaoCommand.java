package petrobras.ticeng.fic.pmwogen.command;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;
import petrobras.ticeng.fic.pmwogen.log.crontask.LogPMWoGenProcessor;
import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;

public class CronsComGeracaoCommand {

	private static final Logger LOGGER = Logger.getLogger(CronsComGeracaoCommand.class);
	
	private List<PMWoGenInfo> listCronsComGeracao;
	
	private Date generationDate;
	
	private Set<CrontaskInstance> cronsProgramadas;
	
	public CronsComGeracaoCommand() {
	}
	
	public void execute() {
		try {
			LogPMWoGenProcessor processor = new LogPMWoGenProcessor();
			listCronsComGeracao = processor.processaLogDoDia(generationDate, cronsProgramadas);
			
			LOGGER.debug(listCronsComGeracao);
			
		} catch (Exception e) {
			LOGGER.error("Erro em ResultServlet.doGet()", e);
		}
	}

	public List<PMWoGenInfo> getCronsComGeracaoNaData() {
		return listCronsComGeracao;
	}

	public void setGenerationDate(Date generationDate) {
		this.generationDate = generationDate;
	}

	public void setCronsProgramadas(Set<CrontaskInstance> cronsProgramadas) {
		this.cronsProgramadas = cronsProgramadas;
	}

}
