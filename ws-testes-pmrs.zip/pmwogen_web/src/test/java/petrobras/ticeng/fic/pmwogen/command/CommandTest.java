package petrobras.ticeng.fic.pmwogen.command;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;


import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.BeforeClass;
import org.junit.Test;

import petrobras.ticeng.fic.pmwogen.config.Configuracao;
import petrobras.ticeng.fic.pmwogen.config.CrontaskInstance;
import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;
import petrobras.ticeng.fic.pmwogen.log.crontask.builder.PMWoGenInfoBuilder;

public class CommandTest {

	@Test
	public void getCronsComGeracaoNaData__13_03_2018__ReturnsCronsComGeracao() throws Exception {
		//Arrange
		
		Date generationDate = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR")).parse("13/03/2018");
		
		CronsProgramadasCommand cronsProgramadasCommand = new CronsProgramadasCommand();
		cronsProgramadasCommand.setGenerationDate(generationDate);
		cronsProgramadasCommand.execute();
		Set<CrontaskInstance> cronsProgramadas = cronsProgramadasCommand.getCronsProgramadas();
		
		CronsComGeracaoCommand command = new CronsComGeracaoCommand();
		command.setGenerationDate(generationDate);
		command.setCronsProgramadas(cronsProgramadas);

		//Act
		command.execute();
		
		//Assert
		List<PMWoGenInfo> cronsComGeracaoNaData = command.getCronsComGeracaoNaData();
		assertThat(cronsComGeracaoNaData, hasSize(2));
		
		PMWoGenInfo cron1 = new PMWoGenInfoBuilder().site("ENGEP-IEUEP-II-IECO-P74")
				.horaInicio("12:01 AM")
				.horaFim("2:53 AM")
				.preservacoes(5244)
				.ordens(3368)
				.build();
		
		PMWoGenInfo cron2 = new PMWoGenInfoBuilder().site("IEREFRJMG-REVAMP DAS URES")
													.horaInicio("3:30 AM")
													.horaFim("3:30 AM")
													.preservacoes(21)
													.ordens(5)
													.build();
		
		assertThat(cronsComGeracaoNaData.get(0), is(cron1));
		assertThat(cronsComGeracaoNaData.get(1), is(cron2));
	}

	@BeforeClass
	public static void envSetUp() {
		loadProperties();

		startLog4j();
		
		logger.info("************************************************************");
		logger.info("**** AMBIENTE: " + config.getAmbiente());
		logger.info("************************************************************");
	}
	
	private static final Logger logger = LogManager.getLogger(CommandTest.class);

	private static final Configuracao config = Configuracao.getInstance();

	private static void loadProperties() {
		
		config.loadProperties("/app.properties");
		
		// Le o ambiente utilizado como diretorio dos arquivos de configuracao da aplicacao no servidor 
		String ambiente = config.getAmbiente();
		
		// *********** ARQUIVOS DE CONFIGURACAO DO AMBIENTE *********** 
		
		// Le arquivo de configuracao CONFIG.PROPERTIES
		config.loadProperties(String.format("/%s/config.properties", ambiente));
	}
	
    private static void startLog4j() {

        String log4JPath = config.getLog4JPath();

        URL resource = CommandTest.class.getResource(log4JPath);

        if (resource != null) {
            PropertyConfigurator.configure(resource);
        } else {
            System.err.println("Log4j: NAO FOI POSSIVEL ENCONTRAR O ARQUIVO \""
                    + log4JPath + "\"");
            BasicConfigurator.configure();
        }
    }
}
