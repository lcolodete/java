package petrobras.ticeng.fic.pmwogen.log.crontask.builder;

import java.util.Date;

import petrobras.ticeng.fic.pmwogen.log.crontask.PMWoGenInfo;

public class PMWoGenInfoBuilder {

	private PMWoGenInfo pmWoGenInfo;
	
	public PMWoGenInfoBuilder() {
	}

	public PMWoGenInfoBuilder site(String site) {
		pmWoGenInfo = new PMWoGenInfo();
		pmWoGenInfo.setSite(site);
		return this;
	}
	public PMWoGenInfoBuilder horaInicio(String horaInicio) {
		pmWoGenInfo.setHoraInicio(horaInicio);
		return this;
	}
	public PMWoGenInfoBuilder horaFim(String horaFim) {
		pmWoGenInfo.setHoraFim(horaFim);
		return this;
	}
	public PMWoGenInfoBuilder preservacoes(Integer preservacoes) {
		pmWoGenInfo.setPreservacoes(preservacoes);
		return this;
	}
	public PMWoGenInfoBuilder ordens(Integer ordens) {
		pmWoGenInfo.setOrdens(ordens);
		return this;
	}

	public PMWoGenInfo build() {
		return pmWoGenInfo;
	}
}
