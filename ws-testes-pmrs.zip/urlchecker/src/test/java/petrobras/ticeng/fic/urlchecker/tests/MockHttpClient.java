package petrobras.ticeng.fic.urlchecker.tests;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.ticeng.fic.urlchecker.http.HttpClient;

public class MockHttpClient extends HttpClient {

	private static final Logger logger = LogManager.getLogger(MockHttpClient.class);
	
	public MockHttpClient() {
	}
	
	@Override
	public String doGet(String url) throws Exception {
		
		logger.info("MockHttpClient.doGet()");
		
		String response = doGet_NotRunning();
		
        logger.debug("----------------------------------------");
        logger.debug(response);

		return response;
	}

	private String doGet_NotRunning() {
		String responseNotRunning = "<html><head><title>IBM Cognos Content Manager</title></head><body><P><B><FONT face=Verdana size=5 color=#cc0000>IBM Cognos</FONT></B></P><P><B><FONT face=Verdana size=5>Content Manager</FONT></B></P><b><font face=\"Verdana\" size=\"2\">Build: </font></b><font face=\"Verdana\" size=\"2\">10.1.6306.4</font><br><b><font face=\"Verdana\" size=\"2\">Start time: </font></b><font face=\"Verdana\" size=\"2\">Tuesday, July 19, 2016 6:45:22 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">Current time: </font></b><font face=\"Verdana\" size=\"2\">Friday, July 22, 2016 12:26:05 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">State: </font></b><font face=\"Verdana\" size=\"2\">Not running. See logs.</font><br></body></html>";
		return responseNotRunning;
	}
	
	private String doGet_RunningSuspended() {
		String runningSuspended = "<html><head><title>IBM Cognos Content Manager</title></head><body><P><B><FONT face=Verdana size=5 color=#cc0000>IBM Cognos</FONT></B></P><P><B><FONT face=Verdana size=5>Content Manager</FONT></B></P><b><font face=\"Verdana\" size=\"2\">Build: </font></b><font face=\"Verdana\" size=\"2\">10.1.6306.4</font><br><b><font face=\"Verdana\" size=\"2\">Start time: </font></b><font face=\"Verdana\" size=\"2\">Tuesday, July 19, 2016 6:45:22 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">Current time: </font></b><font face=\"Verdana\" size=\"2\">Friday, July 22, 2016 12:26:05 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">State: </font></b><font face=\"Verdana\" size=\"2\">Running suspended</font><br></body></html>";
		return runningSuspended;
	}

}
