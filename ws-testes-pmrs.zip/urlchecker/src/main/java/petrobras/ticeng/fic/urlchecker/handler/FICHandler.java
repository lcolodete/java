package petrobras.ticeng.fic.urlchecker.handler;

import java.text.DateFormat;
import java.util.Date;

import petrobras.ticeng.fic.urlchecker.email.IMessage;
import petrobras.ticeng.fic.urlchecker.email.MockMessage;
import petrobras.ticeng.fic.urlchecker.main.Application;

public class FICHandler implements IUrlHandler {

	@Override
	public String handleSuccess(String response) {
		return null;
	}

	@Override
	public void handleError(String errorMsg) {
		IMessage msg = new MockMessage();
//		IMessage msg = new EmailMessage();

		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, Application.LOCALE_pt_BR);
		String addressee = "leandro.colodete@petrobras.com.br";
		String sender = "fic-noreply@petrobras.com.br";
		String subject = "Verificar FIC";
		String body = "URL: ["+getURL()+"]\nErro encontrado às "+df.format(new Date())+" : " + errorMsg;
		
		msg.buildMessage(sender, addressee, subject, body);
		
		msg.send();
	}

	@Override
	public String getURL() {
		return "https://fic.petrobras.com.br/maximo/webclient/login/login.jsp";
	}

}
