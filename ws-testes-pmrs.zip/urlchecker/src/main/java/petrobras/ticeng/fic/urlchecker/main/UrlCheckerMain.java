package petrobras.ticeng.fic.urlchecker.main;

import static org.apache.log4j.Level.ERROR;
import static org.apache.log4j.Level.INFO;
import static org.apache.log4j.Level.WARN;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

import petrobras.ticeng.fic.urlchecker.config.Configuracao;
import petrobras.ticeng.fic.urlchecker.handler.CognosHandler;
import petrobras.ticeng.fic.urlchecker.handler.FICHandler;
import petrobras.ticeng.fic.urlchecker.handler.IUrlHandler;
import petrobras.ticeng.fic.urlchecker.handler.exception.CognosInvalidStateException;
import petrobras.ticeng.fic.urlchecker.http.HttpClient;

public class UrlCheckerMain {

	public static void main(String[] args) {
		Application app = new Application();
		app.boot();

		// Verifica URL do Cognos (p2pd)
		CheckUrlTask checkCognos = new CheckUrlTask(new CognosHandler());
		Thread threadCognos = new Thread(checkCognos);
		threadCognos.setName("COGNOS");
		threadCognos.start();
		
		// Verifica URL da FIC (login.jsp)
		CheckUrlTask checkFIC = new CheckUrlTask(new FICHandler());
		Thread threadFIC = new Thread(checkFIC);
		threadFIC.setName("FIC");
		threadFIC.start();
	}
}

class CheckUrlTask implements Runnable {

//	private static final int MAX_ITERATIONS = 3;

	private final Logger logger = LogManager.getLogger(CheckUrlTask.class);
	
	private final Configuracao config = Configuracao.getInstance();
	
	private IUrlHandler urlHandler;
	
	private void log(Priority priority, String msg) {
		logger.log(priority, Thread.currentThread().getName()+" - "+msg);
	}
	
	private void logException(Exception e) {
		logger.error(Thread.currentThread().getName()+" - "+e.getMessage(), e);
	}

	public CheckUrlTask(IUrlHandler handler) {
		this.urlHandler = handler;
	}
	
	@Override
	public void run() {
//		int i = 0;
//		while (i<MAX_ITERATIONS) {
		while (true) {
			
			double responseTime = 0.0;
			String errorStr = null;
			String successStr = null;
			boolean errorDetected = true;
			long begin = 0L;
			long end = 0L;
			
			HttpClient httpClient = new HttpClient();
//			HttpClient httpClient = new MockHttpClient();
			try {
				begin = System.currentTimeMillis();
				String responseBody = httpClient.doGet(this.urlHandler.getURL());
				end = System.currentTimeMillis();
				responseTime = end - begin;

				successStr = this.urlHandler.handleSuccess(responseBody);
				
				errorDetected = false;
				
			} catch (ConnectTimeoutException timeoutException) {
				logException(timeoutException);
				errorStr = "Nao recebi resposta dentro do timeout definido: " + config.getTimeout(); 
			} catch (ClientProtocolException protocolException) {
				logException(protocolException);
				errorStr = protocolException.getMessage();
			} catch (CognosInvalidStateException invalidStateException) {
				logException(invalidStateException);
				errorStr = "Cognos com estado invalido: " + invalidStateException.getMessage();
			} catch (Exception e) {
				logException(e);
				errorStr = "Erro desconhecido: " + e.getMessage();
			}

			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
			
			if (errorDetected) {
				
				log(ERROR, errorStr);
				
				this.urlHandler.handleError(errorStr);
				
			} else {
				responseTime /= 1000;
				
				NumberFormat nf = NumberFormat.getNumberInstance(Application.LOCALE_pt_BR);
				nf.setMaximumFractionDigits(3);
				nf.setMinimumFractionDigits(3);
				
				String responseTimeStr = nf.format(responseTime);
				
				String beginStr = df.format(new Date(begin));
				String endStr = df.format(new Date(end));
				
				StringBuilder sb = new StringBuilder();
				sb.append(" Inicio=[")
				  .append(beginStr)
				  .append("] Fim=[")
				  .append(endStr)
				  .append("] ")
				  .append("Tempo de resposta=[")
				  .append(responseTimeStr)
				  .append("s]");
				
				log(INFO, "HTTP 200 OK "+sb.toString());
				
				if (responseTime > 5.0) {
					log(WARN, "Alto tempo de resposta : "+responseTimeStr+"s");
				}
				
				if (successStr != null && !successStr.isEmpty()) {
					log(INFO, successStr);
				}
			}
			
			
//			System.out.println("Estou na iteracao "+i);
//			i++;
			try {
				//TODO criar propriedade no app.properties
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} // fim while
	}
	
}
