package petrobras.ticeng.fic.urlchecker.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtils {

	public static String find(String regex, String s) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(s);
		
		String field = "";
		
		if (m.find()) {
			field = m.group();
		}
		
		return field;
	}

}
