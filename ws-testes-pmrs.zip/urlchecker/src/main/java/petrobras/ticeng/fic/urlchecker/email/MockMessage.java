package petrobras.ticeng.fic.urlchecker.email;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class MockMessage implements IMessage {

	private static final Logger logger = LogManager.getLogger(MockMessage.class);
	
	@Override
	public void send() {

		logger.info("mensagem enviada!");
	}

	@Override
	public void buildMessage(String sender, String addressee, String subject, String body) {
		StringBuilder sb = new StringBuilder();
		sb.append("\n")
		  .append("[FROM] = ")
		  .append(sender)
		  .append("\n")
		
		  .append("[TO] = ")
		  .append(addressee)
		  .append("\n")
		  
		  .append("[SUBJECT] = ")
		  .append(subject)
		  .append("\n")
		  
		  .append("[BODY] = ")
		  .append(body)
		;
		
		logger.info(sb.toString());
	}


}
