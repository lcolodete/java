package petrobras.ticeng.fic.urlchecker.main;

import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import petrobras.ticeng.fic.urlchecker.config.Configuracao;


public class Application {

	private static final Logger logger = LogManager.getLogger(Application.class);

	private final Configuracao config = Configuracao.getInstance();
	
	public static final Locale LOCALE_pt_BR = new Locale("pt", "BR");

	public void boot() {

		loadProperties();

		startLog4j();
		
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, Application.LOCALE_pt_BR);
		logger.info("*****************************************************************");
		logger.info("**** APLICACAO urlchecker INICIADA EM " + df.format(new Date()));
		logger.info("**** VERSAO: " + config.getVersaoAplicacao());
		logger.info("*****************************************************************");
	}

	private void loadProperties() {
		
		config.loadProperties("/app.properties");
		
		// Le o ambiente utilizado como diretorio dos arquivos de configuracao da aplicacao no servidor 
		String ambiente = config.getAmbiente();
		
		// *********** ARQUIVOS DE CONFIGURACAO DO AMBIENTE *********** 
		
		// Le arquivo de configuracao CONFIG.PROPERTIES
		config.loadProperties(String.format("/%s/config.properties", ambiente));
	}
	
    private void startLog4j() {

        String log4JPath = config.getLog4JPath();

        URL resource = this.getClass().getResource(log4JPath);

        if (resource != null) {
            PropertyConfigurator.configure(resource);
        } else {
            System.err.println("Log4j: NAO FOI POSSIVEL ENCONTRAR O ARQUIVO \""
                    + log4JPath + "\"");
            BasicConfigurator.configure();
        }
    }

	
}
