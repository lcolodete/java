package petrobras.ticeng.fic.urlchecker.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class HttpClientTest {

    public final static void main(String[] args) throws Exception {
//        CloseableHttpClient httpclient = HttpClients.createDefault();
    	
    	SocketConfig config = SocketConfig.custom()
    			.setSoTimeout(5)
    			.build();
    	
    	CloseableHttpClient httpclient = HttpClients.custom()
    			.setDefaultSocketConfig(config)
    	        .build();

    	
        try {
        	HttpGet httpget = new HttpGet("https://fic.petrobras.com.br/p2pd/servlet");
        	
            System.out.println("Executing request " + httpget.getRequestLine());

            // Create a custom response handler
            ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

                @Override
                public String handleResponse(
                        final HttpResponse response) throws ClientProtocolException, IOException {
                    int status = response.getStatusLine().getStatusCode();
                    if (status >= 200 && status < 300) {
                        HttpEntity entity = response.getEntity();
                        
                        BufferedReader in = null; 
                        StringBuilder sb = new StringBuilder();
                        try {
                        	in = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
                        	String line = "";
                        	int nLines = 0;
                        	while ( (line = in.readLine()) != null && nLines < 20 ) {
                        		nLines ++;
                        		System.out.println(">>>>>> "+ line);
                        		sb.append(line);
                        	}
                        	
                        } finally {
                        	if (in != null)
                				in.close();
                        }
                        
//                        return entity != null ? EntityUtils.toString(entity) : null;
                        return entity != null ? sb.toString() : null;
                    } else {
                        throw new ClientProtocolException("Unexpected response status: " + status);
                    }
                }

            };
            String responseBody = httpclient.execute(httpget, responseHandler);
            System.out.println("----------------------------------------");
            System.out.println(responseBody);
        } finally {
            httpclient.close();
        }
    }

}