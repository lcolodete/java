package petrobras.ticeng.fic.urlchecker.handler;

import java.text.DateFormat;
import java.util.Date;

import petrobras.ticeng.fic.urlchecker.email.IMessage;
import petrobras.ticeng.fic.urlchecker.email.MockMessage;
import petrobras.ticeng.fic.urlchecker.handler.exception.CognosInvalidStateException;
import petrobras.ticeng.fic.urlchecker.main.Application;
import petrobras.ticeng.fic.urlchecker.util.RegexUtils;

public class CognosHandler implements IUrlHandler {

	private static final String REGEX_STATE_RUNNING = "<font face=\"Verdana\" size=\"2\">Running</font>";
	
	@Override
	public String handleSuccess(String response) throws CognosInvalidStateException {
		
		StringBuilder successStr = new StringBuilder();
		
		if (this.getURL().contains("p2pd")) {
			String state = parseState(response);
			String currentTime = parseCurrentTime(response);
			String running = RegexUtils.find(REGEX_STATE_RUNNING, response);
			
			if (running == null || running.isEmpty()) {
				throw new CognosInvalidStateException(state);
			} else {
				successStr.append("Current time: ")
						   .append(currentTime)
						   .append(" / ")
						   .append("State: ")
						   .append(state);
			}
		}

		return successStr.toString();
	}

	@Override
	public void handleError(String errorStr) {
		IMessage msg = new MockMessage();
//		IMessage msg = new EmailMessage();

		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, Application.LOCALE_pt_BR);
		String addressee = "leandro.colodete@petrobras.com.br";
		String sender = "fic-noreply@petrobras.com.br";
		String subject = "Verificar Cognos";
		String body = "URL: ["+getURL()+"]\nErro encontrado às "+df.format(new Date())+" : " + errorStr;
		
		msg.buildMessage(sender, addressee, subject, body);
		
		msg.send();
	}

	@Override
	public String getURL() {
		return "https://fic.petrobras.com.br/p2pd/servlet";
	}

	public static void main(String[] args) {
//		String resposta = "<html><head><title>IBM Cognos Content Manager</title></head><body><P><B><FONT face=Verdana size=5 color=#cc0000>IBM Cognos</FONT></B></P><P><B><FONT face=Verdana size=5>Content Manager</FONT></B></P><b><font face=\"Verdana\" size=\"2\">Build: </font></b><font face=\"Verdana\" size=\"2\">10.1.6306.4</font><br><b><font face=\"Verdana\" size=\"2\">Start time: </font></b><font face=\"Verdana\" size=\"2\">Tuesday, July 19, 2016 6:45:22 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">Current time: </font></b><font face=\"Verdana\" size=\"2\">Thursday, July 21, 2016 6:02:40 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">State: </font></b><font face=\"Verdana\" size=\"2\">Running</font><br></body></html>";
		String resposta = "<html><head><title>IBM Cognos Content Manager</title></head><body><P><B><FONT face=Verdana size=5 color=#cc0000>IBM Cognos</FONT></B></P><P><B><FONT face=Verdana size=5>Content Manager</FONT></B></P><b><font face=\"Verdana\" size=\"2\">Build: </font></b><font face=\"Verdana\" size=\"2\">10.1.6306.4</font><br><b><font face=\"Verdana\" size=\"2\">Start time: </font></b><font face=\"Verdana\" size=\"2\">Tuesday, July 19, 2016 6:45:22 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">Current time: </font></b><font face=\"Verdana\" size=\"2\">Thursday, July 21, 2016 6:02:40 PM BRT</font><br><b><font face=\"Verdana\" size=\"2\">State: </font></b><font face=\"Verdana\" size=\"2\">Not running. See logs.</font><br></body></html>";
		
//		String state = parseState(resposta);
//		System.out.println("State: ["+state+"]");
		
//		String currentTime = parseCurrentTime(resposta);
//		System.out.println("Current time: ["+currentTime+"]");
		
		String running = RegexUtils.find(REGEX_STATE_RUNNING, resposta);
		System.out.println("Running: ["+running+"]");
//		
//		String s0 = state.split("State: ")[0];
//		String s1 = state.split("State: ")[1];
//		
//		System.out.println(s0);
//		System.out.println(s1);
		
		
	}
	
	private String parseState(String s) {
		String regexState = "<b><font face=\"Verdana\" size=\"2\">State: </font></b><font face=\"Verdana\" size=\"2\">[\\w\\.\\s]+</font><br>";
		
		String state = RegexUtils.find(regexState, s);
		
		state = state.replaceFirst("<b><font face=\"Verdana\" size=\"2\">State: </font></b><font face=\"Verdana\" size=\"2\">", "")
					.replaceFirst("</font><br>", "");
		return state;
	}
	
	private String parseCurrentTime(String s) {
//		String regexCurrentTime = "<b><font face=\"Verdana\" size=\"2\">Current time: </font></b><font face=\"Verdana\" size=\"2\">\\w+, \\w+ \\d+, \\d{4} \\d+:\\d+:\\d+ \\w{2} \\w{3}</font><br>";
		String regexCurrentTime = "<b><font face=\"Verdana\" size=\"2\">Current time: </font></b><font face=\"Verdana\" size=\"2\">[\\w,:\\s]+</font><br>";
		String currentTime = RegexUtils.find(regexCurrentTime, s);
		
		currentTime = currentTime.replaceFirst("<b><font face=\"Verdana\" size=\"2\">Current time: </font></b><font face=\"Verdana\" size=\"2\">", "")
								.replaceFirst("</font><br>", "");
		return currentTime;
	}
}
