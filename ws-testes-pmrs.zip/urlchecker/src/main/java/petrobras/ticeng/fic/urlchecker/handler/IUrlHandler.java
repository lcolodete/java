package petrobras.ticeng.fic.urlchecker.handler;


public interface IUrlHandler {

	String handleSuccess(String response) throws Exception;
	
	void handleError(String errorMsg);
	
	String getURL();
}
