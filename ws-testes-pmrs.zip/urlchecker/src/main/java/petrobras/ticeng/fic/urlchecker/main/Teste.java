package petrobras.ticeng.fic.urlchecker.main;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Teste {

	public static void main(String[] args) {
		double responseTime = 0;
		
		long begin = 7540;
		long end = 8000;
		responseTime = end - begin;
		
		responseTime /= 1000;
		
		NumberFormat nf = NumberFormat.getNumberInstance();
		nf.setMaximumFractionDigits(2);
		nf.setMinimumFractionDigits(2);
		
		String responseTimeStr = nf.format(responseTime);
		if (responseTime <= 5.0) {
			System.out.println("Resposta OK! Tempo de resposta : "+responseTimeStr+"s");
		} else {
			System.out.println("Resposta OK, porem com alto tempo de resposta : "+responseTimeStr+"s");
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		System.out.println(sdf.format(new Date()));

	}
}
