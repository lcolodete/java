package petrobras.ticeng.fic.urlchecker.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import petrobras.ticeng.fic.urlchecker.config.Configuracao;

public class HttpClient {

	private static final Logger logger = LogManager.getLogger(HttpClient.class);

	private final Configuracao configuracao = Configuracao.getInstance();
	
	public HttpClient() {
		
	}
	
    public String doGet(String url) throws Exception {
    	
    	SocketConfig config = SocketConfig.custom()
    			.setSoTimeout(configuracao.getTimeout())
    			.build();
    	
    	CloseableHttpClient httpclient = HttpClients.custom()
    			.setDefaultSocketConfig(config)
    	        .build();
    	
        try {
        	HttpGet httpget = new HttpGet(url);
        	
        	logger.info("Executing request " + httpget.getRequestLine());

            // Create a custom response handler
            ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

                @Override
                public String handleResponse(final HttpResponse response) throws ClientProtocolException, IOException {
                	
                    int status = response.getStatusLine().getStatusCode();
                    
                    if (status == 200) {
                        HttpEntity entity = response.getEntity();
                        
                        BufferedReader in = null; 
                        StringBuilder sb = new StringBuilder();
                        
                        try {
                        	in = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
                        	String line = "";
                        	int nLines = 0;
                        	while ( (line = in.readLine()) != null && nLines < 20 ) {
                        		nLines ++;
                        		logger.debug(">>>>>> "+ line);
                        		sb.append(line);
                        	}
                        	
                        } finally {
                        	if (in != null)
                				in.close();
                        }
                        
                        return entity != null ? sb.toString() : null;
                    } else {
                        throw new ClientProtocolException("Unexpected response status: " + status);
                    }
                }

            };
            
            String responseBody = httpclient.execute(httpget, responseHandler);
            logger.debug("----------------------------------------");
            logger.debug(responseBody);
            
            return responseBody;
            
        } finally {
            httpclient.close();
        }
    }

}