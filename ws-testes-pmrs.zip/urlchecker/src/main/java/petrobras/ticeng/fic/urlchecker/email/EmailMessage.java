package petrobras.ticeng.fic.urlchecker.email;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailMessage implements IMessage {
	private String sender;
	private String addressee;
	private String subject;
	private String body;

	@Override
	public void buildMessage(String sender, String addressee, String subject, String body) {
		this.sender = sender;
		this.addressee = addressee;
		this.subject = subject;
		this.body = body;
	}

	@Override
	public void send() {
		Properties mailServerProperties = new Properties();
		mailServerProperties.put("mail.smtp.host", "smtp.petrobras.com.br");
//		mailServerProperties.put("mail.smtp.host", "localhost");
		mailServerProperties.put("mail.smtp.port", "25");

		Session session = Session.getDefaultInstance(mailServerProperties);

		MimeMessage messageToSend = new MimeMessage(session);

		try {
			messageToSend.setFrom(new InternetAddress(this.sender));
			messageToSend.addRecipient(Message.RecipientType.TO, new InternetAddress(this.addressee));
			messageToSend.setSubject(this.subject);
			messageToSend.setText(this.body);

			Transport.send(messageToSend);
		} catch (MessagingException ex) {
			ex.printStackTrace();
		}
	}


}
