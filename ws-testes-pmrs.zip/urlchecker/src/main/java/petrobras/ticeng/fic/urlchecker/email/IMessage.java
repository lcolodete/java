package petrobras.ticeng.fic.urlchecker.email;

public interface IMessage {

	void buildMessage(String sender, String addressee, String subject, String body);
	
	void send();
}
