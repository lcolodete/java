package petrobras.ticeng.fic.urlchecker.handler.exception;

public class CognosInvalidStateException extends Exception {

	private static final long serialVersionUID = 1L;

	public CognosInvalidStateException() {
	}

	public CognosInvalidStateException(String message) {
		super(message);
	}

}
