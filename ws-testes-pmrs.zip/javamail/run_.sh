#!/bin/sh

# Informar o caminho do Java usado pelo WebLogic
JAVA_HOME="C:\Program Files\Java\jdk1.6.0_32"
export JAVA_HOME

$JAVA_HOME/bin/java -cp ./bin:./lib/javax.mail.jar petrobras.ticeng.test.email.EmailTest







