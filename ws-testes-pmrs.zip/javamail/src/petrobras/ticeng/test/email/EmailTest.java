package petrobras.ticeng.test.email;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailTest {
	public static void main(String[] args) {
		String addressee = "leandro.colodete@petrobras.com.br";
//		String addressee = "lcolodete@gmail.com";

//		String sender = "fic-noreply@petrobras.com.br";
		String sender = "fic-noreply@cognoscheck.com";
		
		EmailMessage emailMessage = new EmailMessage(sender, addressee, "email from James", "This is a test email sent from James");

		emailMessage.send();

		System.out.println("email sent to " + addressee);
	}
}

class EmailMessage {
	public String sender;
	public String addressee;
	public String subject;
	public String body;

	public EmailMessage(String sender, String addressee, String subject, String body) {
		this.sender = sender;
		this.addressee = addressee;
		this.subject = subject;
		this.body = body;
	}

	public void send() {
		Properties mailServerProperties = new Properties();
//		mailServerProperties.put("mail.smtp.host", "smtp.petrobras.com.br");
		mailServerProperties.put("mail.smtp.host", "localhost");
		mailServerProperties.put("mail.smtp.port", "25");

		Session session = Session.getDefaultInstance(mailServerProperties);

		MimeMessage messageToSend = new MimeMessage(session);

		try {
			messageToSend.setFrom(new InternetAddress(this.sender));
			messageToSend.addRecipient(Message.RecipientType.TO, new InternetAddress(this.addressee));
			messageToSend.setSubject(this.subject);
			messageToSend.setText(this.body);

			Transport.send(messageToSend);
		} catch (MessagingException ex) {
			ex.printStackTrace();
		}
	}

}
