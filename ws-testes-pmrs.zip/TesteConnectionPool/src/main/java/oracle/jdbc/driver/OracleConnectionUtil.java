package oracle.jdbc.driver;

import java.sql.Connection;

@Deprecated
public class OracleConnectionUtil {

//	java.lang.SecurityException: sealing violation: package oracle.jdbc.driver is sealed
//		at java.net.URLClassLoader.defineClass(URLClassLoader.java:234)
//		at java.net.URLClassLoader.access$000(URLClassLoader.java:58)
//		at java.net.URLClassLoader$1.run(URLClassLoader.java:197)
//		at java.security.AccessController.doPrivileged(Native Method)
//		at java.net.URLClassLoader.findClass(URLClassLoader.java:190)
//		at java.lang.ClassLoader.loadClass(ClassLoader.java:306)
//		at sun.misc.Launcher$AppClassLoader.loadClass(Launcher.java:301)
//		at java.lang.ClassLoader.loadClass(ClassLoader.java:247)
//		at petrobras.ticeng.fic.testepool.testes.birt.TestBirt2.runTest(TestBirt2.java:53)
//		at petrobras.ticeng.fic.testepool.testes.TestCase.run(TestCase.java:35)
//		at java.lang.Thread.run(Thread.java:662)
	public static int getSPID(Connection c) {
		T4CConnection oracleConnection = (T4CConnection) c;
		return oracleConnection.getSessionId();
	}
}
