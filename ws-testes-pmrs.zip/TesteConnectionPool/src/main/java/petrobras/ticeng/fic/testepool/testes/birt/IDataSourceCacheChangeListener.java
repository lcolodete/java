package petrobras.ticeng.fic.testepool.testes.birt;

public interface IDataSourceCacheChangeListener {

	public void onDataSourceCacheChange();
	
}
