package petrobras.ticeng.fic.testepool.testes.birt;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
//import test.reflection.DataSourceConnectionPool;

public class ConnectionPoolLoggerThread extends Thread {
	
	private final String LOG_ID = ConnectionPoolLoggerThread.class.getSimpleName();
	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	private ConnectionPoolLogger connectionPoolLogger;
	
	public ConnectionPoolLoggerThread() {
		super("ConnectionPoolLoggerThread");
		this.connectionPoolLogger = new ConnectionPoolLogger();
	}

	@Override
	public void run() {

		while (true) {
			
			try {
				Thread.sleep(30*1000);
			} catch (InterruptedException e) {
				log(LOG_ID, "Erro", e);
				
			}
			
			try {
				this.connectionPoolLogger.logConnectionsBirtUsedFree();
			} catch (Exception e1) {
				log(LOG_ID, "Erro", e1);
			}

		}
	}
	
	protected void log(String id, String msg) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		LOGGER.info( String.format("%s - %s", id, msg) );
	}

	protected void log(String id, String msg, Throwable t) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		//t.printStackTrace();
		LOGGER.error( String.format("%s - %s", id, msg), t );
	}

}
