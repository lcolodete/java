package petrobras.ticeng.fic.testepool.testes.birt;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnection;

public class TestBirt3 extends BirtTestCase {
	
	private final String LOG_ID = TestBirt3.class.getSimpleName();
	
	@Override
	protected void runTest() throws Exception {
		log(LOG_ID, "runTest()");
		
		for (int i=0; ; i++) {
			
			log(LOG_ID, "***************** Rodada "+ i +" - INICIO *****************");
			
			//pega a conexao
			log(LOG_ID, "Obtendo conexao...");
			
			long begin = System.currentTimeMillis();
			DataSourceConnection con1 = getDS().getNewConnection();
			long end = System.currentTimeMillis();
			double getNewConnectionTime = (end-begin)/1000.0;
			log(LOG_ID, "Conexao obtida em "+getNewConnectionTime+"s");
			
			log(LOG_ID, "Dados da Conexao: ["+con1.getConnection().toString()+"], SPID=["+this.oracleConnectionUtil.getSPID(con1.getConnection())+"]");
			
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			String now = df.format(new Date());
			log(LOG_ID, "Entrando em sleep : "+now);
			
			begin = System.currentTimeMillis();
			try {
				Thread.sleep(60*1000);
			} catch (InterruptedException e) {
				log(LOG_ID, "Erro", e);
				throw e;
			}
			end = System.currentTimeMillis();
			
			now = df.format(new Date());
			log(LOG_ID, "Fim sleep : "+now);
			
			//freeConnection
			log(LOG_ID, "Devolvendo conexao ao pool...");
			getDS().freeConnection(con1);
			log(LOG_ID, "Conexao devolvida.");
			
			log(LOG_ID, "***************** Rodada "+ i +" - FIM *****************");
		}
	}

}
