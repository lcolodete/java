package petrobras.ticeng.fic.testepool.util;

import java.lang.reflect.Field;

public class ReflectionUtil {

	/**
	 * Acessa o objeto DataSourceConnectionPool por reflection e
	 * obtem o valor do campo/atributo indicado por fieldName. 
	 *  
	 * @param fieldName nome do campo/atributo
	 * @return valor do campo/atributo, como um Object
	 * @throws Exception
	 */
	public static Object getFieldValueFromObject(Object o, String fieldName) throws Exception {
		Class<?> clazz = o.getClass();

		Field f = clazz.getDeclaredField(fieldName);
		f.setAccessible(true);
		Object fieldValue = f.get(o);
		return fieldValue;
	}

}
