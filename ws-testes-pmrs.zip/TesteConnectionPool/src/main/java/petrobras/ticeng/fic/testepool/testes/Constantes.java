package petrobras.ticeng.fic.testepool.testes;

public final class Constantes {

	public static final String LOGGER_NAME = "maximo.test";
	
	public static final String MAXIMOCACHE_REPORTDATASOURCE = "REPORTDATASOURCE";
}
