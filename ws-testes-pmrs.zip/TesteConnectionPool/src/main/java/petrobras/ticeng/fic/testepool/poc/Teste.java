package petrobras.ticeng.fic.testepool.poc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import psdi.security.ConnectionKey;
import psdi.server.ConRef;
import psdi.server.DBManager;
import psdi.server.DBManagerWrapper;
import psdi.server.MXServer;

public class Teste {
	
	private static final String LOG = ">>>>> MAIN -> ";
	
	public static void main(String[] args) throws Exception {
		
		DBManager manager = null;

		try {
	
			//Nao precisa. Ver mais abaixo.
//			manager = new DBManager();
			
			Properties props = new Properties();
			props.setProperty("mxe.db.driver", "oracle.jdbc.OracleDriver");
			props.setProperty("mxe.db.initialConnections", "3");
			props.setProperty("mxe.db.maxFreeConnections", "3");
			props.setProperty("mxe.db.minFreeConnections", "1");
			props.setProperty("mxe.db.newConnectionCount", "1");
			
			props.setProperty("mxe.db.schemaowner", "fic");
			
			props.setProperty("mxe.db.url", "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=zurg.petrobras.com.br)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=FICH.petrobras.com.br)))");
			props.setProperty("mxe.db.user", "FIC");
			props.setProperty("mxe.db.password", "Cnc7Qx_whj");
			
			//maquina Johnny
//			props.setProperty("mxe.db.url", "jdbc:oracle:thin:@MI00284056:1521:maximo");
//			props.setProperty("mxe.db.user", "fic");
//			props.setProperty("mxe.db.password", "maximo");
			
			props.setProperty("mxe.db.resultsettype", "TYPE_FORWARD_ONLY");
			props.setProperty("mxe.db.fetchsize", "40");
			props.setProperty("mxe.db.autocommit", "0");
			props.setProperty("mxe.db.transaction_isolation", "TRANSACTION_READ_COMMITTED");
			
			props.setProperty("mxe.name", "MXServer");
			
			MXServer.start(props);
			
			//Nao precisa executar essas linhas!!!! MXServer.start internamente ja deve fazer isso!!!
//			manager.configure(props);
//			manager.init();
			
		} catch (Exception e) {
			System.out.println(Teste.LOG + " ============== Excecao no metodo main =============");
			e.printStackTrace();
			System.out.println(Teste.LOG + " ===================================================");
		}
			
		//espera tempo suficiente para o DBManager inicializar
		Thread.sleep(5000);
		
		manager = MXServer.getMXServer().getDBManager();
		System.out.println(Teste.LOG + "MXServer.getMXServer().getDBManager()=["+manager+"]");
		
		DBManagerWrapper wrapper = new DBManagerWrapper(manager);
		
		wrapper.logFree();
		wrapper.logUsed();
		
		Client client = new Client(wrapper);
		Thread t = new Thread(client);
		t.start();
		
		synchronized (client) {
			client.wait();
		}
		
		System.out.println(Teste.LOG + "Fim do teste");
		System.out.println(Teste.LOG + "DBManager sera destruido");
		
		manager.destroy();
		
		System.out.println(Teste.LOG + "DBManager.destroy concluido");
		
		wrapper.logFree();
		wrapper.logUsed();
		
		System.exit(0);
	}
	
}

class Client implements Runnable {

	private DBManagerWrapper wrapper = null;
	private DBManager manager = null;
	
	private static final String LOG = ">>>>> Client -> ";
	
	public Client(DBManagerWrapper wrapper) {
		this.wrapper = wrapper;
		this.manager = wrapper.getManager();
	}
	
	@Override
	public void run() {
		
		if (this.manager != null) {
			System.out.println(Client.LOG + "this.manager=["+this.manager.toString()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnFree=["+this.manager.getDBConnFree()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnTotal=["+this.manager.getDBConnTotal()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnUsed=["+this.manager.getDBConnUsed()+"]");
			
			ConnectionKey connectionKey = this.manager.getSystemConnectionKey();
			
			System.out.println(Client.LOG + "connectionKey=["+connectionKey+"]");

			System.out.println(Client.LOG + "ANTES DE PEGAR A CONEXAO");
			try {
				wrapper.logFree();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				wrapper.logUsed();
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			ConRef con1 = (ConRef) this.manager.getConnection(connectionKey);

			System.out.println(Client.LOG + "DEPOIS DE PEGAR A CONEXAO");
			try {
				wrapper.logFree();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				wrapper.logUsed();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			System.out.println(Client.LOG + "conRef=["+con1+"]");

			System.out.println(Client.LOG + "this.manager.getDBConnFree=["+manager.getDBConnFree()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnTotal=["+manager.getDBConnTotal()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnUsed=["+manager.getDBConnUsed()+"]");

			//retorna a mesma conexao de antes
			ConRef con3 = (ConRef) this.manager.getConnection(connectionKey);
			
			System.out.println(Client.LOG + "conRef=["+con3+"]");

			System.out.println(con1.equals(con3));
			System.out.println(con1 == con3);
			
			System.out.println(Client.LOG + "this.manager.getDBConnFree=["+manager.getDBConnFree()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnTotal=["+manager.getDBConnTotal()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnUsed=["+manager.getDBConnUsed()+"]");


			// usa a conexao obtida para fazer uma query
			PreparedStatement stmt = null;
			ResultSet rs = null;

			try {
				
				stmt = con3.prepareStatement("SELECT * FROM maxsession");
				rs = stmt.executeQuery();
				
				while (rs.next()) {
					System.out.println(rs.getObject("userid").toString() + " - " + rs.getObject("issystem").toString() + " - " + rs.getObject("logindatetime").toString());
				}

				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if (rs != null)
					try {
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				if (stmt != null)
					try {
						stmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
			

			//retorna uma nova connectionKey!!!
			connectionKey = manager.getSystemConnectionKey();
			
			System.out.println(Client.LOG + "outra connectionKey=["+connectionKey+"]");

			//consigo pegar uma nova conexao
			ConRef con2 = (ConRef) this.manager.getConnection(connectionKey);
			
			System.out.println(Client.LOG + "conRef=["+con2+"]");

			System.out.println(Client.LOG + "this.manager.getDBConnFree=["+manager.getDBConnFree()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnTotal=["+manager.getDBConnTotal()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnUsed=["+manager.getDBConnUsed()+"]");
			
			this.manager.freeConnection(connectionKey);
			System.out.println(Client.LOG + "this.manager.getDBConnFree=["+manager.getDBConnFree()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnTotal=["+manager.getDBConnTotal()+"]");
			System.out.println(Client.LOG + "this.manager.getDBConnUsed=["+manager.getDBConnUsed()+"]");

		} else {
			System.out.println(Client.LOG + "this.manager == null");
		}
		
		synchronized (this) {
			notify();
		}
	}
	
}
