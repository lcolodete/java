package petrobras.ticeng.fic.testepool.poc;

public class TesteRunnable {

	public static void main(String[] args) throws InterruptedException {

		int i = 0;
		
		for (;;) {
			System.out.println("i="+i++);
			long begin = System.currentTimeMillis();
			Thread.sleep(3000);
			long end = System.currentTimeMillis();
			double sleepTime = (end-begin)/1000.0;
			System.out.println("Acordei apos "+sleepTime+" segundos");
		}
		
	}
}
