package petrobras.ticeng.fic.testepool.testes.birt;


public class TestBirt4 extends BirtTestCase {
	
	private final String LOG_ID = TestBirt4.class.getSimpleName();
	
	@Override
	protected void runTest() {
		log(LOG_ID, "runTest()");
		
		for (int i=0; ; i++) {
			
			log(LOG_ID, "***************** Rodada "+ i +" - INICIO *****************");
			
			try {
				Thread.sleep(120*1000);
			} catch (InterruptedException e) {
				log(LOG_ID, "Erro", e);
				
			}

			log(LOG_ID, "***************** Rodada "+ i +" - FIM *****************");
		}
	}

}
