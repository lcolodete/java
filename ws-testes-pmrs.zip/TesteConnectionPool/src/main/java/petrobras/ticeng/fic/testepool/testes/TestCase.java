package petrobras.ticeng.fic.testepool.testes;

import java.text.SimpleDateFormat;
import java.util.Date;

import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public abstract class TestCase implements Runnable {

	private final String LOG_ID = TestCase.class.getSimpleName();
	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	protected abstract void runTest() throws Exception;
	
	protected void before() throws Exception {
		log(LOG_ID, "before");
	}
	
	protected void after() {
		log(LOG_ID, "after");
	}

	public void run() {
		
		int exitCode = 0;
		
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		String now = df.format(new Date());
		
		log(LOG_ID, "INICIO: "+now);
		
		try {
			//Excecoes em before() ou runTest() devem interromper a execucao do teste 
			before();
			runTest();
		} catch (Exception e) {
			log(LOG_ID, "Erro", e);
			exitCode = -1;
		} finally {
			try {
				after();
			} catch (Exception e) {
				log(LOG_ID, "Erro", e);
				exitCode = -2;
			}
		}
		
		now = df.format(new Date());
		
		log(LOG_ID, "FIM: "+now);
		
		System.exit(exitCode);
	}
	
	protected void log(String id, String msg) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		LOGGER.info( String.format("%s - %s", id, msg) );
	}
	
	protected void log(String id, String msg, Throwable t) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		//t.printStackTrace();
		LOGGER.error( String.format("%s - %s", id, msg), t );
	}
	
	
}

