package petrobras.ticeng.fic.testepool.testes.birt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import petrobras.ticeng.fic.testepool.testes.birt.datasource.util.DataSourceUtil;
import petrobras.ticeng.fic.testepool.testes.maximo.MaximoConnectionPoolLogger;
import petrobras.ticeng.fic.testepool.util.ReflectionUtil;
import psdi.server.MXServer;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnectionPool;

public class RefreshPoolThread extends Thread {

	private final String LOG_ID = RefreshPoolThread.class.getSimpleName();
	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	private MaximoConnectionPoolLogger connectionPoolLogger;
	
	public RefreshPoolThread() {
		super("RefreshPoolThread");
		this.connectionPoolLogger = new MaximoConnectionPoolLogger();
	}

	@Override
	public void run() {
		
		while (true) {
			
			try {
				//TODO ajustar tempo
				Thread.sleep(900*1000);//15 minutos
			} catch (InterruptedException e) {
				log(LOG_ID, "Erro", e);
			}
			
			//imprime no log os registros em v$session, usando conexao obtida do DBManager
			log(LOG_ID, "gv$session antes do refresh");
			this.connectionPoolLogger.logTable_GV$SESSION();
			
			DataSourceConnectionPool pool;
			try {
				pool = DataSourceUtil.getConnectionPool();
				if (pool != null) {
					
					log(LOG_ID, "pool="+pool.toString());
					
					synchronized(pool) {
						this.refreshConnections(pool);
					}
				}
			} catch (Exception e) {
				log(LOG_ID, "Erro", e);
			}

			//imprime no log os registros em v$session, usando conexao obtida do DBManager
			log(LOG_ID, "gv$session apos refresh");
			this.connectionPoolLogger.logTable_GV$SESSION();
		}
	}
	
	
	@SuppressWarnings("unchecked")
	private void refreshConnections(DataSourceConnectionPool pool) throws Exception {
		ArrayList<Connection> free = (ArrayList<Connection>) ReflectionUtil.getFieldValueFromObject(pool, "free");
		
		int size = free.size();
		
		log(LOG_ID, "free.size()=" +size);
		
		if (size > 0) {
			int i = 1;
			for (Connection c : free) {
				log(LOG_ID, i+") ["+c.toString()+"], SPID=["+this.executeSimpleQuery(c)+"]");
				i++;
			}
		}
	}
	
	/**
	 * Executa uma query simples usando a conexao dada.
	 * Por simplicidade (e por ja ter testado), executa uma query que retorna o sessionId da conexao.
	 * 
	 * @param con Conexao atraves da qual a query sera executada.
	 * @return sessionId da conexao na tabela gv$session
	 */
	private int executeSimpleQuery(Connection con) {
		
		log(LOG_ID, "executeSimpleQuery with connection=["+ con.toString() +"]");
		
		int sessionId = -1;
		
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			log(LOG_ID, "Executando query...");
			
			stmt = con.prepareStatement("select sys_context('USERENV','SID') from dual");
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				sessionId = rs.getInt(1);
			}
			
			log(LOG_ID, "Query executada: sessionId=["+sessionId+"]");
			
		} catch (SQLException e) {
			log(LOG_ID, "Ocorreu um erro em executeSimpleQuery", e);
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					log(LOG_ID, "Ocorreu um erro ao executar rs.close()", e);
				}
			
			if (stmt != null)
				try {
					stmt.close();
				} catch (SQLException e) {
					log(LOG_ID, "Ocorreu um erro ao executar stmt.close()", e);
				}
		}
		
		return sessionId;
	}


	@SuppressWarnings("unchecked")
	public void run_SOLUCAO1_RADICAL() {
		
		while (true) {
			
			try {
				//TODO ajustar tempo
				Thread.sleep(180*1000);
			} catch (InterruptedException e) {
				log(LOG_ID, "Erro", e);
			}
			
			DataSourceConnectionPool pool;
			try {
				pool = DataSourceUtil.getConnectionPool();
				if (pool != null) {
					
					log(LOG_ID, "pool="+pool.toString());
					
					synchronized(pool) {
						ArrayList<Connection> used = (ArrayList<Connection>) ReflectionUtil.getFieldValueFromObject(pool, "used");
						int size = used.size();
						log(LOG_ID, "used.size()=" +size);
						
						if (size < 1) {
							SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
							String now = df.format(new Date());
							
							log(LOG_ID, "INICIO: "+now);
							
							MXServer mxServer = MXServer.getMXServer();
							mxServer.reloadMaximoCache( Constantes.MAXIMOCACHE_REPORTDATASOURCE , false);
							
							now = df.format(new Date());
							log(LOG_ID, "FIM: "+now);
						}
					}
				}
				
			} catch (Exception e) {
				log(LOG_ID, "Erro", e);
			}

		}
		
	}
	
	protected void log(String id, String msg) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		LOGGER.info( String.format("%s - %s", id, msg) );
	}

	protected void log(String id, String msg, Throwable t) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		//t.printStackTrace();
		LOGGER.error( String.format("%s - %s", id, msg), t );
	}
	
}
