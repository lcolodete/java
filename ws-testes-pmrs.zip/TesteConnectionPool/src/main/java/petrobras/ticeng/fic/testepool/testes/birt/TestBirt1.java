package petrobras.ticeng.fic.testepool.testes.birt;

import java.rmi.RemoteException;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnection;

/**
 * 
 * @author ur5g
 *
 */
public class TestBirt1 extends BirtTestCase {

//	private final String LOG_ID = TestBirt1.class.getSimpleName();
	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	@Override
	protected void runTest() throws RemoteException {
//		log(LOG_ID, "runTest()");
		LOGGER.info("runTest()");
		
//		log(LOG_ID, "INICIO");
		LOGGER.info("INICIO");
		
		DataSourceConnection con1 = getDS().getNewConnection();
		
//		log(LOG_ID, "con1=["+con1.getConnection().toString()+"]");
		LOGGER.info("con1=["+con1.getConnection().toString()+"]");
		
		getDS().freeConnection(con1);

		DataSourceConnection con2 = getDS().getNewConnection();
		
//		log(LOG_ID, "con2=["+con2.getConnection().toString()+"]");
		LOGGER.info("con2=["+con2.getConnection().toString()+"]");
		
		getDS().freeConnection(con2);

//		log(LOG_ID, "FIM");
		LOGGER.info("FIM");
	}
}
