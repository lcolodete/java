package petrobras.ticeng.fic.testepool.testes.birt;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import petrobras.ticeng.fic.testepool.testes.birt.datasource.util.DataSourceUtil;
import petrobras.ticeng.fic.testepool.util.OracleConnectionUtilEx;
import petrobras.ticeng.fic.testepool.util.ReflectionUtil;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnectionPool;

public class ConnectionPoolLogger {

	private final String LOG_ID = ConnectionPoolLogger.class.getSimpleName();
	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);

	private OracleConnectionUtilEx oracleConnectionUtil = OracleConnectionUtilEx.getOracleConnectionUtil();

	@SuppressWarnings("unchecked")
	private void logArray(DataSourceConnectionPool pool, String arrayName) throws Exception {
		ArrayList<Connection> arrayObj = (ArrayList<Connection>) ReflectionUtil.getFieldValueFromObject(pool, arrayName);
		
		int size = arrayObj.size();
		
		log(LOG_ID, arrayName+" = " +size);
		
		if (size > 0) {
			int i = 1;
			for (Connection c : arrayObj) {
				log(LOG_ID, i+") ["+c.toString()+"], SPID=["+this.oracleConnectionUtil.getSPID(c)+"]");
				i++;
			}
		}
	}
	
	public void logConnectionsBirtUsedFree() throws Exception {
		
		DataSourceConnectionPool pool = DataSourceUtil.getConnectionPool();
		
		if (pool != null) {
			
			log(LOG_ID, "pool="+pool.toString());
			
			synchronized(pool) {
				SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				String now = df.format(new Date());
				
				log(LOG_ID, "< logConnections > INICIO: "+now);
				
				logArray(pool, "free");
				logArray(pool, "used");
				
				now = df.format(new Date());
				log(LOG_ID, "< logConnections > FIM: "+now);
			}
		}
	}

	protected void log(String id, String msg) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		LOGGER.info( String.format("%s - %s", id, msg) );
	}

	protected void log(String id, String msg, Throwable t) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		//t.printStackTrace();
		LOGGER.error( String.format("%s - %s", id, msg), t );
	}

}
