package petrobras.ticeng.fic.testepool.testes.maximo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import psdi.security.ConnectionKey;
import psdi.server.ConRef;
import psdi.server.DBManager;

/**
 * Pega uma conexao, usa e devolve ao pool (executa {@link DBManager#freeConnection(psdi.security.ConnectionKey)}).
 * <br>
 * Repete essa operacao 7 vezes. A cada execucao, espera mais tempo antes de usar a conexao :
 * <br>
 * <ul>
 * <li>32 minutos</li>
 * <li>42 minutos</li>
 * <li>52 minutos</li>
 * <li>62 minutos</li>
 * <li>72 minutos</li>
 * <li>82 minutos</li>
 * <li>92 minutos</li>
 * </ul>
 * 
 * Ao final, pega uma nova conexao (por um novo connectionKey), usa e devolve ao pool. 
 * 
 * @author ur5g
 *
 */
public class TestMaximo1 extends MaximoTestCase {

	private final String LOG_ID = TestMaximo1.class.getSimpleName();
	
	@Override
	protected void runTest() {
		log(LOG_ID, "runTest()");
		log(LOG_ID, "Versão gerada em 21/10/2015 14h28 - SMP atualizado com fix Oracle RAC");
	
		DBManager manager = getWrapper().getManager();
		
		ConnectionKey connectionKey = manager.getSystemConnectionKey();
		
		log(LOG_ID, "connectionKey=["+connectionKey+"]");
		
		int[] rodadas = {32, 42, 52, 62, 72, 82, 92};
//		int[] rodadas = {1, 2, 3, 4};
		
		for (int i=0; i<rodadas.length; i++) {
			
			log(LOG_ID, "***************** Rodada "+ i +" ("+ rodadas[i] +" min) - INICIO *****************");
			
			//pega a conexao
			
			ConRef con = (ConRef) manager.getConnection(connectionKey);

			log(LOG_ID, "Dados da Conexao: conRef=["+con+"], SPID=["+con.getSPID()+"]");
			
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			String now = df.format(new Date());
			log(LOG_ID, "Entrando em sleep : "+now);
			
			long begin = System.currentTimeMillis();
			try {
				Thread.sleep(rodadas[i]*60*1000);
			} catch (InterruptedException e) {
				log(LOG_ID, "Erro", e);
			}
			long end = System.currentTimeMillis();
			double sleepTime = (end-begin)/1000.0;
			
			now = df.format(new Date());
			log(LOG_ID, "Fim sleep : "+now);
			
			log(LOG_ID, "Tempo em sleep : "+sleepTime+"s");

			//usa e devolve
			
			PreparedStatement stmt = null;
			ResultSet rs = null;

			try {
				log(LOG_ID, "Executando query...");
				
				stmt = con.prepareStatement("select * from site  where (active=1) and (siteid in(select siteid from siteauth a,groupuser b  where a.groupname=b.groupname and b.userid =  'PRV_IERENEST-IEHDT-JEY-001' )  and active = 1)");
				
				begin = System.currentTimeMillis();
				rs = stmt.executeQuery();
				end = System.currentTimeMillis();
				double queryTime = (end-begin)/1000.0;
				
				log(LOG_ID, "Query executada em "+queryTime+"s");
				
				while (rs.next()) {
					log(LOG_ID, rs.getObject("siteid").toString() + " - " + rs.getObject("active").toString() + " - " + rs.getObject("changedate").toString());
				}
				
			} catch (SQLException e) {
				log(LOG_ID, "Erro", e);
			} finally {
				if (rs != null)
					try {
						rs.close();
					} catch (SQLException e) {
						log(LOG_ID, "Erro", e);
					}
				
				if (stmt != null)
					try {
						stmt.close();
					} catch (SQLException e) {
						log(LOG_ID, "Erro", e);
					}
				
				try {
					getWrapper().logFree();
				} catch (Exception e) {
					log(LOG_ID, "Erro", e);
				}
				try {
					getWrapper().logUsed();
				} catch (Exception e) {
					log(LOG_ID, "Erro", e);
				}
				log(LOG_ID, "getDBConnTotal = "+manager.getDBConnTotal());
				
				log(LOG_ID, "Devolvendo ao pool: conRef=["+con+"], SPID=["+con.getSPID()+"]");
				manager.freeConnection(connectionKey);
				log(LOG_ID, "Conexao devolvida.");
				
				try {
					getWrapper().logFree();
				} catch (Exception e) {
					log(LOG_ID, "Erro", e);
				}
				try {
					getWrapper().logUsed();
				} catch (Exception e) {
					log(LOG_ID, "Erro", e);
				}
				log(LOG_ID, "getDBConnTotal = "+manager.getDBConnTotal());
			}
			
			log(LOG_ID, "***************** Rodada "+ i +" ("+ rodadas[i] +" min) - FIM ********************");

		} // FIM DO FOR
		
		//obtem outro ConnectionKey
		ConnectionKey connectionKey2 = manager.getSystemConnectionKey();
		
		log(LOG_ID, "connectionKey2=["+connectionKey2+"]");
		
		//pega conexao
		ConRef con2 = (ConRef) manager.getConnection(connectionKey2);
		
		log(LOG_ID, "con2=["+con2+"], SPID=["+con2.getSPID()+"]");
		
		// usa a conexao obtida para fazer uma query
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			log(LOG_ID, "Executando query...");
			
			stmt = con2.prepareStatement("SELECT * FROM maxsession");
			
			long begin = System.currentTimeMillis();
			rs = stmt.executeQuery();
			long end = System.currentTimeMillis();
			double queryTime = (end-begin)/1000.0;
			
			log(LOG_ID, "Query executada em "+queryTime+"s");
			
			while (rs.next()) {
				log(LOG_ID, rs.getObject("userid").toString() + " - " + rs.getObject("issystem").toString() + " - " + rs.getObject("logindatetime").toString());
			}
			
		} catch (SQLException e) {
			log(LOG_ID, "Erro", e);
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					log(LOG_ID, "Erro", e);
				}
			
			if (stmt != null)
				try {
					stmt.close();
				} catch (SQLException e) {
					log(LOG_ID, "Erro", e);
				}
			
			//devolve a conexao ao pool
			log(LOG_ID, "Devolvendo ao pool: conRef=["+con2+"], SPID=["+con2.getSPID()+"]");
			manager.freeConnection(connectionKey2);
			log(LOG_ID, "Conexao devolvida.");
		}
		
	}
}
