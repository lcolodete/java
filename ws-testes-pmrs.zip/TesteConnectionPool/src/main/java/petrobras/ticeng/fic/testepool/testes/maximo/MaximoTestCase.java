package petrobras.ticeng.fic.testepool.testes.maximo;

import java.rmi.RemoteException;
import java.util.Properties;

import petrobras.ticeng.fic.testepool.testes.TestCase;
import psdi.server.DBManager;
import psdi.server.DBManagerWrapper;
import psdi.server.MXServer;

public abstract class MaximoTestCase extends TestCase {

	private static final String LOG_ID = MaximoTestCase.class.getSimpleName();
	
	private DBManagerWrapper wrapper;
	
	protected DBManagerWrapper getWrapper() {
		return wrapper;
	}

	protected void setWrapper(DBManagerWrapper wrapper) {
		this.wrapper = wrapper;
	}

	@Override
	protected void before() throws Exception {
		super.before();
		
		Properties props = new Properties();
		props.setProperty("mxe.db.driver", "oracle.jdbc.OracleDriver");
		props.setProperty("mxe.db.initialConnections", "1");
		props.setProperty("mxe.db.maxFreeConnections", "1");
		props.setProperty("mxe.db.minFreeConnections", "1");
		props.setProperty("mxe.db.newConnectionCount", "1");
		
		props.setProperty("mxe.db.schemaowner", "fic");

		//DESENV
//		props.setProperty("mxe.db.url", "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=carijo.petrobras.com.br)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=FICD.petrobras.com.br)))");
//		props.setProperty("mxe.db.user", "FIC");
//		props.setProperty("mxe.db.password", "lkjhgfd_09");
		
		//PROD
		props.setProperty("mxe.db.url", "jdbc:oracle:thin:@(DESCRIPTION =	(LOAD_BALANCE=YES)(ADDRESS = (PROTOCOL = TCP)(HOST = vipficpa.petrobras.com.br)(PORT = 1521))(ADDRESS = (PROTOCOL = TCP)(HOST = vipficpb.petrobras.com.br)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = FICP.PETROBRAS.COM.BR)(FAILOVER_MODE=(TYPE=SELECT)(METHOD=BASIC)(RETRIES=180)(DELAY=5))))");
		props.setProperty("mxe.db.user", "FIC");
		props.setProperty("mxe.db.password", "B2DHqf_FUv");
		
		props.setProperty("mxe.db.resultsettype", "TYPE_FORWARD_ONLY");
		props.setProperty("mxe.db.fetchsize", "40");
		props.setProperty("mxe.db.autocommit", "0");
		props.setProperty("mxe.db.transaction_isolation", "TRANSACTION_READ_COMMITTED");
		
		props.setProperty("mxe.name", "MXServerUR5G");
		
		//Funciona! Nao roda nenhuma cron nem escalation
		props.setProperty("mxe.crontask.donotrun", "ALL");
		
		props.setProperty("mxe.report.birt.disablequeuemanager", "1");
		
		//Funcionou!
		//a propriedade birt.maxconcurrentrun determina a quantidade de conexoes criadas no data source do BIRT
		props.setProperty("mxe.report.birt.maxconcurrentrun", "3");

		//TODO testar em DESENV
//		props.setProperty("mxe.db.closelongrunconn", "true");
//		props.setProperty("mxe.db.longruntimelimit", "10");
		
		try {
			// Para o start rodar com sucesso TOTAL, é preciso ter o conteudo do diretorio properties do SMP no classpath do projeto TesteConnectionPool.
			// Sem o diretorio properties, ocorre uma excecao. Porem, mesmo assim o connection pool é iniciado com sucesso.
			MXServer.start(props);
		} catch (Exception e) {
			//Essa excecao é esperada: loga e segue em frente
			log(LOG_ID, "============== Excecao em MaximoTestCase.before() =============");
			log(LOG_ID, "Exception=["+e.toString()+"]");
			log(LOG_ID, "Msg=["+e.getMessage()+"], Cause=["+e.getCause()+"]");
			log(LOG_ID, "===============================================================");
		}

		log(LOG_ID, "***** MXServer iniciado com sucesso *****");
		
		MXServer mxServer = MXServer.getMXServer();
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
//		MXServerWrapper mxServerWrapper = new MXServerWrapper(mxServer);
//		mxServerWrapper.logMXServerProperties();
//		
//		MaxPropCache maxPropCache = (MaxPropCache) mxServer.getFromMaximoCache("MAXPROP");
//		
//		log(LOG_ID, "lida do cache="+maxPropCache.getProperty("mxe.crontask.donotrun"));
//		
//		//Nao surtiu nenhum efeito
////		mxServerWrapper.setProperty("mxe.crontask.donotrun", "ESCALATION");
//
//		//TODO testar reload sem parametros
//		maxPropCache.reload("mxe.crontask.donotrun");
//		
//		log(LOG_ID, "apos o reload="+maxPropCache.getProperty("mxe.crontask.donotrun"));
//		
//		mxServerWrapper.logMXServerProperties();
//		
//		log(LOG_ID, "maxPropCache.getFilePropNames() - INICIO");
//		for (Object name : maxPropCache.getFilePropNames()) {
//			log(LOG_ID, name.toString());
//		}
//		log(LOG_ID, "maxPropCache.getFilePropNames() - FIM");
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		DBManager manager = mxServer.getDBManager();
		log(LOG_ID, "DBManager=["+manager+"]");
		
		DBManagerWrapper wrapper = new DBManagerWrapper(manager);
		wrapper.logFree();
		wrapper.logUsed();

		setWrapper(wrapper);
	}

	@Override
	protected void after() {
		super.after();
		log(LOG_ID, "Destruindo DBManager...");
		
		try {
			MXServer srv = MXServer.getMXServer();
			//TODO nao esta funcionando!
			//srv.destroy();
			//log(LOG_ID, "MXServer destruido");
		} catch (RemoteException e) {
			log(LOG_ID, "Erro", e);
		} finally {
			
			if (getWrapper() != null) {
				
				if (getWrapper().getManager() != null) {
					getWrapper().getManager().destroy();
					log(LOG_ID, "DBManager destruido");
				}
				
				try {
					getWrapper().logFree();
				} catch (Exception e) {
					log(LOG_ID, "Erro", e);
				}
				try {
					getWrapper().logUsed();
				} catch (Exception e) {
					log(LOG_ID, "Erro", e);
				}
			}
			
		}
		
	}

}
