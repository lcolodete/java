package petrobras.ticeng.fic.testepool.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class OracleConnectionUtilEx {

	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	private final Map<Connection,Integer> map = new HashMap<Connection,Integer>();
	
	private static OracleConnectionUtilEx instance;
	
	private OracleConnectionUtilEx() {
	}
	
	public static synchronized OracleConnectionUtilEx getOracleConnectionUtil() {
		if (instance == null) {
			instance = new OracleConnectionUtilEx();
		}
		return instance; 
	}
	
	public synchronized int getSPID(Connection con) {
		int sessionId = -1;
		
		if (map.get(con) != null) {
			LOGGER.info("Connection ["+con.toString()+"] esta no map. Retornando sessionId armazenado.");
			sessionId = map.get(con).intValue();
		} else {
			LOGGER.info("Connection nao esta no map!!!");
			sessionId = executeQuery(con);
			map.put(con, Integer.valueOf(sessionId));
			LOGGER.info("<Connection,sessionId>=<"+con.toString()+","+sessionId+"> armazenado no map.");
		}
		
		return sessionId;
	}
	
	private int executeQuery(Connection con) {
		int sessionId = -1;
		
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			LOGGER.info("Executando query para obter sessionId...");
			
			stmt = con.prepareStatement("select sys_context('USERENV','SID') from dual");
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				sessionId = rs.getInt(1);
			}
			
			LOGGER.info("Query executada. sessionId="+sessionId);
			
		} catch (SQLException e) {
			LOGGER.error("Ocorreu um erro ao executar OracleConnectionUtil.getSPID()", e);
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					LOGGER.error("Ocorreu um erro ao executar rs.close()", e);
				}
			
			if (stmt != null)
				try {
					stmt.close();
				} catch (SQLException e) {
					LOGGER.error("Ocorreu um erro ao executar stmt.close()", e);
				}
		}
		
		return sessionId;
	}

}
