package petrobras.ticeng.fic.testepool.testes.birt.datasource.util;

import java.rmi.RemoteException;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import psdi.server.MXServer;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSource;
import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceCache;
import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnectionPool;
import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceImpl;

public class DataSourceUtil {
	
	public static DataSourceConnectionPool getConnectionPool() throws RemoteException {
		MXServer mxServer = MXServer.getMXServer();
		DataSourceCache dataSourceCache = (DataSourceCache) mxServer.getFromMaximoCache( Constantes.MAXIMOCACHE_REPORTDATASOURCE );
		DataSourceConnectionPool connectionPool = dataSourceCache.getDataSourceConnectionPool("maximoDataSource");
		return connectionPool;
	}
	
	public static DataSource getDataSource() throws RemoteException {
		DataSourceConnectionPool connectionPool = DataSourceUtil.getConnectionPool();
		
		DataSource ds = new DataSourceImpl(connectionPool);
		return ds;
	}
}
