package petrobras.ticeng.fic.testepool.testes.birt;

import java.rmi.RemoteException;

import petrobras.ticeng.fic.testepool.testes.birt.datasource.util.DataSourceUtil;
import petrobras.ticeng.fic.testepool.testes.maximo.MaximoTestCase;
import petrobras.ticeng.fic.testepool.util.OracleConnectionUtilEx;
import psdi.server.MXServerInfo;
import psdi.server.MXServerInfoWrapper;
import psdi.util.MXException;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSource;
import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceCache;
import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnectionPool;

public abstract class BirtTestCase extends MaximoTestCase {
	
	private final String LOG_ID = BirtTestCase.class.getSimpleName();
	
	protected OracleConnectionUtilEx oracleConnectionUtil = OracleConnectionUtilEx.getOracleConnectionUtil();

	protected DataSource getDS() throws RemoteException {
		return DataSourceUtil.getDataSource();
	}
	
	@Override
	protected void before() throws Exception {
		super.before();
		
		log(LOG_ID, "Versão gerada em 16/09/2015 16h29");
		
		log(LOG_ID, "Inicializando pool do BIRT...");

		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//
		// USANDO DataSourceConnectionPool
		//
		// * Serve para um teste simples e direto. Instancia explicitamente um pool e, assim, torna possivel usar a API para fazer getConnection e freeConnection.
		//
		// OBS 1: Nao precisa do Maximo iniciado (estender TestCase).
		// OBS 2: Nesse caso, a thread REPORTCONPOOLMGR não roda (ou seja, o metodo adjustPool() do pool nunca é chamado).
		//
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//		DataSourceInfo info = new DataSourceInfo();
//		info.setDriver("oracle.jdbc.OracleDriver");
//		info.setUrl("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=zurg.petrobras.com.br)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=FICH.petrobras.com.br)))");
//		info.setUserName("FIC");
//		info.setPassword("Cnc7Qx_whj");
//		info.setSchemaOwner("fic");
//		info.setName("maximoDataSource");
//		
//		this.pool = new DataSourceConnectionPool(info);
//
//		this.ds = new DataSourceImpl(pool);
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//
		// USANDO DataSourceCache
		//
		// * Teste completo, muito similiar a Produção. Instancia o pool interno e tem acesso aos datasources da Administração de Relatórios.
		//
		// OBS 1: Precisa do MXServer iniciado (estender MaximoTestCase).
		// OBS 2: É preciso incluir o conteudo do properties.jar do maximo.ear no classpath do projeto.
		// 			Caso nao tenha o properties no classpath:
		//				Inicia com erros, funciona, mas so instancia um unico pool (o interno) e nao tem acesso aos datasources da Administração de Relatórios.
		//
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		//Esse macete so é necessario caso nao tenha o properties no classpath
		MXServerInfo serverInfo = MXServerInfo.getMXServerInfo();
		MXServerInfoWrapper serverInfoWrapper = new MXServerInfoWrapper(serverInfo);
		serverInfoWrapper.setRunning(true);

		//Essa linha faz o start na thread REPORTCONPOOLMGR (apenas caso nao tenha o properties no classpath. Se tiver o properties, a thread é iniciada anteriormente)
		DataSourceCache dataSourceCache = DataSourceCache.getDataSourceCache();
		
		try {
			dataSourceCache.init();
		} catch (MXException mxException) {
			//Essa excecao é esperada: loga e segue em frente
			log(LOG_ID, "============== MXException em BirtTestCase.before() =============");
			log(LOG_ID, "Exception=["+mxException.toString()+"]");
			log(LOG_ID, "Msg=["+mxException.getMessage()+"], Cause=["+mxException.getCause()+"]");
			log(LOG_ID, "=================================================================");
		} catch (Exception e) {
			//Excecao inesperada: deve interromper a execucao e abortar
			throw e;
		}
		
		/////////////////////////////
		// TESTE
		/////////////////////////////
		
//		MXServer mxServer = MXServer.getMXServer();
//		DataSourceCache fromCache = (DataSourceCache) mxServer.getFromMaximoCache( Constantes.MAXIMOCACHE_REPORTDATASOURCE );
//		
//		log(LOG_ID, "fromCache="+fromCache.toString());
//		
//		log(LOG_ID, "dataSourceCache="+dataSourceCache.toString());
//		
//		Set<String> cacheNames = mxServer.getMaximoCacheNames();
//		for (String name : cacheNames) {
//			log(LOG_ID, "cacheName=["+name+"]");
//		}
		
		//////////////////////////////

		//Espera o pool se inicializar (ou seja, a thread REPORTCONPOOLMGR rodar pela primeira vez)
		try {
			Thread.sleep(90*1000);
		} catch (InterruptedException e) {
			log(LOG_ID, "Erro", e);
			throw e;
		}
		
		log(LOG_ID, "Pool do BIRT inicializado.");

		//Aqui ja poderia pegar o pool configurado na Administração de Relatórios (informar o nome configurado na tela "Configurar Fontes de Dados")
//		this.pool = dataSourceCache.getDataSourceConnectionPool("maximoDataSource");
//		this.ds = new DataSourceImpl(pool);

		ConnectionPoolLogger connectionPoolLogger = new ConnectionPoolLogger();
		connectionPoolLogger.logConnectionsBirtUsedFree();
		
		//Em Producao, essa thread nao existira!!
//		ConnectionPoolLoggerThread loggerThread = new ConnectionPoolLoggerThread();
//		loggerThread.start();
		
		//Em Producao, essa thread sera na verdade uma crontask
		new RefreshPoolThread().start();
	}

	@Override
	protected void after() {
		super.after();
		log(LOG_ID, "Destruindo pool do BIRT...");
		
		DataSourceConnectionPool pool;
		try {
			pool = DataSourceUtil.getConnectionPool();
			if (pool != null) {
				pool.destroy();
			}
			
			log(LOG_ID, "Pool do BIRT destruido.");
		} catch (RemoteException e) {
			log(LOG_ID, "Erro", e);
		}
	}

//	@Override
//	public void onDataSourceCacheChange() {
//		//TODO
//		MXServer mxServer = null;
//		try {
//			mxServer = MXServer.getMXServer();
//		} catch (RemoteException e) {
//			log(LOG_ID, "Erro", e);
//			return;
//		}
//		DataSourceCache fromCache = (DataSourceCache) mxServer.getFromMaximoCache( Constantes.MAXIMOCACHE_REPORTDATASOURCE );
//		this.pool = fromCache.getDataSourceConnectionPool("maximoDataSource"); 
//		//loggerThread.setPool(this.pool);
//		//loggerThread.logConnections(); // nesse momento provavelmente nao havera nenhuma conexao criada ainda
//	}
}
