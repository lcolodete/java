package petrobras.ticeng.fic.testepool.testes;

import petrobras.ticeng.fic.testepool.testes.maximo.TestMaximo1;

public class TestRunner {

	public static void main(String[] args) {
		TestCase test = new TestMaximo1();
//		TestCase test = new TestBirt1();
//		TestCase test = new TestBirt2();
//		TestCase test = new TestBirt3();
//		TestCase test = new TestBirt4();
		
		Thread t = new Thread(test);
		t.start();
	}
}
