package petrobras.ticeng.fic.testepool.testes.birt;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnection;

/**
 * Pega uma conexao, usa e devolve ao pool.
 * <br>
 * Repete essa operacao 7 vezes. A cada execucao, espera mais tempo antes de usar a conexao :
 * <br>
 * <ul>
 * <li>30 minutos</li>
 * <li>40 minutos</li>
 * <li>50 minutos</li>
 * <li>60 minutos</li>
 * <li>70 minutos</li>
 * <li>80 minutos</li>
 * <li>90 minutos</li>
 * </ul>
 * 
 * @author ur5g
 *
 */
public class TestBirt2 extends BirtTestCase {

	private final String LOG_ID = TestBirt2.class.getSimpleName();
	
	@Override
	protected void runTest() throws Exception {
		log(LOG_ID, "runTest()");
		
		int[] rodadas = {30, 40, 50, 60, 70, 80, 90};
//		int[] rodadas = {1, 2, 3};
		
		for (int i=0; i<rodadas.length; i++) {
			
			log(LOG_ID, "***************** Rodada "+ i +" ("+ rodadas[i] +" min) - INICIO *****************");
			
			//pega a conexao

			log(LOG_ID, "Obtendo conexao...");
			
			long begin = System.currentTimeMillis();
			DataSourceConnection con1 = getDS().getNewConnection();
			long end = System.currentTimeMillis();
			double getNewConnectionTime = (end-begin)/1000.0;
			log(LOG_ID, "Conexao obtida em "+getNewConnectionTime+"s");
			
			log(LOG_ID, "Dados da Conexao: ["+con1.getConnection().toString()+"], SPID=["+this.oracleConnectionUtil.getSPID(con1.getConnection())+"]");
			
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			String now = df.format(new Date());
			log(LOG_ID, "Entrando em sleep : "+now);
			
			begin = System.currentTimeMillis();
			try {
				Thread.sleep(rodadas[i]*60*1000);
//				Thread.sleep(rodadas[i]*1000);
			} catch (InterruptedException e) {
				log(LOG_ID, "Erro", e);
				throw e;
			}
			end = System.currentTimeMillis();
			double sleepTime = (end-begin)/1000.0;
			
			now = df.format(new Date());
			log(LOG_ID, "Fim sleep : "+now);
			
			log(LOG_ID, "Tempo em sleep : "+sleepTime+"s");

			//usa e devolve
			
			PreparedStatement stmt = null;
			ResultSet rs = null;

			try {
				log(LOG_ID, "Executando query...");
				
				stmt = con1.getConnection().prepareStatement("select workorder.workorderid, workorder.wonum, workorder.description, workorder.woclass, workorder.status,        workorder.assetnum, workorder.worktype, workorder.wopriority, workorder.lead,        workorder.location,  workorder.jpnum, workorder.parent, workorder.siteid,        workorder.schedstart, workorder.schedfinish, workorder.siteid from (((workorder left outer join wochange on workorder.siteid = wochange.siteid                                           and workorder.orgid = wochange.orgid                                           and workorder.wonum = wochange.wonum)                   left outer join worelease on workorder.siteid = worelease.siteid                                            and workorder.orgid = worelease.orgid                                            and workorder.wonum = worelease.wonum)                   left outer join woactivity on workorder.siteid = woactivity.siteid                                             and workorder.orgid = woactivity.orgid                                             and workorder.wonum = woactivity.wonum) where ( ( ( ( workorder.woclass  =  'OS'  or workorder.woclass  =  'ATIVIDADE'  ) and workorder.historyflag  =  0 and workorder.istask  =  0 and workorder.siteid  =  'IERENEST-IEHDT-JEY-001'  ) and workorder.worktype  =  'FVI'  ) and ( ( workorder.wonum  =  '454314'  ) ))  and workorder.istask = 0 order by workorder.siteid, workorder.wonum");
				
				begin = System.currentTimeMillis();
				rs = stmt.executeQuery();
				end = System.currentTimeMillis();
				double queryTime = (end-begin)/1000.0;
				
				log(LOG_ID, "Query executada em "+queryTime+"s");
				
				while (rs.next()) {
					log(LOG_ID, rs.getObject("workorderid").toString() + " - " + rs.getObject("wonum").toString() + " - " + rs.getObject("description").toString());
				}
				
			} catch (SQLException e) {
				log(LOG_ID, "Erro", e);
			} finally {
				if (rs != null)
					try {
						rs.close();
					} catch (SQLException e) {
						log(LOG_ID, "Erro", e);
					}
				
				if (stmt != null)
					try {
						stmt.close();
					} catch (SQLException e) {
						log(LOG_ID, "Erro", e);
					}
				
				log(LOG_ID, "Devolvendo conexao ao pool...");
				getDS().freeConnection(con1);
				log(LOG_ID, "Conexao devolvida.");
			}

			log(LOG_ID, "***************** Rodada "+ i +" ("+ rodadas[i] +" min) - FIM *****************");
			
		} // FIM DO FOR
		
	}
}
