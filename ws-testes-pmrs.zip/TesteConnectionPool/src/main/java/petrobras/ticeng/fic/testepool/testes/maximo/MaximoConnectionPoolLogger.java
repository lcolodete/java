package petrobras.ticeng.fic.testepool.testes.maximo;

import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import psdi.security.ConnectionKey;
import psdi.server.ConRef;
import psdi.server.DBManager;
import psdi.server.MXServer;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class MaximoConnectionPoolLogger {

	private final String LOG_ID = MaximoConnectionPoolLogger.class.getSimpleName();
	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	private static final Locale LOCALE_PT_BR = new Locale("pt", "BR");
	
//	private static final String TABLE_GV$SESSION = "v$session"; 
	private static final String TABLE_GV$SESSION = "gv$session"; 

	public void logTable_GV$SESSION() {
		try {
			DBManager dbManager = MXServer.getMXServer().getDBManager();
			
			//pega uma conexao do DBManager
			
			ConnectionKey connectionKey = dbManager.getSystemConnectionKey();
			
			log(LOG_ID, "connectionKey=["+connectionKey+"]");

			ConRef con = (ConRef) dbManager.getConnection(connectionKey);
			
			log(LOG_ID, "conRef=["+con+"], SPID=["+con.getSPID()+"]");

			//executa select na tabela gv$session
			//imprime os registros encontrados no log, com lastcallet/60 (tempo em minutos)
			
			PreparedStatement stmt = null;
			ResultSet rs = null;

			try {
				
				stmt = con.prepareStatement("select SID, logon_time, last_call_et/60, status from "+TABLE_GV$SESSION + " order by SID asc");
				rs = stmt.executeQuery();
				
				int i = 0;
				while (rs.next()) {
					i++;
					if (i == 1) {
						log(LOG_ID, "SID - logon_time - last_call_et (minutos) - status");
					}
					log(LOG_ID, 	rs.getObject(1).toString() + " - " + 
									rs.getObject(2).toString() + " - " + 
									this.formatNumber( rs.getDouble(3) ) + " - " +
									rs.getObject(4).toString()
							);
				}
				
			} catch (SQLException e) {
				log(LOG_ID, "Erro", e);
			} finally {
				if (rs != null)
					try {
						rs.close();
					} catch (SQLException e) {
						log(LOG_ID, "Erro", e);
					}
				
				if (stmt != null)
					try {
						stmt.close();
					} catch (SQLException e) {
						log(LOG_ID, "Erro", e);
					}
				
				//devolve a conexao ao pool
				log(LOG_ID, "Devolvendo ao pool...");
				dbManager.freeConnection(connectionKey);
				log(LOG_ID, "Conexao devolvida.");
			}

		} catch (RemoteException e) {
			log(LOG_ID, "Erro", e);
		}
	}
	
	private String formatNumber(double d) {
		String str = null;

		NumberFormat nf = NumberFormat.getNumberInstance(LOCALE_PT_BR);
		nf.setMinimumFractionDigits(2);
		nf.setMaximumFractionDigits(2);
		
		str = nf.format(d);
		return str;

	}
	
	private String formatDate(Date d) {
		String str = null;
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, LOCALE_PT_BR);
		str = df.format(d);
		return str;
		
	}

	protected void log(String id, String msg) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		LOGGER.info( String.format("%s - %s", id, msg) );
	}

	protected void log(String id, String msg, Throwable t) {
		//System.out.println( String.format(">>>>> %s -> %s", id, msg) );
		//t.printStackTrace();
		LOGGER.error( String.format("%s - %s", id, msg), t );
	}

}
