package psdi.security;

import java.rmi.RemoteException;

import psdi.server.MXServer;

public class MySecurityService extends SecurityService {

	public MySecurityService(MXServer mxServer) throws RemoteException {
		super(mxServer);
		setName("SECURITY");
		setURL("rmi://kaliningrado.petrobras.com.br:13400/MXServer");
	}

}
