package psdi.server;

import java.rmi.RemoteException;

public class MyBulletinBoardService extends BulletinBoardService {

	public MyBulletinBoardService(MXServer mxServer) throws RemoteException {
		super(mxServer);
		setName("BULLETINBOARD");
		setURL("rmi://kaliningrado.petrobras.com.br:13400/MXServer");
	}

}
