package psdi.server;

public class MXServerInfoWrapper {


	private MXServerInfo mxServerInfo;

	protected MXServerInfo getMxServerInfo() {
		return mxServerInfo;
	}

	protected void setMxServerInfo(MXServerInfo mxServerInfo) {
		this.mxServerInfo = mxServerInfo;
	}

	public MXServerInfoWrapper(MXServerInfo mxServerInfo) {
		this.mxServerInfo = mxServerInfo;
	}
	

	public void setRunning(boolean running) {
		getMxServerInfo().setRunning(running);
	}
	
}
