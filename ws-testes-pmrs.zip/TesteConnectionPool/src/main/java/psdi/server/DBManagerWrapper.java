package psdi.server;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.HashMap;
import java.util.Vector;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import psdi.security.ConnectionKey;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class DBManagerWrapper {

	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	private DBManager manager;
	
	public DBManagerWrapper(DBManager manager) {
		this.manager = manager;
	}
	
	public DBManager getManager() {
		return manager;
	}

	public void logFreeOriginal() {
		if (this.manager.free != null) {
//			System.out.println(DBManagerWrapper.LOG + "free=["+this.manager.free+"]");
			LOGGER.info("free=["+this.manager.free+"]");
		} else {
//			System.out.println(DBManagerWrapper.LOG + "free=[null]");
			LOGGER.info("free=[null]");
		}
	}
	
	public void logFree() throws Exception {
		if (this.manager != null) {
			synchronized(this.manager) {
				logFree2(this.manager, "free");
			}
		}
	}
	
	/**
	 * Acessa o objeto DataSourceConnectionPool por reflection e
	 * obtem o valor do campo/atributo indicado por fieldName. 
	 *  
	 * @param fieldName nome do campo/atributo
	 * @return valor do campo/atributo, como um Object
	 * @throws Exception
	 */
	private Object getValueAsObj(Object obj, String fieldName) throws Exception {
		Class<?> clazz = obj.getClass();

		Field f = clazz.getDeclaredField(fieldName);
		f.setAccessible(true);
		Object fieldValue = f.get(obj);
		return fieldValue;
	}

	@SuppressWarnings("rawtypes")
	private void logFree2(Object obj, String arrayName) throws Exception {
		Vector arrayObj = (Vector) getValueAsObj(obj, arrayName);
		
		if (arrayObj != null) {
			int size = arrayObj.size();
			
//			System.out.println(arrayName+" = " +size);
			LOGGER.info(arrayName+" = " +size);
			
			if (size > 0) {
				
				int i = 1;
				for (Object c : arrayObj) {
					
					if (c instanceof ConRef) {
						
						ConRef conRef = (ConRef) c;
						
						String sessionId = conRef.getSPID();
						
//						System.out.println(i+") ["+conRef.toString()+"], SPID=["+sessionId+"]");
						LOGGER.info(i+") ["+conRef.toString()+"], SPID=["+sessionId+"]");
					}
					
					
					i++;
				}
			}
			
		} else {
//			System.out.println(arrayName+" == null");
			LOGGER.info(arrayName+" == null");
		}
	}
	
	public void logUsedOriginal() {
		if (this.manager.used != null) {
//			System.out.println(DBManagerWrapper.LOG + "used=["+this.manager.used+"]");
			LOGGER.info("used=["+this.manager.used+"]");
		} else {
//			System.out.println(DBManagerWrapper.LOG + "used=[null]");
			LOGGER.info("used=[null]");
		}
	}
	
	@SuppressWarnings("unchecked")
	private void logUsed2(Object obj, String arrayName) throws Exception {
		HashMap<ConnectionKey, ConRef> usedMap = (HashMap<ConnectionKey, ConRef>) getValueAsObj(obj, arrayName);
		
		if (usedMap != null) {
			
			Collection<ConRef> connections = usedMap.values();

			int size = connections.size();
			
//			System.out.println(arrayName+" = " +size);
			LOGGER.info(arrayName+" = " +size);
			
			if (size > 0) {
				
				int i = 1;
				for (ConRef conRef : connections) {
					String sessionId = conRef.getSPID();
//					System.out.println(i+") ["+conRef.toString()+"], SPID=["+sessionId+"]");
					LOGGER.info(i+") ["+conRef.toString()+"], SPID=["+sessionId+"]");
					i++;
				}
			}
			
		} else {
//			System.out.println(arrayName+" == null");
			LOGGER.info(arrayName+" == null");
		}
	}
	
	public void logUsed() throws Exception {
		if (this.manager != null) {
			synchronized(this.manager) {
				logUsed2(this.manager, "used");
			}
		}
	}
}
