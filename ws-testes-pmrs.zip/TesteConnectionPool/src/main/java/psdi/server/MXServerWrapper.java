package psdi.server;

import java.rmi.RemoteException;
import java.util.Properties;

import petrobras.ticeng.fic.testepool.testes.Constantes;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class MXServerWrapper {

	private static final String LOG_ID = MXServerWrapper.class.getSimpleName();
	private static MXLogger LOGGER = MXLoggerFactory.getLogger(Constantes.LOGGER_NAME);
	
	private MXServer srv;

	protected MXServer getSrv() {
		return srv;
	}

	public MXServerWrapper(MXServer srv) {
		this.srv = srv;
	}


	public void boot(Properties props) throws Exception {
		this.srv.boot(props);
	}
	
	public void bind(ServiceRemote svcRmt) throws RemoteException, MXException {
		this.srv.serviceCoordinator.bind(svcRmt);
	}

	public String[] getLocalAppList() {
		return this.srv.serviceCoordinator.getLocalAppList();
	}
	
	public void logMXServerProperties() {
//		this.logProperties(this.srv.mxServerConfig);
		log(LOG_ID, "MXServer.getConfig() - INICIO");
		this.logProperties(this.srv.getConfig());
		log(LOG_ID, "MXServer.getConfig() - FIM");
		
//		log(LOG_ID, "MXServer.getSystemProperties() - INICIO");
//		this.logProperties(this.srv.getSystemProperties());
//		log(LOG_ID, "MXServer.getSystemProperties() - FIM");
//		
//		log(LOG_ID, "MXServer.getMaximoCacheNames() - INICIO");
//		Set<String> cacheNames = this.srv.getMaximoCacheNames();
//		if ( cacheNames != null && !cacheNames.isEmpty() ) {
//			for (String name : cacheNames) {
//				log(LOG_ID, name);//MAXPROP
//			}
//		} else {
//			log(LOG_ID, "MXServer.getMaximoCacheNames() null ou vazio");
//		}
//		log(LOG_ID, "MXServer.getMaximoCacheNames() - FIM");
	}
	
	private void logProperties(Properties props) {
		
		if (props != null) {
			
			if (props.keySet() != null && !props.keySet().isEmpty()) {
				
				for (Object key : props.keySet()) {
					
					log(LOG_ID, key+"=["+props.getProperty((String)key)+"]" );
				}
				
			} else {
				log(LOG_ID, "keySet nulo ou vazio");
			}
			
		} else {
			log(LOG_ID, "mxServerConfig == null");
			
		}
		
	}
	
	public void log(String id, String msg) {
		LOGGER.info( String.format("%s - %s", id, msg) );
	}

	public static void main(String[] args) {
		Properties props = new Properties();
		props.setProperty("p1", "valor de p1");
		props.setProperty("p2", "valor de p2");
		

		MXServerWrapper m = new MXServerWrapper(null);
		m.logProperties(props);
	}

	public void setProperty(String propertyName, String value) {
//		this.srv.mxServerConfig.setProperty(propertyName, value);
		this.srv.getConfig().setProperty(propertyName, value);
	}
}
