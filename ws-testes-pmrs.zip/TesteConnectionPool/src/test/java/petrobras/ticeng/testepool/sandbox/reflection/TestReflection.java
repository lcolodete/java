package petrobras.ticeng.testepool.sandbox.reflection;

import java.lang.reflect.Field;
import java.util.ArrayList;

import petrobras.ticeng.fic.testepool.testes.birt.ConnectionPoolLoggerThread;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnection;

public class TestReflection {

	public static void main(String[] args) {
		DataSourceConnectionPool ds = new DataSourceConnectionPool();

		ds.setDestroyed(true);
		
		ArrayList<DataSourceConnection> free = new ArrayList<DataSourceConnection>();
//		free.add(new MockDataSourceConnection(100));
//		free.add(new MockDataSourceConnection(200));
//		free.add(new MockDataSourceConnection(300));
		ds.setFree(free);
		
		
		ArrayList<DataSourceConnection> used = new ArrayList<DataSourceConnection>();
//		used.add(new MockDataSourceConnection(400));
//		used.add(new MockDataSourceConnection(500));
		ds.setUsed(used);

		ConnectionPoolLoggerThread logger = new ConnectionPoolLoggerThread();
		//TODO descomentar antes de rodar um novo teste unitário
//		logger.setPool(ds);
		
		logger.run();
	}
	
	public static void main2(String[] args) throws IllegalArgumentException, IllegalAccessException {
		
		DataSourceConnectionPool ds = new DataSourceConnectionPool();

		ds.setDestroyed(true);
		
		ArrayList<DataSourceConnection> free = new ArrayList<DataSourceConnection>();
		free.add(new MockDataSourceConnection(100));
		free.add(new MockDataSourceConnection(200));
		free.add(new MockDataSourceConnection(300));
		ds.setFree(free);
		
		
		ArrayList<DataSourceConnection> used = new ArrayList<DataSourceConnection>();
		used.add(new MockDataSourceConnection(400));
		used.add(new MockDataSourceConnection(500));
		ds.setUsed(used);
		
		
		Class<?> clazz = ds.getClass();
		Field[] fields = clazz.getDeclaredFields();
		
		for (Field f : fields) {
			System.out.println(f);
			
			if (f.getName().equals("destroyed")) {
				System.out.println("achei o atributo 'destroyed'");
				System.out.println("isAccessible? "+f.isAccessible());
				
				f.setAccessible(true);
				
				System.out.println("isAccessible? "+f.isAccessible());
				
				System.out.println( "destroyed=["+f.getBoolean(ds)+"]" );
			} else if (f.getName().equals("free")) {
				System.out.println("achei o atributo 'free'");
				System.out.println("isAccessible? "+f.isAccessible());
				
				f.setAccessible(true);
				
				System.out.println("isAccessible? "+f.isAccessible());
				
				//System.out.println( "free=["+f.get(ds)+"]" );
				
				ArrayList<Integer> freeObj = (ArrayList<Integer>) f.get(ds);
				
				System.out.println( "freeObj=["+freeObj+"]" );
			} else if (f.getName().equals("used")) {
				System.out.println("achei o atributo 'used'");
				System.out.println("isAccessible? "+f.isAccessible());
				
				f.setAccessible(true);
				
				System.out.println("isAccessible? "+f.isAccessible());
				
				ArrayList<Integer> usedObj = (ArrayList<Integer>) f.get(ds);
				
				System.out.println( "usedObj=["+usedObj+"]" );
			}
			
		}
		
	}
}
