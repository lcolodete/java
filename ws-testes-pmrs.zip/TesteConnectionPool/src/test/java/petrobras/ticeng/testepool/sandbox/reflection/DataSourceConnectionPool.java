package petrobras.ticeng.testepool.sandbox.reflection;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnection;

public class DataSourceConnectionPool {

	private com.ibm.tivoli.maximo.report.birt.datasource.DataSourceInfo dataSourceInfo;

	private java.util.ArrayList<DataSourceConnection> used;

	private java.util.ArrayList<DataSourceConnection> free;

	private boolean destroyed;

	protected void setDestroyed(boolean destroyed) {
		this.destroyed = destroyed;
	}

	protected void setUsed(java.util.ArrayList<DataSourceConnection> used) {
		this.used = used;
	}

	protected void setFree(java.util.ArrayList<DataSourceConnection> free) {
		this.free = free;
	}


}
