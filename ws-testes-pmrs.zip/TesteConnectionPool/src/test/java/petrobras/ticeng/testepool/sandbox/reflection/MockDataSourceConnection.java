package petrobras.ticeng.testepool.sandbox.reflection;

import java.sql.Connection;

import com.ibm.tivoli.maximo.report.birt.datasource.DataSourceConnection;

public class MockDataSourceConnection implements DataSourceConnection {

	private Integer id;
	
	public MockDataSourceConnection(Integer id) {
		this.id = id;
	}
	
	@Override
	public Connection getConnection() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toString() {
		return this.id.toString();
	}
}
