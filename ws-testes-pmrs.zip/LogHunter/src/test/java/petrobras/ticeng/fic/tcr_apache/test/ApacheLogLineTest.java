package petrobras.ticeng.fic.tcr_apache.test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.junit.BeforeClass;
import org.junit.Test;

import petrobras.ticeng.fic.tcr_apache.ApacheLogLine;

public class ApacheLogLineTest {

	private static ApacheLogLine logLine;
	
	@BeforeClass
	public static void beforeClass() {
		final String TEST_LOGLINE = "186.208.122.222 - - [09/Nov/2015:07:34:57 -0200] \"POST /tarf/servlet/dispatch HTTP/1.1\" 200 8060 \"http://fic.petrobras.com.br/tarf/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27FIC%27%5d%2fpackage%5b%40name%3d%27FIC_REP_CADBASPackage%27%5d%2freport%5b%40name%3d%27FIC_Cadastro_Geral%27%5d&run.outputFormat=&run.prompt=false&run.outputLocale=pt-br\" \"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Win64; x64; Trident/4.0; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)\" \"cam_passport=101:6b8eb7db-659d-dd36-2566-c0c4dce7a7b7:18446744072766115285; cea-ssa=false; usersessionid=AQgAAAA9o0lWAAAAAAoAAAB6Vm2U3urBholjFAAAAMBNZe4rC8qnvjN783t9hFbcIlT8FAAAAN3SL7EcyyXqgCcto3dGE+yULs+V; CRN=useAccessibilityFeatures%3Dfalse%26showOptionSummary%3Dtrue%26showWelcomePage%3Dtrue%26contentLocale%3Dpt-br%26skin%3Dcorporate%26linesPerPage%3D15%26listViewSeparator%3Dnone%26displayMode%3Dlist%26timeZoneID%3DBET%26automaticPageRefresh%3D30%26columnsPerPage%3D3%26format%3DHTML%26showHiddenObjects%3Dfalse%26productLocale%3Dpt%26; userCapabilities=7c6d%3B6f%3Bff070ef8%26ARQAAADATWXuKwvKp74ze%2FN7fYRW3CJU%2FMRyTLq8WlFqwS%2FQTTBQQQUPHam%2B; viewer_session=uig:|e_hp:CAMID(*22maximo*3au*3a220.388.918-77*22)|e_user:220.388.918-77|show_logon:true|pp:18446744072766115285; JSESSIONID=qD7rl52XzmWP5V0yNmrgsKzFOmadX8rm28pNuwuc358ggE-Z81e9!-293147043\"";
//		final String TEST_LOGLINE = "201.32.173.166 - - [30/Sep/2015:09:55:42 -0300] \"GET /tarf/servlet/dispatch/gd/H4sIAAAAAAAAALMuLskvSvV00VDKtHC0dDQxdjO2tDAyMHE2NrEwcXI1c3N2MjezcHY2c3VS0gQAlqdiwi0AAAA_/ HTTP/1.1\" 206 65536 \"http://fic.petrobras.com.br/tarf/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27FIC%27%5d%2fpackage%5b%40name%3d%27FIC_REP_CCMPackage%27%5d%2freport%5b%40name%3d%27FIC_CCM_COMPLETO%27%5d&run.outputFormat=&run.prompt=false&run.outputLocale=pt-br\" \"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:26.0) Gecko/20100101 Firefox/26.0\" \"cam_passport=101:dd44ae7e-0071-f7c1-65fe-3da39c63e38d:18446744072598654176; cea-ssa=false; usersessionid=AQgAAABHFhVWAAAAAAoAAACv1G2zP3pzZIQeFAAAAMBNZe4rC8qnvjN783t9hFbcIlT8FAAAACvLJRh7MBij0L5MZaxJW+BT8mmW; CRN=listViewSeparator%3Dnone%26displayMode%3Dlist%26timeZoneID%3DBET%26automaticPageRefresh%3D30%26columnsPerPage%3D3%26format%3DHTML%26showHiddenObjects%3Dfalse%26productLocale%3Den%26useAccessibilityFeatures%3Dfalse%26showOptionSummary%3Dtrue%26showWelcomePage%3Dtrue%26contentLocale%3Den-us%26skin%3Dcorporate%26linesPerPage%3D15%26; userCapabilities=7c6d%3B6f%3Bff070ef8%26ARQAAADATWXuKwvKp74ze%2FN7fYRW3CJU%2FMRyTLq8WlFqwS%2FQTTBQQQUPHam%2B; viewer_session=uig:|e_hp:CAMID(*22maximo*3au*3a08223458705*22)|e_user:08223458705|show_logon:true|pp:18446744072598654176; JSESSIONID=TLod4TH_nMjg7FV9FZPHBuCBC0AXpWXA4J2UtIV47-13pbesU-ky!-503561908; TJE=; TE3=; cam_passport=101:dd44ae7e-0071-f7c1-65fe-3da39c63e38d:18446744072598654176; cea-ssa=false; usersessionid=AQgAAABHFhVWAAAAAAoAAACv1G2zP3pzZIQeFAAAAMBNZe4rC8qnvjN783t9hFbcIlT8FAAAACvLJRh7MBij0L5MZaxJW+BT8mmW; CRN=listViewSeparator%3Dnone%26displayMode%3Dlist%26timeZoneID%3DBET%26automaticPageRefresh%3D30%26columnsPerPage%3D3%26format%3DHTML%26showHiddenObjects%3Dfalse%26productLocale%3Den%26useAccessibilityFeatures%3Dfalse%26showOptionSummary%3Dtrue%26showWelcomePage%3Dtrue%26contentLocale%3Den-us%26skin%3Dcorporate%26linesPerPage%3D15%26; userCapabilities=7c6d%3B6f%3Bff070ef8%26ARQAAADATWXuKwvKp74ze%2FN7fYRW3CJU%2FMRyTLq8WlFqwS%2FQTTBQQQUPHam%2B; viewer_session=uig:|e_hp:CAMID(*22maximo*3au*3a08223458705*22)|e_user:08223458705|show_logon:true|pp:18446744072598654176; JSESSIONID=TLod4TH_nMjg7FV9FZPHBuCBC0AXpWXA4J2UtIV47-13pbesU-ky!-503561908; TJE=; TE3=\"";
		
		logLine = ApacheLogLine.parse(TEST_LOGLINE);
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// user
	//
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Test
	public void Parse_LogLine_UserReturned() {
		//Arrange
		//Act
		String user = logLine.getUser();
		
		//Assert
		assertThat(user, is("220.388.918-770"));
//		assertThat(user, is("08223458705"));
		
//		assertEquals("220.388.918-77", user);
	}

	@Test(expected=IllegalArgumentException.class)
	public void Parse_LogLineWithoutUserInfo_ExceptionThrown() {
		//Arrange
		String lineWithException = "186.208.113.130 - - [09/Nov/2015:07:28:28 -0200] \"POST /tarf/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27FIC%27%5d%2fpackage%5b%40name%3d%27FIC_REP_OPPackage%27%5d%2freport%5b%40name%3d%27FIC_Preserv%27%5d&run.outputFormat=&run.prompt=false&run.outputLocale=pt-br HTTP/1.1\" 200 22174 \"http://fic.petrobras.com.br/maximo/webclient/common/openreport.jsp\" \"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko\" \"JSESSIONID=tijrj0PNYTLIPzvFyhHalRI33kSsb18SAipvlpPMxyGryyyjSQ-e!1697212449\"";
		
		//Act
		ApacheLogLine.parse(lineWithException);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// JSESSIONID
	//
	////////////////////////////////////////////////////////////////////////////////////////////////////

	@Test
	public void Parse_LogLine_JSESSIONIDReturned() {
		//Arrange
		//Act
		String JSESSIONID = logLine.getJSESSIONID();
		
		//Assert
		assertThat(JSESSIONID, is("qD7rl52XzmWP5V0yNmrgsKzFOmadX8rm28pNuwuc358ggE-Z81e9!-293147043"));
//		assertThat(JSESSIONID, is("TLod4TH_nMjg7FV9FZPHBuCBC0AXpWXA4J2UtIV47-13pbesU-ky!-503561908"));
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// reportName
	//
	////////////////////////////////////////////////////////////////////////////////////////////////////

	@Test
	public void Parse_LogLine_ReportNameReturned() {
		//Arrange
		//Act
		String reportName = logLine.getReportName();
		
		//Assert
		assertThat(reportName, is("FIC_Cadastro_Geral"));
//		assertThat(reportName, is("FIC_CCM_COMPLETO"));
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// ipAddress
	//
	////////////////////////////////////////////////////////////////////////////////////////////////////

	@Test
	public void Parse_LogLine_IpAddressReturned() {
		//Arrange
		//Act
		String ipAddress = logLine.getIpAddress();
		
		//Assert
		assertThat(ipAddress, is("186.208.122.222"));
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// dateTime
	//
	////////////////////////////////////////////////////////////////////////////////////////////////////

	@Test
	public void Parse_LogLine_DateTimeReturned() {
		//Arrange
		//Act
		Date dateTime = logLine.getDateTime();
		
		Calendar c = Calendar.getInstance();
//		c.set(2015, Calendar.SEPTEMBER, 30, 9, 55, 42);
		c.set(2015, Calendar.NOVEMBER, 9, 7, 34, 57);
		c.set(Calendar.MILLISECOND, 0);
		
		//Assert
		assertThat(dateTime, is(c.getTime()));
		assertEquals(c.getTimeInMillis(), dateTime.getTime());
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// equals
	//
	////////////////////////////////////////////////////////////////////////////////////////////////////

	@Test
	public void Equals_TwoEquivalentLogLines_True() {
		ApacheLogLine line1 = new ApacheLogLine("ur5g", "xyz", "FIC_FVI_Consolidada", "1", null);
		ApacheLogLine line2 = new ApacheLogLine("ur5g", "xyz", "FIC_FVI_Consolidada", "2", new Date());
		assertThat(line1, is(equalTo(line2)));
		
		assertThat(line1.getUser(), is(equalTo(line2.getUser())));
		assertThat(line1.getJSESSIONID(), is(equalTo(line2.getJSESSIONID())));
		assertThat(line1.getReportName(), is(equalTo(line2.getReportName())));
	}
	
	@Test
	public void Equals_TwoDifferentLogLines_False() {
		ApacheLogLine line1 = new ApacheLogLine("ur5g", "abc", "FIC_FVI_Consolidada", "1", null);
		ApacheLogLine line2 = new ApacheLogLine("ur5g", "xyz", "FIC_FVI_Consolidada", "1", null);
		
		assertThat(line1, is(not(equalTo(line2))));
		
		assertThat(line1.getUser(), is(equalTo(line2.getUser())));
		assertThat(line1.getJSESSIONID(), is(not(equalTo(line2.getJSESSIONID()))));
		assertThat(line1.getReportName(), is(equalTo(line2.getReportName())));
	}
	
	@Test
	public void shouldAddOnlyFirstObjectToSet() {
		ApacheLogLine line1 = ApacheLogLine.parse("187.95.160.1 - - [28/Sep/2015:15:22:23 -0300] \"POST /tarf/servlet/dispatch HTTP/1.1\" 200 16814 \"http://fic.petrobras.com.br/tarf/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27FIC%27%5d%2fpackage%5b%40name%3d%27FIC_REP_OPPackage%27%5d%2freport%5b%40name%3d%27FIC_Preserv%27%5d&run.outputFormat=&run.prompt=false&run.outputLocale=pt-br\" \"Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0\" \"cam_passport=101:53fea920-cead-60cd-af01-365c725e97eb:18446744069837397573; cea-ssa=false; usersessionid=AQgAAACGpxJWAAAAAAoAAABTwGxT3h2IDdj9FAAAAMBNZe4rC8qnvjN783t9hFbcIlT8FAAAABe6P/n2i8QUsCr+lPiFZfVUWAao; CRN=listViewSeparator%3Dnone%26displayMode%3Dlist%26timeZoneID%3DBET%26automaticPageRefresh%3D30%26columnsPerPage%3D3%26format%3DHTML%26showHiddenObjects%3Dfalse%26productLocale%3Dpt%26useAccessibilityFeatures%3Dfalse%26showOptionSummary%3Dtrue%26showWelcomePage%3Dtrue%26contentLocale%3Dpt-br%26skin%3Dcorporate%26linesPerPage%3D15%26; userCapabilities=7c6d%3B6f%3Bff070ef8%26ARQAAADATWXuKwvKp74ze%2FN7fYRW3CJU%2FMRyTLq8WlFqwS%2FQTTBQQQUPHam%2B; viewer_session=uig:|e_hp:CAMID(*22maximo*3au*3a33748894848*22)|e_user:33748894848|show_logon:true|pp:18446744069837397573; JSESSIONID=HvQVKYzCBuZzqs5B5Y9ZL95Q4ICFQVkQb38Z9sVXhTQa6fkeF4nu!-1949392200; TJE=; TE3=\"");
		ApacheLogLine line2 = ApacheLogLine.parse("187.95.160.1 - - [28/Sep/2015:16:06:08 -0300] \"POST /tarf/servlet/dispatch HTTP/1.1\" 200 16752 \"http://fic.petrobras.com.br/tarf/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27FIC%27%5d%2fpackage%5b%40name%3d%27FIC_REP_OPPackage%27%5d%2freport%5b%40name%3d%27FIC_Preserv%27%5d&run.outputFormat=&run.prompt=false&run.outputLocale=pt-br\" \"Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0\" \"cam_passport=101:53fea920-cead-60cd-af01-365c725e97eb:18446744069837397573; cea-ssa=false; usersessionid=AQgAAACGpxJWAAAAAAoAAABTwGxT3h2IDdj9FAAAAMBNZe4rC8qnvjN783t9hFbcIlT8FAAAABe6P/n2i8QUsCr+lPiFZfVUWAao; CRN=listViewSeparator%3Dnone%26displayMode%3Dlist%26timeZoneID%3DBET%26automaticPageRefresh%3D30%26columnsPerPage%3D3%26format%3DHTML%26showHiddenObjects%3Dfalse%26productLocale%3Dpt%26useAccessibilityFeatures%3Dfalse%26showOptionSummary%3Dtrue%26showWelcomePage%3Dtrue%26contentLocale%3Dpt-br%26skin%3Dcorporate%26linesPerPage%3D15%26; userCapabilities=7c6d%3B6f%3Bff070ef8%26ARQAAADATWXuKwvKp74ze%2FN7fYRW3CJU%2FMRyTLq8WlFqwS%2FQTTBQQQUPHam%2B; viewer_session=uig:|e_hp:CAMID(*22maximo*3au*3a33748894848*22)|e_user:|show_logon:true|pp:18446744069837397573; JSESSIONID=HvQVKYzCBuZzqs5B5Y9ZL95Q4ICFQVkQb38Z9sVXhTQa6fkeF4nu!-1949392200; TJE=; TE3=\"");
		
		assertThat(line1, is(equalTo(line2)));
		
		Map<String, Set<ApacheLogLine>> userLogsMap = new TreeMap<String, Set<ApacheLogLine>>();
		
		//objeto line1
		String user = line1.getUser();
		
		Set<ApacheLogLine> lineSet = userLogsMap.get(user);
		
		if (lineSet == null) {
			lineSet = new HashSet<ApacheLogLine>();
			userLogsMap.put(user, lineSet);
		}
		lineSet.add(line1);
		
		assertThat(lineSet.size(), is(1));

		//objeto line2
		user = line2.getUser();
		lineSet = userLogsMap.get(user);
		
		assertThat(lineSet.add(line2), is(false));
		assertThat(lineSet.size(), is(1));
	}
	
	@Test
	public void shouldAddBothToSet() {
		ApacheLogLine line1 = ApacheLogLine.parse("187.95.160.1 - - [28/Sep/2015:13:38:39 -0300] \"POST /tarf/servlet/dispatch HTTP/1.1\" 200 16756 \"http://fic.petrobras.com.br/tarf/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27FIC%27%5d%2fpackage%5b%40name%3d%27FIC_REP_OPPackage%27%5d%2freport%5b%40name%3d%27FIC_Preserv%27%5d&run.outputFormat=&run.prompt=false&run.outputLocale=pt-br\" \"Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0\" \"cam_passport=101:53fea920-cead-60cd-af01-365c725e97eb:18446744069837397573; cea-ssa=false; usersessionid=AQgAAACGpxJWAAAAAAoAAABTwGxT3h2IDdj9FAAAAMBNZe4rC8qnvjN783t9hFbcIlT8FAAAABe6P/n2i8QUsCr+lPiFZfVUWAao; CRN=listViewSeparator%3Dnone%26displayMode%3Dlist%26timeZoneID%3DBET%26automaticPageRefresh%3D30%26columnsPerPage%3D3%26format%3DHTML%26showHiddenObjects%3Dfalse%26productLocale%3Dpt%26useAccessibilityFeatures%3Dfalse%26showOptionSummary%3Dtrue%26showWelcomePage%3Dtrue%26contentLocale%3Dpt-br%26skin%3Dcorporate%26linesPerPage%3D15%26; userCapabilities=7c6d%3B6f%3Bff070ef8%26ARQAAADATWXuKwvKp74ze%2FN7fYRW3CJU%2FMRyTLq8WlFqwS%2FQTTBQQQUPHam%2B; viewer_session=uig:|e_hp:CAMID(*22maximo*3au*3a33748894848*22)|e_user:33748894848|show_logon:true|pp:18446744069837397573; JSESSIONID=AEoUstKar_d4rFD8nLQeV1C-e9bQxxDeFZY0bey5zNa9qyBC7Lyf!-1949392200; TJE=; TE3=\"");
		ApacheLogLine line2 = ApacheLogLine.parse("187.95.160.1 - - [28/Sep/2015:15:22:23 -0300] \"POST /tarf/servlet/dispatch HTTP/1.1\" 200 16814 \"http://fic.petrobras.com.br/tarf/servlet/dispatch?b_action=cognosViewer&ui.action=run&ui.object=%2fcontent%2ffolder%5b%40name%3d%27FIC%27%5d%2fpackage%5b%40name%3d%27FIC_REP_OPPackage%27%5d%2freport%5b%40name%3d%27FIC_Preserv%27%5d&run.outputFormat=&run.prompt=false&run.outputLocale=pt-br\" \"Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0\" \"cam_passport=101:53fea920-cead-60cd-af01-365c725e97eb:18446744069837397573; cea-ssa=false; usersessionid=AQgAAACGpxJWAAAAAAoAAABTwGxT3h2IDdj9FAAAAMBNZe4rC8qnvjN783t9hFbcIlT8FAAAABe6P/n2i8QUsCr+lPiFZfVUWAao; CRN=listViewSeparator%3Dnone%26displayMode%3Dlist%26timeZoneID%3DBET%26automaticPageRefresh%3D30%26columnsPerPage%3D3%26format%3DHTML%26showHiddenObjects%3Dfalse%26productLocale%3Dpt%26useAccessibilityFeatures%3Dfalse%26showOptionSummary%3Dtrue%26showWelcomePage%3Dtrue%26contentLocale%3Dpt-br%26skin%3Dcorporate%26linesPerPage%3D15%26; userCapabilities=7c6d%3B6f%3Bff070ef8%26ARQAAADATWXuKwvKp74ze%2FN7fYRW3CJU%2FMRyTLq8WlFqwS%2FQTTBQQQUPHam%2B; viewer_session=uig:|e_hp:CAMID(*22maximo*3au*3a33748894848*22)|e_user:33748894848|show_logon:true|pp:18446744069837397573; JSESSIONID=HvQVKYzCBuZzqs5B5Y9ZL95Q4ICFQVkQb38Z9sVXhTQa6fkeF4nu!-1949392200; TJE=; TE3=\"");
		
		assertThat(line1, is(not(equalTo(line2))));

		Map<String, Set<ApacheLogLine>> userLogsMap = new TreeMap<String, Set<ApacheLogLine>>();
		
		//objeto line1
		String user = line1.getUser();
		
		Set<ApacheLogLine> lineSet = userLogsMap.get(user);
		
		if (lineSet == null) {
			lineSet = new HashSet<ApacheLogLine>();
			userLogsMap.put(user, lineSet);
		}
		lineSet.add(line1);
		
		assertThat(lineSet.size(), is(1));

		//objeto line2
		user = line2.getUser();
		lineSet = userLogsMap.get(user);
		
		assertThat(lineSet.add(line2), is(true));
		assertThat(lineSet.size(), is(2));
	}
}
