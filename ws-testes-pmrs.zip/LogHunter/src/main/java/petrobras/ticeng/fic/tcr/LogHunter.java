package petrobras.ticeng.fic.tcr;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lê os arquivos de log do Cognos e produz um relatório.<br/>
 * <br/>
 * Os arquivos tem a seguinte regra de formação:<br/>
 * - cogserver.log é o mais recente<br/>
 * - cogserver.log.1 até 60 (onde .60 é o mais antigo)<br/>
 * <br/>
 * A classe começa a ler do 60 em diante, até chegar ao cogserver.log.
 * 
 * 
 * @author ur5g
 */
public class LogHunter {

	private static final Boolean _SYSOUT = false;  
	
//	private static final String DIR = "C:/Users/ur5g/FIC/Logs/2015-07-27/";
//	private static final String DIR = "C:/Users/ur5g/FIC/Logs/2016-06-06/";
	private static final String DIR = "C:/Users/ur5g/FIC/Logs/2016-12-26/";
	private static final String LOG_FILE = "cogserver.log";
	
	private static final String SEARCH_STRING_EXECUTE = ".*Execute	Report (BatchReportService|ReportService)	/content/folder\\[@name='FIC'\\]/package\\[@name='.*?'\\]/report\\[@name='.*?'\\]			<parameters>.*";
	private static final String SEARCH_STRING_SUCCESS = ".*Execute	Report (BatchReportService|ReportService)	/content/folder\\[@name='FIC'\\]/package\\[@name='.*?'\\]/report\\[@name='.*?'\\]	Success		<parameters>.*";
	private static final String SEARCH_STRING_FAILURE = ".*Execute	Report (BatchReportService|ReportService)	/content/folder\\[@name='FIC'\\]/package\\[@name='.*?'\\]/report\\[@name='.*?'\\]	Failure.* 	<parameters>.*";
	
	private static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/out/";
	private static final String OUTPUT_FILE_EXECUTE = "output_execute_";
	private static final String OUTPUT_FILE_SUCCESS = "output_success_";
	private static final String OUTPUT_FILE_FAILURE = "output_failure_";
	private static final String OUTPUT_FILE_TOTAIS_POR_DIA = "output_totaisPorDia_";
	
	
	public static void main2(String[] args) {
		
		boolean matches = false;
		
		String line = "10.29.170.61:16310	13185	2015-05-20 07:53:07.846	-3	5FC5FFAEABFD21790B3F35CD3648941785A796F3	CClCCqhCvCqs2GlvqMGhs492d4yjs49sq8GdG4ys	CClCCqhCvCqs2GlvqMGhs492d4yjs49sq8GdG4ys		1593412496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report ReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_CADBASPackage']/report[@name='FIC_Cadastro_Geral']			<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_CADBASPackage']/model[@name='2011-08-15T20:19:55.524Z']]]></item><item name=\"storeID\"><![CDATA[i8BA784FCDE5949159ABBB23C75194DD4]]></item></parameters>";
		
		String lineBatch = "10.29.170.61:16310	32244	2015-05-20 16:27:46.915	-3	A2A0CF1AF12F326A84B423E81057D18C984DC87E	8wM4s4jjvCwj8yCqdlddGhlw92G4hl8M2qjlhyC8	8wM4s4jjvCwj8yCqdlddGhlw92G4hl8M2qjlhyC8		1572932496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report BatchReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_FVIPackage']/report[@name='FIC_FVI_Consolidada']			<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_FVIPackage']/model[@name='2011-09-05T14:47:54.857Z']]]></item><item name=\"storeID\"><![CDATA[i8D60B47BCE944ADBAE9409F65D45D5AD]]></item></parameters>";
		
		String lineSuccess = "10.29.170.61:16310	3546	2015-05-20 07:53:22.842	-3	DEC22C9AB29EB59A2F9BEC7D89773B83EB664EE6	y4ddqdll2Gsjvqjj92qvy4C98w98C48dyw8Clhdy	y4ddqdll2Gsjvqjj92qvy4C98w98C48dyw8Clhdy		1597508496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report BatchReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_CADBASPackage']/report[@name='FIC_Hierarquia_de_Malhas']	Success		<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_CADBASPackage']/model[@name='2011-08-15T20:19:55.524Z']]]></item><item name=\"storeID\"><![CDATA[i6A93DD61EF5C4EADAEA0885BC7E24721]]></item></parameters>";
		
		String lineFailure1 = "10.29.170.61:16310	26439	2015-05-20 15:07:21.182	-3	C4BC46835FB70EE6097B95D99A2FC7694073B7D4	MM4Cjq9jMM2vlq2y8q2s2MlCG8qwqMqM4C8vdh8s	MM4Cjq9jMM2vlq2y8q2s2MlCG8qwqMqM4C8vdh8s		1605700496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report ReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_FVIPackage']/report[@name='FIC_FVI_Consolidada']	Failure	RSV-SRV-0066 A soap fault has been returned. 	<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_FVIPackage']/model[@name='2011-09-05T14:47:54.857Z']]]></item><item name=\"storeID\"><![CDATA[i8D60B47BCE944ADBAE9409F65D45D5AD]]></item></parameters>";
		
		String lineFailure2 = "10.29.170.61:16310	31628	2015-05-20 10:03:00.231	-3	94B864AAA41B4178CEF89F452020227A6F968FA3	8ywhqqshj9vhM8dCq9jMqdy8CGC4ys8svGwsM4hd	8ywhqqshj9vhM8dCq9jMqdy8CGC4ys8svGwsM4hd		1601604496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report ReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_OPPackage']/report[@name='FIC_Etiquetas']	Failure	RSV-SRV-0066 A soap fault has been returned. QE-DEF-0315 An error occurred while calling the content store for parameter map information. CCL-RCI-0004 Content Manager returned an authentication fault. CAM-AAA-0102 Unable to authenticate. The user must select a namespace. The error messages from WASP engine:  CM-REQ-4159 Content Manager returned an error in the response header. RQP-DEF-0149 The query specification is incorrect. RQP-DEF-0457 Referenced Query 'Q_Informacao_Pessoal' is not defined or its query items contain unresolved references. 	<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_OPPackage']/model[@name='2011-08-15T20:30:47.514Z']]]></item><item name=\"storeID\"><![CDATA[i53AD984B75614887827D7CFFB90695A8]]></item></parameters>";
		
		if (lineFailure2.matches(SEARCH_STRING_FAILURE)) {
			matches = true;
		}
		
		System.out.println(matches);
		
		
		String lineToParse = "10.29.170.61:16310	30069	2015-05-19 14:11:13.201	-3	1F3EFCA3A9E3ED082122EFCBC523B7E110402AF2	hMqvdlqMyhs2jh2hMj92C4qMw9sC4yjqvdl29Mqj	hMqvdlqMyhs2jh2hMj92C4qMw9sC4yjqvdl29Mqj		1589316496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report ReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_FVMPackage']/report[@name='FIC_FVM']			<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_FVMPackage']/model[@name='2011-09-05T14:57:06.232Z']]]></item><item name=\"storeID\"><![CDATA[i77F4495C57DD4A0A9D6E3C43500A399C]]></item></parameters>";
		
		Pattern p = Pattern.compile("\\d\\d\\d\\d-\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d.\\d\\d\\d");
		Matcher m = p.matcher(lineToParse);
		
		if (m.find()) {
			System.out.println(m.start());
			System.out.println(lineToParse.substring(25, 48));
			System.out.println(lineToParse.substring(m.start(), m.end()));
			System.out.println(m.group());
		}

		Pattern p2 = Pattern.compile("[A-F0-9]{40}");
		Matcher m2 = p2.matcher(lineToParse);
		
		if (m2.find()) {
			System.out.println(m2.group());
		}

		Pattern p3 = Pattern.compile("report\\[@name='.*?'\\]");
		Matcher m3 = p3.matcher(lineToParse);
		
		if (m3.find()) {
			String reportFound = m3.group();
			System.out.println(reportFound);
			
			String[] reportParts = reportFound.split("=");
			String reportName = reportParts[1].replaceAll("'", "").replace("]", "");
			System.out.println(reportName);
		}

		HashMap<String, HashMap<String,Integer>> hitsPerHourPerDay = new HashMap<String, HashMap<String,Integer>>();
		
		HashMap<String, Integer> hitsPerHour = new HashMap<String, Integer>();
		hitsPerHour.put("00", 10);
		hitsPerHour.put("09", 234);
		
		hitsPerHourPerDay.put("10/05", hitsPerHour);
		
		HashMap<String, Integer> execucoesPorHora = hitsPerHourPerDay.get("10/05");
		String hour = "09";
		Integer qtdExecuoesHora = execucoesPorHora.get(hour);
		if (qtdExecuoesHora == null || qtdExecuoesHora == 0) {
			qtdExecuoesHora = 1;
		} else {
			qtdExecuoesHora++;
		}
		execucoesPorHora.put(hour, qtdExecuoesHora);
		
		System.out.println(execucoesPorHora.get(hour));
		System.out.println(hitsPerHourPerDay.get("10/05"));
		
		String report = "FIC_Avanco_Fisico_SSOP";
		StringBuilder sb = new StringBuilder(report);
		
		if (report.length() < 55) {
			StringBuilder padding = new StringBuilder();
			for (int i = 0; i< 55 - report.length(); i++) {
				padding.append(" ");
			}
			
			sb.append(padding, 0, padding.length());
		}
		
		System.out.println("["+sb.toString()+"]");


		NumberFormat nf = NumberFormat.getPercentInstance();
//		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(2);
		nf.setMinimumFractionDigits(1);
		
		Integer falhas = 3;
		Double execucoes = (double) 11;
		Double taxaFalhas = falhas/execucoes;

		System.out.println(nf.format(taxaFalhas));
		
		
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR"));
		
		Date d1 = null;
		try {
			df.setLenient(false);
			d1 = df.parse("13/12/15");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		System.out.println(d1);
	}
	
	public static void main(String[] args) throws Exception {
		
		BufferedReader in = null;
		BufferedWriter outExecute = null; 
		BufferedWriter outSuccess = null;
		BufferedWriter outFailure = null;
		BufferedWriter outTotaisPorDia = null;
		
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
			
			String now = df.format(new Date());
			
			outExecute = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_EXECUTE + now)), "UTF-8"));
			outSuccess = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_SUCCESS + now)), "UTF-8"));
			outFailure = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_FAILURE + now)), "UTF-8"));
			outTotaisPorDia = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE_TOTAIS_POR_DIA + now)), "UTF-8"));
			
			Map<String, HashMap<String,Integer>> reportExecutionsPerDay = new HashMap<String, HashMap<String,Integer>>();
			
			Map<String, HashMap<String,Integer>> reportFailuresPerDay = new HashMap<String, HashMap<String,Integer>>();
			
			// EXECUÇÕES
			Map<String, Integer> hitsPerDay = new HashMap<String, Integer>();
			Map<String, HashMap<String,Integer>> hitsPerHourPerDay = new HashMap<String, HashMap<String,Integer>>();

			// FALHAS
			Map<String, Integer> failuresPerDay = new HashMap<String, Integer>();
			Map<String, HashMap<String,Integer>> failuresPerHourPerDay = new HashMap<String, HashMap<String,Integer>>();

			
			boolean startDay = true;
			String currentDayAndMonth = "";
			
			File dir = new File(DIR);
			if (dir.isDirectory()) {
				
				String[] files = dir.list();
				List<String> list = Arrays.asList(files);
				for (int i = 60; i>=0; i--) {
					
					int hitsExecute = 0;
					int hitsSuccess = 0; 
					int hitsFailure = 0;
					
					String line = null;
					
					String filename = (i > 0 ? LOG_FILE+"."+i : LOG_FILE);
					
					if (list.contains(filename)) {
						
						in = new BufferedReader(new InputStreamReader(new FileInputStream(DIR+filename), "UTF-8"));
						
						System.out.println(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
						
						while ( (line = in.readLine()) != null ) {
							
							if (line.matches(SEARCH_STRING_EXECUTE)) {
								
								hitsExecute++;
								
								if (hitsExecute == 1) {
									outExecute.write(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
									outExecute.newLine();
								}

								LogLine logLine = LogLine.parse(line);
								String dayAndMonth = LogLineUtil.getDayAndMonth(logLine);

								if (currentDayAndMonth.equals("") || !currentDayAndMonth.equals(dayAndMonth)) {
									
									//encerra o dia
									if (!currentDayAndMonth.equals("")) {
										encerraDia(outTotaisPorDia, hitsPerDay.get(currentDayAndMonth), 
																	hitsPerHourPerDay.get(currentDayAndMonth), 
																	failuresPerDay.get(currentDayAndMonth), 
																	failuresPerHourPerDay.get(currentDayAndMonth),
																	reportExecutionsPerDay.get(currentDayAndMonth),
																	reportFailuresPerDay.get(currentDayAndMonth));
									}
									
									//inicia novo dia
									currentDayAndMonth = dayAndMonth;
									startDay = true;
									hitsPerDay.put(dayAndMonth, 1);
								} else {
									hitsPerDay.put(dayAndMonth, hitsPerDay.get(dayAndMonth)+1);
								}
								
								if (startDay) {
									outTotaisPorDia.write(">>>>>>>>>>>>>>>>>>>>>> " + dayAndMonth);
									outTotaisPorDia.newLine();
									startDay = false;
								}
								
								if (_SYSOUT) {
									System.out.println("SEARCH_STRING_EXECUTE >>> "+line);
								} else {
									
									outExecute.write(line);
									outExecute.newLine();
									
//									outTotaisPorDia.write(logLine.toString());
//									outTotaisPorDia.newLine();
									
									//Atualiza a quantidade de execuções por hora
									HashMap<String, Integer> execucoesHoraDia = hitsPerHourPerDay.get(dayAndMonth);
									if (execucoesHoraDia == null) {
										execucoesHoraDia = new HashMap<String, Integer>();
										hitsPerHourPerDay.put(dayAndMonth, execucoesHoraDia);
									}
									String hour = LogLineUtil.getHour(logLine);
									Integer qtdExecucoesHora = execucoesHoraDia.get(hour);
									if (qtdExecucoesHora == null || qtdExecucoesHora == 0) {
										qtdExecucoesHora = 1;
									} else {
										qtdExecucoesHora++;
									}
									execucoesHoraDia.put(hour, qtdExecucoesHora);

									//Atualiza a quantidade de execuções por relatorio
									HashMap<String, Integer> executionsPerType = reportExecutionsPerDay.get(dayAndMonth);
									if (executionsPerType == null) {
										executionsPerType = new HashMap<String, Integer>();
										reportExecutionsPerDay.put(dayAndMonth, executionsPerType);
									}
									String report = logLine.getReportName();
									Integer qtdExecucoesReport = executionsPerType.get(report);
									if (qtdExecucoesReport == null || qtdExecucoesReport == 0) {
										qtdExecucoesReport = 1;
									} else {
										qtdExecucoesReport++;
									}
									executionsPerType.put(report, qtdExecucoesReport);
									
									if ((hitsExecute % 50) == 0) {
										System.out.println("out.flush() => hitsExecute="+hitsExecute);
										outExecute.flush();
										outTotaisPorDia.flush();
									}
								}
								
							} else if (line.matches(SEARCH_STRING_SUCCESS)) {

								hitsSuccess++;

								if (hitsSuccess == 1) {
									outSuccess.write(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
									outSuccess.newLine();
								}

								if (_SYSOUT) {
									System.out.println(line);
								} else {
									
									outSuccess.write(line);
									outSuccess.newLine();
									
									if ((hitsSuccess % 50) == 0) {
										System.out.println("out.flush() => hitsSuccess="+hitsSuccess);
										outSuccess.flush();
									}
								}

							} else if (line.matches(SEARCH_STRING_FAILURE)) {
								
								hitsFailure++;
								
								if (hitsFailure == 1) {
									outFailure.write(">>>>>>>>>>>>>>>>>>>>>> File : " + filename);
									outFailure.newLine();
								}
								
								LogLine logLine = LogLine.parse(line);
								String dayAndMonth = LogLineUtil.getDayAndMonth(logLine);

								if (failuresPerDay.get(dayAndMonth) == null) {
									failuresPerDay.put(dayAndMonth, 1);
								} else {
									failuresPerDay.put(dayAndMonth, failuresPerDay.get(dayAndMonth)+1);
								}
								
								//Atualiza a quantidade de falhas por hora
								HashMap<String, Integer> falhasPorHora = failuresPerHourPerDay.get(dayAndMonth);
								if (falhasPorHora == null) {
									falhasPorHora = new HashMap<String, Integer>();
									failuresPerHourPerDay.put(dayAndMonth, falhasPorHora);
								}
								String hour = LogLineUtil.getHour(logLine);
								Integer qtdFalhas = falhasPorHora.get(hour);
								if (qtdFalhas == null || qtdFalhas == 0) {
									qtdFalhas = 1;
								} else {
									qtdFalhas++;
								}
								falhasPorHora.put(hour, qtdFalhas);

								//Atualiza a quantidade de falhas por relatorio
								HashMap<String, Integer> failuresPerReport = reportFailuresPerDay.get(dayAndMonth);
								if (failuresPerReport == null) {
									failuresPerReport = new HashMap<String, Integer>();
									reportFailuresPerDay.put(dayAndMonth, failuresPerReport);
								}
								String report = logLine.getReportName();
								Integer qtdFalhasReport = failuresPerReport.get(report);
								if (qtdFalhasReport == null || qtdFalhasReport == 0) {
									qtdFalhasReport = 1;
								} else {
									qtdFalhasReport++;
								}
								failuresPerReport.put(report, qtdFalhasReport);

								if (_SYSOUT) {
									System.out.println(line);
								} else {
									
									outFailure.write(line);
									outFailure.newLine();
									
									if ((hitsFailure % 50) == 0) {
										System.out.println("out.flush() => hitsFailure="+hitsFailure);
										outFailure.flush();
									}
								}

							}
							
							
						} // Lê a próxima linha
						
						// FIM DE 1 ARQUIVO
						
						System.out.println("**************************");
						System.out.println("Search \"Execute\" ("+hitsExecute+" hits in file \""+ filename +"\")");
						System.out.println("Search \"Success\" ("+hitsSuccess+" hits in file \""+ filename +"\")");
						System.out.println("Search \"Failure\" ("+hitsFailure+" hits in file \""+ filename +"\")");
						System.out.println("**************************");
						System.out.println("");
					}
					
					in = null;
					
				} // Lê o próximo arquivo

				// FIM DE TODOS OS ARQUIVOS
				
				//encerra o dia
				if (!currentDayAndMonth.equals("")) {
					encerraDia(outTotaisPorDia, hitsPerDay.get(currentDayAndMonth), 
												hitsPerHourPerDay.get(currentDayAndMonth), 
												failuresPerDay.get(currentDayAndMonth),
												failuresPerHourPerDay.get(currentDayAndMonth),
												reportExecutionsPerDay.get(currentDayAndMonth),
												reportFailuresPerDay.get(currentDayAndMonth));
				}
				
				outTotaisPorDia.newLine();
				outTotaisPorDia.write(">>>>>>>> TOTAIS DO PERÍODO <<<<<<<<");
				outTotaisPorDia.newLine();
				
				outTotaisPorDia.newLine();
				outTotaisPorDia.write("EXECUÇÕES POR DIA:");
				outTotaisPorDia.newLine();
				
				List<String> days = new ArrayList<String>(hitsPerDay.keySet());
				DayAndMonthComparator dayAndMonthComparator = new DayAndMonthComparator();
				Collections.sort(days, dayAndMonthComparator);
				
				for (String day : days) {
					outTotaisPorDia.write(day + " - " + hitsPerDay.get(day));
					outTotaisPorDia.newLine();
				}
				
				Map<String, Integer> globalExecutionsPerReport = somaRelatoriosDoPeriodo(reportExecutionsPerDay);
				
				outTotaisPorDia.newLine();
				outTotaisPorDia.write("EXECUÇÕES DO PERÍODO:");
				outTotaisPorDia.newLine();

				escreveRanking(outTotaisPorDia, globalExecutionsPerReport);
				
				outTotaisPorDia.newLine();
				outTotaisPorDia.write("FALHAS POR DIA:");
				outTotaisPorDia.newLine();
				
				days = new ArrayList<String>(failuresPerDay.keySet());
				Collections.sort(days, dayAndMonthComparator);
				
				for (String day : days) {
					
					Integer falhas = failuresPerDay.get(day);
					Integer execucoes = hitsPerDay.get(day);
					
					outTotaisPorDia.write(day + " - " + falhas + " ( "+ calculaTaxaFalhas(falhas, execucoes) +" )");
					outTotaisPorDia.newLine();
				}
				
				Map<String, Integer> globalFailuresPerReport = somaRelatoriosDoPeriodo(reportFailuresPerDay);
				
				outTotaisPorDia.newLine();
				outTotaisPorDia.write("FALHAS DO PERÍODO:");
				outTotaisPorDia.newLine();

				escreveRanking(outTotaisPorDia, globalFailuresPerReport);
			}
			
			
		} finally {
			if (in != null)
				in.close();
			if (outExecute != null)
				outExecute.close();
			if (outSuccess != null)
				outSuccess.close();
			if (outFailure != null)
				outFailure.close();
			if (outTotaisPorDia != null)
				outTotaisPorDia.close();
		}
		
		
	}
	
	private static void encerraDia(BufferedWriter outTotaisPorDia,	Integer qtdExecucoesDia, 
																	HashMap<String, Integer> hitsPerHour, 
																	Integer qtdFalhasDia,
																	HashMap<String, Integer> failuresPerHour,
																	final Map<String, Integer> executionsPerReport,
																	final Map<String, Integer> failuresPerReport) throws IOException {

		outTotaisPorDia.newLine();
		outTotaisPorDia.write("EXECUÇÕES DO DIA:");
		outTotaisPorDia.newLine();
		
		escreveRanking(outTotaisPorDia, executionsPerReport);
		
		outTotaisPorDia.newLine();
		outTotaisPorDia.write("EXECUÇÕES POR HORA:");
		outTotaisPorDia.newLine();
		
		TreeSet<String> hours = new TreeSet<String>(hitsPerHour.keySet());
		
		for (String hour : hours) {
			outTotaisPorDia.write(hour + " - " + hitsPerHour.get(hour));
			outTotaisPorDia.newLine();
		}
		
		outTotaisPorDia.newLine();
		outTotaisPorDia.write("TOTAL DE EXECUÇÕES: " + qtdExecucoesDia);
		outTotaisPorDia.newLine();

		if (failuresPerReport != null) {
			outTotaisPorDia.newLine();
			outTotaisPorDia.write("FALHAS DO DIA:");
			outTotaisPorDia.newLine();
			
			escreveRanking(outTotaisPorDia, failuresPerReport);
		}

		if (failuresPerHour != null) {
			
			outTotaisPorDia.newLine();
			outTotaisPorDia.write("FALHAS POR HORA:");
			outTotaisPorDia.newLine();
			
			hours = new TreeSet<String>(failuresPerHour.keySet());
			
			for (String hour : hours) {
				outTotaisPorDia.write(hour + " - " + failuresPerHour.get(hour) + " ( "+ calculaTaxaFalhas(failuresPerHour.get(hour), hitsPerHour.get(hour)) +" )");
				outTotaisPorDia.newLine();
			}
		}

		outTotaisPorDia.newLine();
		outTotaisPorDia.write("TOTAL DE FALHAS: " + (qtdFalhasDia == null ? 0 : qtdFalhasDia));
		outTotaisPorDia.newLine();
		outTotaisPorDia.newLine();
	}
	
	private static void escreveRanking(BufferedWriter outTotaisPorDia, final Map<String, Integer> reportMap) throws IOException {
		List<String> reportsParaRanking = new ArrayList<String>(reportMap.keySet());
		
		Collections.sort(reportsParaRanking, new Comparator<String>() {
			
			@Override
			public int compare(String s1, String s2) {
				
				int result = 0;
				
				if (reportMap.get(s1) == reportMap.get(s2)) {
					result = 0;
				} else if (reportMap.get(s1) > reportMap.get(s2)) {
					result = -1;
				} else {
					result = 1;
				}
				
				return result;
			};
			
		});
		
		for (String report : reportsParaRanking) {
			
			StringBuilder sb = new StringBuilder(report);
			
			if (report.length() < 55) {
				StringBuilder padding = new StringBuilder();
				for (int i = 0; i< 55 - report.length(); i++) {
					padding.append(" ");
				}
				
				sb.append(padding, 0, padding.length());
			}
			
			outTotaisPorDia.write(sb.toString() + "- " + reportMap.get(report));
			outTotaisPorDia.newLine();
		}

	}
	
	private static String calculaTaxaFalhas(Integer iFalhas, Integer iExecucoes) {
		NumberFormat nf = NumberFormat.getPercentInstance();
		nf.setMaximumFractionDigits(2);
		nf.setMinimumFractionDigits(1);
		
		Double dExecucoes = null;
		Double taxaFalhas = null;
		
		//se nao houve execucoes naquela hora, somente falhas
		//Exemplo: 1 relatorio comecou as 16h53, mas so terminou com falha as 17h49 (e nesse intervalo, nenhum relatorio foi solicitado)
		if (iExecucoes == null || iExecucoes == 0) {
			taxaFalhas = 1D;
		} else {
			dExecucoes = (double) iExecucoes;
			taxaFalhas = iFalhas/dExecucoes;
		}
		
		return nf.format(taxaFalhas);
	}
	
	private static Map<String, Integer> somaRelatoriosDoPeriodo(Map<String, HashMap<String,Integer>> reportsPerDay) {
		
		Map<String, Integer> globalReportMap = null;
		
		if (reportsPerDay != null) {
			
			globalReportMap = new HashMap<String, Integer>();
			
			for (String day : reportsPerDay.keySet()) {
				
				Map<String, Integer> reportMap = reportsPerDay.get(day);
				
				if (reportMap != null) {
					//percorre todos os relatorios do dia
					for (String report : reportMap.keySet()) {
						
						Integer globalExecutions = globalReportMap.get(report);
						
						if ( globalExecutions != null && globalExecutions > 0 ) {
							globalExecutions += reportMap.get(report);
						} else {
							globalExecutions = reportMap.get(report);
						}
						
						globalReportMap.put(report, globalExecutions);
					}
				}
				
			}
			
		}
		
		
		return globalReportMap;
	}
	
}

class DayAndMonthComparator implements Comparator<String> {
	@Override
	public int compare(String o1, String o2) {
		int result = 0;
		
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, new Locale("pt", "BR"));
		df.setLenient(false);
		
		Date d1 = null;
		try {
			//TODO corrigir
			d1 = df.parse(o1+"/16");
		} catch (ParseException e) {
			e.printStackTrace();
			return result;
		}
		
		Date d2 = null;
		try {
			//TODO corrigir
			d2 = df.parse(o2+"/16");
		} catch (ParseException e) {
			e.printStackTrace();
			return result;
		}
		
		if (d1.before(d2)) {
			result = -1;
		} else if (d1.after(d2)) {
			result = 1;
		}
		
		return result;
	}
	
}
