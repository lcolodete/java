package petrobras.ticeng.fic.tcr;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

public class LogLineUtil {

	public static String getDayAndMonth(LogLine e) throws ParseException {
		Date d = e.getDateTimeObject();
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int month = c.get(Calendar.MONTH) + 1;
		String monthStr = Integer.toString(month);
		monthStr = (month < 10) ? "0"+monthStr : monthStr;
		
		String dayStr = LogLineUtil.getDay(e); 
		
		return dayStr+"/"+monthStr;
	}
	
	public static String getDay(LogLine e) throws ParseException {
		Date d = e.getDateTimeObject();
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int day = c.get(Calendar.DAY_OF_MONTH);
		String dayStr = Integer.toString(day);
		dayStr = (day < 10) ? "0"+dayStr : dayStr; 
		
		return dayStr;
	}
	
	public static String getHour(LogLine e) throws ParseException {
		Date d = e.getDateTimeObject();
		
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		
		int hour = c.get(Calendar.HOUR_OF_DAY);
		String hourStr = Integer.toString(hour);
		hourStr = (hour < 10) ? "0"+hourStr : hourStr; 
		
		return hourStr;
	}

}
