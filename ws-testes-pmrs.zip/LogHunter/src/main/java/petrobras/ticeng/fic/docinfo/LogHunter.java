package petrobras.ticeng.fic.docinfo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Recebe como entrada uma lista de arquivos (tabela docinfo). 
 * Para cada item da lista:
 * - se contem acentos ou caracteres especiais, escreve o nome do arquivo no arquivo de saida correspondente.
 * - se nao contem, pula e passa para o proximo da lista.
 * 
 * OBS: CLASSE USADA PARA RESOLVER A 2a PARTE DO PROBLEMA DO DOWNLOAD DE ARQUIVOS ANEXOS.
 * 
 * @author ur5g
 *
 */
public class LogHunter {

	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/docinfo/in/";
	
	private static final String SEARCH_STRING_Special_Characters = "[áéíóúÁÉÍÓÚàÀâêîôûÂÊÎÔÛçÇãÃõÕº°üÜ§£¢¬ª¹²³´]";

	private static final String SEARCH_STRING_Unknown_Characters = "[^A-za-z0-9\\-_,\\.)(áéíóúÁÉÍÓÚàÀâêîôûÂÊÎÔÛçÇãÃõÕº°üÜ§£¢¬ª¹²³´/=<>:;\\?\\+!@#\\$%\\&\\*~\\^{}\\[\\]`'\"|]";
	
	private static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/docinfo/out/";
	private static final String OUTPUT_FILE = "output_";
	
	public static void main2(String[] args) {
		
		String line = "/ebusiness/shared/home/PrdExt100_WLSv103/applications/fic/doclinks/P75-RIR-ELE-OFE-015SystemAutomationPanels_已压缩.pdf";
		
//		boolean matches = false;
//		if (line.matches(SEARCH_STRING_Special_Characters)) {
//			matches = true;
//		}
//		System.out.println(matches);

		String regex = SEARCH_STRING_Unknown_Characters;
		
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(line);
		
		String field = "";
		
		while (m.find()) {
			field = m.group();
			System.out.println("found="+field);
		}

		
	}
	
	public static void main(String[] args) throws Exception {
		
		BufferedReader in = null;
		BufferedWriter outSpecial = null;
		BufferedWriter outNotSpecial = null;
		
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
			
			String now = df.format(new Date());
			
//			FileWriter fileWriter = new FileWriter(OUTPUT_DIR + OUTPUT_FILE + "especiais_" + now);
			
			outSpecial = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE + "especiais_" + now)), "UTF-8"));
			outNotSpecial = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(OUTPUT_DIR + OUTPUT_FILE + "NAO_especiais_" + now)), "UTF-8"));
			
			File dir = new File(INPUT_DIR);
				
			File[] files = dir.listFiles();
			
			Set<File> fileSet = new TreeSet<File>(Arrays.asList(files));
			
			for (File file : fileSet) {
			
				int hits = 0;
				int hitsNotSpecial = 0;
				
				int lineNumber = 0;
				
				in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
				
				System.out.println(">>>>>>>>>>>>>>>>>>>>>> File : " + file.getName());
				
				String line = null;
				
				while ( (line = in.readLine()) != null ) {
					
					lineNumber++;
					
					if ((lineNumber % 1000) == 0) {
						System.out.println("Processando linha "+lineNumber);
					}

					Pattern patternSpecial = Pattern.compile(SEARCH_STRING_Special_Characters);
					Matcher matcherSpecial = patternSpecial.matcher(line);
					
					Pattern patternUnknown = Pattern.compile(SEARCH_STRING_Unknown_Characters);
					Matcher matcherUnknown = patternUnknown.matcher(line);
					
					if (matcherSpecial.find()) {
						System.out.println("line="+ line +" -> found="+matcherSpecial.group());
						
						hits++;
						
						outSpecial.write("Line "+lineNumber+": "+line);
						outSpecial.newLine();
						
						if ((hits % 100) == 0) {
							System.out.println("outSpecial.flush() => hits="+hits);
							outSpecial.flush();
						}

					} else if (matcherUnknown.find()) {

						System.out.println("line="+ line +" -> found="+matcherUnknown.group());
						
						hits++;
						
						outSpecial.write("*** ATENCAO: CARACTER NAO CONHECIDO *** Line "+lineNumber+": "+line);
						outSpecial.newLine();
						
						if ((hits % 100) == 0) {
							System.out.println("outSpecial.flush() => hits="+hits);
							outSpecial.flush();
						}

					} else {
						hitsNotSpecial++;
						
						outNotSpecial.write("Line "+lineNumber+": "+line);
						outNotSpecial.newLine();
						
						if ((hitsNotSpecial % 100) == 0) {
							System.out.println("outNotSpecial.flush() => hitsNotSpecial="+hitsNotSpecial);
							outNotSpecial.flush();
						}

					}
					
					
				} // Le a proxima linha
				
				// FIM DE 1 ARQUIVO

				System.out.println("**************************");
				System.out.println("Search complete ("+hits+" hits in file \""+ file +"\")");
				System.out.println("**************************");
				System.out.println("");
				
				if (in != null)
					in.close();
				
				in = null;
				
			} // fim do for

			// FIM DE TODOS OS ARQUIVOS
			
		} finally {
			if (in != null)
				in.close();
			if (outSpecial != null)
				outSpecial.close();
			if (outNotSpecial != null)
				outNotSpecial.close();
		}
		
		
	}
	
	
}
