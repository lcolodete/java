package petrobras.ticeng.fic.maximo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

/**
 * Busca uma expressao regular em todos os arquivos indicados no diretorio de entrada.
 * Produz um arquivo de saida com as linhas encontradas.
 * 
 * @author ur5g
 *
 */
public class LogHunter {

//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/maximo/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-05-26/Producao-dinamico/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-05-28/fich/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-06-02/fich-cipd/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-06-03/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-06-12/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-06-12/fich-cipd/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-06-23/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-07-08/fich-cipd/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-08-06/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-08-10/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-08-13/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-08-14/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-08-27/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-09-03/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-09-16/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-10-15/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-11-03/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-11-03/13-08_a_25-09/tenerife_oviedo/";
//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-11-05/";
	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-11-12/";
	
	private static final String SEARCH_STRING_BMXAA6348I_O_serviço_SYSTEM_esta_sendo_iniciado = ".*BMXAA6348I - O serviço SYSTEM está sendo iniciado\\..*";
	private static final String SEARCH_STRING_Connection_spid = ".*Connection spid.*";
	private static final String SEARCH_STRING_BMXAA7088I = ".*BMXAA7088I.*";
	private static final String SEARCH_STRING_DBManager = ".*DBManager Total number of connections.*";
	private static final String SEARCH_STRING_NoRouteToHostException = ".*java\\.net\\.NoRouteToHostException.*";
	private static final String SEARCH_STRING_SocketException = ".*java\\.net\\.SocketException.*";
	private static final String SEARCH_STRING_TNS_bad_packet = ".*TNS:bad packet.*";
	private static final String SEARCH_STRING_Error = ".*\\[ERROR\\].*";
	private static final String SEARCH_STRING_UnknownHostException = ".*UnknownHostException.*";
	private static final String SEARCH_STRING_Correlated_data_PMWoGenCronTask = ".*Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:.{3,50} ElapsedTime:\\d+ ms  END";
	
	private static final String SEARCH_STRING_FIC_Etiquetas = ".*FIC_Etiquetas.*";
	private static final String SEARCH_STRING_CAMID = ".*CAMID.*";
	
	private static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/maximo/out/";
	private static final String OUTPUT_FILE = "output_";
	
	public static void main2(String[] args) {
		boolean matches = false;
		
//		String line = "26 May 2015 00:29:23:028 [INFO] [MXServerESC1] [] BMXAA7088I - A classe DbConnectionWatchDog registrou 2 referências de conexão neste período; atualmente existem 2 referências abertas, 2 referências de execução longa, 2 conexões de execução longa e 0 referências que foram fechadas pelo finalizador do coletor de lixo.";
//		
//		if (line.matches(SEARCH_STRING_BMXAA7088I)) {
//			matches = true;
//		}
//		String line = "13 Mar 2015 10:00:20:636 [ERROR] [MXServer3] [CID-UIASYNC-4182] ORA-12592: TNS:bad packet";
//		
//		if (line.matches(SEARCH_STRING_TNS_bad_packet)) {
//			matches = true;
//		}
		String line = "Correlated data: BEGIN TaskName:PMWoGenCronTask InstanceName:ENGGE-IEEI-IEINFRA-CMEDISE-001 ElapsedTime:11476 ms  END";
		
		if (line.matches(SEARCH_STRING_Correlated_data_PMWoGenCronTask)) {
			matches = true;
		}
		
		System.out.println(matches);
		
	}
	
	public static void main(String[] args) throws Exception {
		
		BufferedReader in = null;
		BufferedWriter out = null; 
		
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
			
			String now = df.format(new Date());
			
			out = new BufferedWriter(new FileWriter(OUTPUT_DIR + OUTPUT_FILE + now));
			
			File dir = new File(INPUT_DIR);
			if (dir.isDirectory()) {
				
				File[] files = dir.listFiles();
				
				Set<File> fileSet = new TreeSet<File>(Arrays.asList(files));
				
				for (File file : fileSet) {
					
					if (file.isFile()) {
					
						int hits = 0;
						
						int lineNumber = 0;
						
						in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
						
						System.out.println(">>>>>>>>>>>>>>>>>>>>>> File : " + file.getName());
						
						String line = null;
						
						while ( (line = in.readLine()) != null ) {
							
							lineNumber++;
							if (lineNumber == 1) {
								out.write(">>>>>>>>>>>>>>>>>>>>>> File : " + file.getName());
								out.newLine();
							}
							
							if ((lineNumber % 25000) == 0) {
								System.out.println("Processando linha "+lineNumber);
							}

//							if (line.matches(SEARCH_STRING_Connection_spid)) {
//							if (line.matches(SEARCH_STRING_BMXAA7088I) || line.matches(SEARCH_STRING_DBManager)) {
//							if (line.matches(SEARCH_STRING_TNS_bad_packet)) {
//							if (line.matches(SEARCH_STRING_Error)) {
//							if ( line.matches(SEARCH_STRING_SocketException) ) {
							if ( line.matches(SEARCH_STRING_NoRouteToHostException) ) {
//							if ( line.matches(SEARCH_STRING_CAMID) ) {
//							if ( line.matches(SEARCH_STRING_BMXAA6348I_O_serviço_SYSTEM_esta_sendo_iniciado) ) {
//							if (line.matches(SEARCH_STRING_NoRouteToHostException) || line.matches(SEARCH_STRING_Error)) {
//							if (line.matches(SEARCH_STRING_UnknownHostException)) {
//							if (line.matches(SEARCH_STRING_Correlated_data_PMWoGenCronTask)) {
								
								hits++;
								
								out.write("Line "+lineNumber+": "+line);
								out.newLine();
								
								if ((hits % 500) == 0) {
									System.out.println("out.flush() => hits="+hits);
									out.flush();
								}
								
								
							}
							
							
						} // Le a proxima linha
						
						// FIM DE 1 ARQUIVO

						out.write("Hits : "+hits);
						out.newLine();
						
						//SEARCH_STRING_NoRouteToHostException
//						out.write("Ocorrencias do erro (hits/2) : "+hits/2);
//						out.newLine();
						
						out.newLine();

						System.out.println("**************************");
						System.out.println("Search complete ("+hits+" hits in file \""+ file +"\")");
						System.out.println("**************************");
						System.out.println("");
						
						if (in != null)
							in.close();
						
						in = null;
					}	
					
					
				} // Le o proximo arquivo

				// FIM DE TODOS OS ARQUIVOS
				
			}
			
			
		} finally {
			if (in != null)
				in.close();
			if (out != null)
				out.close();
		}
		
		
	}
	
	
}
