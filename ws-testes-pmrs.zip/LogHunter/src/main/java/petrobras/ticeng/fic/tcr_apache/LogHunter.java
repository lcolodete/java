package petrobras.ticeng.fic.tcr_apache;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import oracle.jdbc.pool.OracleDataSource;

/**
 * 
 * @author ur5g
 *
 */
public class LogHunter {

//	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2015-11-09/a/";
	private static final String INPUT_DIR = "C:/Users/ur5g/FIC/Logs/2017-01-19/";
	private static final String LOG_PROFUTE = "access_https_profute_";
	private static final String LOG_DUQUECAXIENSE = "access_https_duquecaxiense_";

	//TCR
//	private static final String SEARCH_STRING_Post_tarf_servlet_dispatch = ".*POST /tarf/servlet/dispatch HTTP.*";
//	private static final String SEARCH_STRING_Get_tarf_servlet_dispatch_gd = ".*GET /tarf/servlet/dispatch/gd/.*";
	
	//Cognos
	private static final String SEARCH_STRING_Post_tarf_servlet_dispatch = ".*POST /ibmcognos/cgi-bin/cognos.cgi HTTP.*";
	private static final String SEARCH_STRING_Get_tarf_servlet_dispatch_gd = ".*GET /ibmcognos/cgi-bin/cognos.cgi\\?b_action=dc.*";
	
	private static final String OUTPUT_DIR = "C:/Users/ur5g/FIC/Logs/LogHunter/maximo/out/";
	private static final String OUTPUT_FILE = "output_";

	//PRODUCAO
	private static final String URL_BANCO = "jdbc:oracle:thin:@(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST = scanficp.petrobras.biz)(PORT = 1521)))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = nficp.petrobras.biz)(FAILOVER_MODE =(TYPE = SESSION)(METHOD = BASIC)(RETRIES = 180)(DELAY = 5))))";
	private static final String USER = "FIC";
	private static final String PASSWORD = "B2DHqf_FUv";

	public static void main(String[] args) throws Exception {
		
		BufferedReader in = null;
		BufferedWriter out = null;
		Connection con = null;
		
		//TODO mudar para List<ApacheLogLine> ? Ver a linha 127!
		Map<String, Set<ApacheLogLine>> userLogsMap = new TreeMap<String, Set<ApacheLogLine>>();
		
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
			
			String now = df.format(new Date());
			
			out = new BufferedWriter(new FileWriter(OUTPUT_DIR + OUTPUT_FILE + now));
			
			File dir = new File(INPUT_DIR);
			if (dir.isDirectory()) {
				
				File[] files = dir.listFiles();
				
				Set<File> fileSet = new TreeSet<File>(Arrays.asList(files));
				
				for (File file : fileSet) {
					
					if ( file.isFile() &&
						 (file.getName().startsWith(LOG_PROFUTE) || file.getName().startsWith(LOG_DUQUECAXIENSE)) ) {
					
						int hits = 0;
						
						int lineNumber = 0;
						
						in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
						
						System.out.println(">>>>>>>>>>>>>>>>>>>>>> File : " + file.getName());
						
						String line = null;
						
						while ( (line = in.readLine()) != null ) {
							
							lineNumber++;
							if (lineNumber == 1) {
								out.write(">>>>>>>>>>>>>>>>>>>>>> File : " + file.getName());
								out.newLine();
							}
							
							if ((lineNumber % 25000) == 0) {
								System.out.println("Processando linha "+lineNumber);
							}

							if ( line.matches(SEARCH_STRING_Post_tarf_servlet_dispatch) ||
								 line.matches(SEARCH_STRING_Get_tarf_servlet_dispatch_gd)	) {
								
								hits++;
								
//								out.write("Line "+lineNumber+": "+line);
//								out.newLine();
								
								if ((hits % 500) == 0) {
									System.out.println("out.flush() => hits="+hits);
									out.flush();
								}
								
								try {
									ApacheLogLine logLine = ApacheLogLine.parse(line);
									String user = logLine.getUser();
									
									Set<ApacheLogLine> lineSet = userLogsMap.get(user);
									
									if (lineSet == null) {
										//TODO mudar para LinkedHashSet<ApacheLogLine> para nao precisar criar a lista na 205 e fazer o sort na 206
										lineSet = new HashSet<ApacheLogLine>();
										userLogsMap.put(user, lineSet);
									}
									lineSet.add(logLine);
								} catch (Exception e) {
									out.write("ApacheLogLine.parse() falhou na seguinte linha : "+line);
									out.newLine();
									out.write("\t\t"+e.getMessage());
									out.newLine();
								}
							}
							
							
						} // Le a proxima linha
						
						// FIM DE 1 ARQUIVO

						out.write("Hits : "+hits);
						out.newLine();
						
						out.newLine();

						System.out.println("**************************");
						System.out.println("Search complete ("+hits+" hits in file \""+ file +"\")");
						System.out.println("**************************");
						System.out.println("");
						
						if (in != null)
							in.close();
						
						in = null;
					}	
					
					
				} // Le o proximo arquivo

				// FIM DE TODOS OS ARQUIVOS

				System.out.println("**************************");
				System.out.println("FIM DE TODOS OS ARQUIVOS");
				System.out.println("**************************");
				System.out.println("");

				out.write("=====================================================================================================================================================");
				out.newLine();
				out.newLine();
				
				Map<String, List<ApacheLogLine>> userEtiquetas = new TreeMap<String, List<ApacheLogLine>>();
				Set<String> groupsEtiquetas = new TreeSet<String>();
				
				DateFormat df_pt_BR = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, new Locale("pt", "BR"));
				
				System.out.println("Criando DataSource...");
				OracleDataSource ds = new OracleDataSource();
				ds.setURL(URL_BANCO);
				System.out.println("DataSource criado.");
				
				System.out.println("Obtendo conexao...");
				con = ds.getConnection(USER, PASSWORD);
				System.out.println("Conexao obtida.");
				
				int i = 0;
				for (String user : userLogsMap.keySet()) {
					i++;
					
					out.write(i+")");
					out.newLine();
					
					out.write("USUARIO: "+user);
					out.newLine();
					
					String groups = getUserGroups(user, con);
					
					out.write("GRUPOS: "+groups);
					out.newLine();
					
					Set<ApacheLogLine> lineSet = userLogsMap.get(user);
					List<ApacheLogLine> lineList = new ArrayList<ApacheLogLine>(lineSet);
					Collections.sort(lineList, new DateTimeComparator());
					
					for (ApacheLogLine line : lineList) {
						if (line.getReportName().equals("FIC_Etiquetas")) {
							List<ApacheLogLine> lineEtiquetasList = userEtiquetas.get(user);
							if (lineEtiquetasList == null) {
								lineEtiquetasList = new ArrayList<ApacheLogLine>();
								userEtiquetas.put(user, lineEtiquetasList);
							}
							lineEtiquetasList.add(line);
						}
						out.write("\t"+df_pt_BR.format(line.getDateTime()) + " - " + line.getReportName());
						out.newLine();
					}
					out.newLine();
				}

				if (!userEtiquetas.keySet().isEmpty()) {
					
					out.write("=====================================================================================================================================================");
					out.newLine();
					out.newLine();
					
					out.write("Usuarios que imprimiram FIC_Etiquetas");
					out.newLine();
					out.newLine();
					
					i = 0;
					for (String user : userEtiquetas.keySet()) {
						i++;
						
						out.write(i+")");
						out.newLine();
						
						out.write("USUARIO: "+user);
						out.newLine();
						
						String groups = getUserGroups(user, con);
						groupsEtiquetas.addAll(Arrays.asList(groups.split(", ")));
						
						out.write("GRUPOS: "+groups);
						out.newLine();
						
						List<ApacheLogLine> etiquetasList = userEtiquetas.get(user);
						
						for (ApacheLogLine line : etiquetasList) {
							out.write("\t"+df_pt_BR.format(line.getDateTime()) + " - " + line.getReportName());
							out.newLine();
						}
						out.newLine();
					}
					
					out.write("=====================================================================================================================================================");
					out.newLine();
					out.newLine();
					
					out.write("Grupos que imprimiram FIC_Etiquetas");
					out.newLine();
					out.newLine();
					
					for (String groups : groupsEtiquetas) {
						out.write("\t"+groups);
						out.newLine();
					}
				}

			}
			
			
		} finally {
			
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}

			if (in != null)
				in.close();
			if (out != null)
				out.close();
		}
		
		
	}
	
	private static String getUserGroups(String user, Connection con) throws SQLException {
		
		StringBuilder groups = new StringBuilder();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = con.prepareStatement("select groupname from groupuser where userid=? order by groupname asc");
			ps.setString(1, user);
			
			System.out.println("Executando query para o usuario: "+user);
			rs = ps.executeQuery();
			System.out.println("Query executada.");
			
			while (rs.next()) {
				String groupName = rs.getString("groupname");
				
				if ( !groupName.matches("EVERYONE|DEFLTREG|MAXADMIN|FIC_OPERADOR|FIC_GESTAO CONTRATADA|FIC_CONTROLADOR DE QUALIDADE|FIC_CONSULTANTE|FIC_ADMINISTRADOR LOCAL|FIC_FISCAL|FIC_CLIENTE") )
				{
					if (groups.length() > 0)
						groups.append(", ");
					groups.append(groupName);
				}
			}
			
			return groups.toString();
			
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			
			if (ps != null)
				try {
					ps.close();
				} catch (Exception e) {
					e.printStackTrace();
				}

		}

		
	}
	
	
}
