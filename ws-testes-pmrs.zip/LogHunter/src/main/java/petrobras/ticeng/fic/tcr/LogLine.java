package petrobras.ticeng.fic.tcr;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Representa uma linha de execução no arquivo de totais do dia.
 * 
 * Exemplo:
 * 
 * 2015-05-19 14:11:13.201	1F3EFCA3A9E3ED082122EFCBC523B7E110402AF2	report[@name='FIC_FVM']
 * 
 * A linha tem 3 componentes :
 * 
 * 1) Data e hora da execução
 * 2) Identificador da execução
 * 3) Nome do relatório executado
 * 
 * @author ur5g
 *
 */
public class LogLine {

	private String dateTime;
	private String id;
	private String reportName;
	
	public LogLine(String dateTime, String id, String reportName) {
		this.dateTime = dateTime;
		this.id = id;
		this.reportName = reportName;
	}

	public String getDateTime() {
		return dateTime;
	}

	public Date getDateTimeObject() throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		return df.parse(this.dateTime);
	}
	
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public static LogLine parse(String s) {
		
		String dateTime = parseDateTime(s);
		String id = parseId(s);
		String reportName = parseReportName(s);
		
		LogLine executeLine = new LogLine(dateTime, id, reportName); 
		
		return executeLine;
	}
	
	private static String parseDateTime(String s) {
		return find("\\d\\d\\d\\d-\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d.\\d\\d\\d", s);
	}
	
	private static String parseId(String s) {
		return find("[A-F0-9]{40}", s);
	}
	
	private static String parseReportName(String s) {
		
		String reportFound = find("report\\[@name='.*?'\\]", s);
		
		String[] reportParts = reportFound.split("=");
		String reportName = reportParts[1].replaceAll("'", "").replace("]", "");
		
		return reportName;
	}
	
	private static String find(String regex, String s) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(s);
		
		String field = "";
		
		if (m.find()) {
			field = m.group();
		} else {
			throw new IllegalArgumentException("A regex "+regex+" nao encontrou nenhum resultado.");
		}
		
		return field;
	}

	@Override
	public String toString() {
		return this.dateTime + " " + this.id + " " + this.reportName;
	}
	
	public static void main(String[] args) throws ParseException {
		String lineToParse = "10.29.170.61:16310	19458	2015-05-19 15:58:30.313	-3	DA4DA4A6F0DDCCE41DA040D9CDFCFABDDE947CDE	M9dv8jhwCwvM2CMhwqqwCy298GjCw82Ch2Cdd9Mv	M9dv8jhwCwvM2CMhwqqwCy298GjCw82Ch2Cdd9Mv		1609796496	RSVP	6138	3	Audit.RTUsage.RSVP	Execute	Report ReportService	/content/folder[@name='FIC']/package[@name='FIC_REP_CCMPackage']/report[@name='FIC_CCM_COMPLETO']	Failure	RSV-SRV-0066 A soap fault has been returned. RQP-DEF-0112 Query execution time exceeds the 20 second limit specified for the user who has the identity '{All Authenticated Users, Everyone, Authors, Query Users, Consumers, Metrics Authors, Metrics Users, Planning Contributor Users, Controller Users, Analysis Users, PowerPlay Users, Data Manager Authors, Readers, Express Authors, Adaptive Analytics Users, System Administrators, DEFLTREG, ENGEP-IEUEP-II-IECO-P74, ENGEP-IEUEP-II-IECO-P75, ENGEP-IEUEP-II-IECO-P76, ENGEP-IEUEP-II-IECO-P77, EVERYONE, FIC_CONSULTANTE}'. 	<parameters><item name=\"model\"><![CDATA[/content/folder[@name='FIC']/package[@name='FIC_REP_CCMPackage']/model[@name='2011-08-15T20:21:03.905Z']]]></item><item name=\"storeID\"><![CDATA[i6EB092EDAC7544028133CB5911E091ED]]></item></parameters>";
		LogLine e = LogLine.parse(lineToParse);
		
		System.out.println(e);
		
		Date d = e.getDateTimeObject();
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		System.out.println( c.get(Calendar.DAY_OF_MONTH) );
		System.out.println( c.get(Calendar.MONTH) );
		System.out.println( c.get(Calendar.YEAR) );
		System.out.println( c.get(Calendar.HOUR_OF_DAY) );
		
		System.out.println( LogLineUtil.getDayAndMonth(e) );
		System.out.println( LogLineUtil.getDay(e) );
		System.out.println( LogLineUtil.getHour(e) );
	}
}
