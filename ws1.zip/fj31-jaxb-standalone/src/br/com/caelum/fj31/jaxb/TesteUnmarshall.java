package br.com.caelum.fj31.jaxb;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class TesteUnmarshall {
	public static void main(String[] args) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(Produto.class);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		Produto produto = (Produto) unmarshaller.unmarshal(new File("bola.xml"));
		System.out.println("Produto="+produto.getNome());
		System.out.println("Categoria="+produto.getCategoria().getNome());
		
	}

}
