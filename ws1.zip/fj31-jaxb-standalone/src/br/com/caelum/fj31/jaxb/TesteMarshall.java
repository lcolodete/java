package br.com.caelum.fj31.jaxb;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.sun.xml.internal.bind.marshaller.NamespacePrefixMapper;

public class TesteMarshall {


	public static void main(String[] args) throws JAXBException, FileNotFoundException {

		Produto produto = new Produto();
		produto.setNome("bola");
		produto.setPreco(23.45);
		produto.setDescricao("uma bola redonda");
		
		Categoria categoria = new Categoria();
		categoria.setNome("esportes");
		produto.setCategoria(categoria);
		
		JAXBContext ctx = JAXBContext.newInstance(Produto.class);
		Marshaller marshaller = ctx.createMarshaller();
		
		NamespacePrefixMapper prefixMapper = new MyNamespacePrefixMapper();
		marshaller.setProperty("com.sun.xml.internal.bind.namespacePrefixMapper", prefixMapper);
		
		System.out.println("Arquivo sera gerado no diretorio: "+System.getProperty("user.dir"));
		marshaller.marshal(produto, new FileOutputStream("bola.xml"));
		
		
	}

}
