package br.com.caelum.fj31.jaxb;

import com.sun.xml.internal.bind.marshaller.NamespacePrefixMapper;

public class MyNamespacePrefixMapper extends NamespacePrefixMapper {

	@Override
	public String getPreferredPrefix(String arg0, String arg1, boolean arg2) {
		return "";
	}

}
