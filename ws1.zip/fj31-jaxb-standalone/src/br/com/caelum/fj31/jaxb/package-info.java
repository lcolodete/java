@XmlSchema(namespace="123"
,
elementFormDefault = XmlNsForm.QUALIFIED
//,
//		xmlns = {
//		@javax.xml.bind.annotation.XmlNs(namespaceURI = "123777", prefix = "prdNs"),
//		@javax.xml.bind.annotation.XmlNs(namespaceURI = "http://www.w3.org/2001/XMLSchema", prefix = "xs") 
//		}
)
package br.com.caelum.fj31.jaxb;


import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

//@javax.xml.bind.annotation.XmlSchema (
//	      xmlns = {
//	        @javax.xml.bind.annotation.XmlNs(prefix = "po", 
//	                   namespaceURI="http://www.caelum.com.br/fj31"),
//
//	        @javax.xml.bind.annotation.XmlNs(prefix="xs",
//	                   namespaceURI="http://www.w3.org/2001/XMLSchema")
//	      }
// )
