package petrobras.engenharia.fic.jaxb;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import petrobras.engenharia.fic.jaxb.beans.PM;
import petrobras.engenharia.fic.jaxb.beans.PreservQueryResponse;

public class TesteUnmarshallPreservQueryResponse {
	public static void main(String[] args) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(PreservQueryResponse.class);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		PreservQueryResponse preservQueryResponse = (PreservQueryResponse) unmarshaller.unmarshal(new File("preservqueryresponse.xml"));

		System.out.println("numRecords="+preservQueryResponse.getNumRecords());
		System.out.println("maximoVersion="+preservQueryResponse.getMaximoVersion());

//		List<PM> pmList = preservQueryResponse.getPmList();
//		
//		for (PM pm : pmList) {
//			System.out.println("pm.assetNum="+pm.getAssetNum());
//			System.out.println("pm.dataProxima="+pm.getDataProxima());
//			System.out.println("pm.pmNum="+pm.getPmNum());
//			System.out.println("pm.siteid="+pm.getSiteId());
//			System.out.println("pm.status="+pm.getStatus());
//		}
		
	}

}
