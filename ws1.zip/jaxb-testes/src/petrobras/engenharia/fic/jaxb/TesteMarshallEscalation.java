package petrobras.engenharia.fic.jaxb;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import petrobras.engenharia.fic.jaxb.beans.Escalation;

public class TesteMarshallEscalation {
	
	
	public static void main(String[] args) throws JAXBException, FileNotFoundException {

		Escalation esc = new Escalation();
		esc.setActive("1");
		esc.setEscalation("FIC_OCULTATTI");
		esc.setInstancename("ESCFIC_OCULTATTI");
		esc.setLastrun("2013-12-11T18:03:31-02:00");
		esc.setObjectname("WORKORDER");
		esc.setSchedule("10m,*,*,*,*,*,*,*,*,*");
		
		JAXBContext ctx = JAXBContext.newInstance(Escalation.class);
		Marshaller marshaller = ctx.createMarshaller();
		marshaller.marshal(esc, new FileOutputStream("escalation.xml"));
		System.out.println("Arquivo gerado no diretorio: "+System.getProperty("user.dir"));
	}

}
