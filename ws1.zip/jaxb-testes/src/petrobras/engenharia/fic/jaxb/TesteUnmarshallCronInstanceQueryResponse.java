package petrobras.engenharia.fic.jaxb;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import petrobras.engenharia.fic.jaxb.beans.CronInstanceQueryResponse;
import petrobras.engenharia.fic.jaxb.beans.CronTaskInstance;

public class TesteUnmarshallCronInstanceQueryResponse {
	public static void main(String[] args) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(CronInstanceQueryResponse.class);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		CronInstanceQueryResponse cronInstanceQueryResponse = (CronInstanceQueryResponse) unmarshaller.unmarshal(new File("crontaskinstancequeryresponse.xml"));

		List<CronTaskInstance> cronTaskInstanceSet = cronInstanceQueryResponse.getCronInstances();
		
		for (CronTaskInstance cronTaskInstance : cronTaskInstanceSet) {
			System.out.println(">>>>> Cron Task Instance Name: " + cronTaskInstance.getInstancename());
			System.out.println("instance.crontaskinstanceid="+cronTaskInstance.getCrontaskinstanceid());
			System.out.println("instance.runasuserid="+cronTaskInstance.getRunasuserid());
			System.out.println("instance.active="+cronTaskInstance.getActive());
			System.out.println("instance.schedule="+cronTaskInstance.getSchedule());

			System.out.println("instance.maxuser="+cronTaskInstance.getMaxUser().getUserid());
			System.out.println("instance.empreendimento="+cronTaskInstance.getEmpreendimento());
		}
		
	}

}
