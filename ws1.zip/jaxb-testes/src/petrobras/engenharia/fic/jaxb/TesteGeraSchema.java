package petrobras.engenharia.fic.jaxb;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.SchemaOutputResolver;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;

import petrobras.engenharia.fic.jaxb.beans.CronHistQueryResponse;

public class TesteGeraSchema {


	public static void main(String[] args) throws Exception {
		
		JAXBContext context = JAXBContext.newInstance(CronHistQueryResponse.class);
		context.generateSchema(new SchemaOutputResolver() {
			@Override
			public Result createOutput(String namespaceUri, String suggestedFileName) throws IOException
			{
				StreamResult result = new StreamResult(new File("teste.xsd"));
				return result;
			}
			
		}
				
		);

	}

}
