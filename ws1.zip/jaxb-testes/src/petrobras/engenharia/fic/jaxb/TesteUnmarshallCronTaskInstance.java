package petrobras.engenharia.fic.jaxb;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import petrobras.engenharia.fic.jaxb.beans.CronTaskInstance;
import petrobras.engenharia.fic.jaxb.beans.CronTaskParam;
import petrobras.engenharia.fic.jaxb.beans.MaxUser;



public class TesteUnmarshallCronTaskInstance {
	
	public static void main(String[] args) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(CronTaskInstance.class);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		CronTaskInstance cronTaskInstance = (CronTaskInstance) unmarshaller.unmarshal(new File("crontaskinstance.xml"));

		System.out.println(">>>>> Cron Task Instance Name: "+cronTaskInstance.getInstancename());
		System.out.println("cronTaskInstance.active="+cronTaskInstance.getActive());
		System.out.println("cronTaskInstance.crontaskname="+cronTaskInstance.getCrontaskname());
		System.out.println("cronTaskInstance.schedule="+cronTaskInstance.getSchedule());

		MaxUser maxUser = cronTaskInstance.getMaxUser();
		
		System.out.println("cronTaskInstance.maxuser.defsite="+maxUser.getDefsite());
		System.out.println("cronTaskInstance.maxuser.loginid="+maxUser.getLoginid());
		System.out.println("cronTaskInstance.maxuser.maxuserid="+maxUser.getMaxuserid());
		System.out.println("cronTaskInstance.maxuser.userid="+maxUser.getUserid());
		
		List<CronTaskParam> params = cronTaskInstance.getParams();
		System.out.println("params="+params);
	}

}
