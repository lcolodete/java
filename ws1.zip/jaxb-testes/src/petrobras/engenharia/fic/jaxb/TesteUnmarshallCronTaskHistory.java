package petrobras.engenharia.fic.jaxb;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import petrobras.engenharia.fic.jaxb.beans.CronTaskHistory;

public class TesteUnmarshallCronTaskHistory {
	public static void main(String[] args) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(CronTaskHistory.class);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		CronTaskHistory cronTaskHist = (CronTaskHistory) unmarshaller.unmarshal(new File("crontaskhistory.xml"));

		System.out.println(">>>>> Cron Task Instance Name: "+cronTaskHist.getInstancename());
		System.out.println("cronTaskHist.sequence="+cronTaskHist.getSequence());
		System.out.println("cronTaskHist.activity="+cronTaskHist.getActivity());
		System.out.println("cronTaskHist.starttime="+cronTaskHist.getStarttime());
		System.out.println("cronTaskHist.endtime="+cronTaskHist.getEndtime());
		System.out.println("cronTaskHist.servername="+cronTaskHist.getServername());
		System.out.println("cronTaskHist.serverhost="+cronTaskHist.getServerhost());
	}

}
