package petrobras.engenharia.fic.jaxb.beans;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QueryMXESCALATIONResponse")
public class EscalationQueryResponse {

/*
<?xml version="1.0" encoding="UTF-8"?>
<QueryMXESCALATIONResponse 
    xmlns="http://www.ibm.com/maximo" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" creationDateTime="2013-12-11T18:06:47-02:00" transLanguage="PT" baseLanguage="PT" messageID="1386792407523381124" maximoVersion="7 1 20120709-1611 V71111-19" rsStart="0" rsCount="54" rsTotal="54">
    <MXESCALATIONSet>
        <ESCALATION>
            <ACTIVE>1</ACTIVE>
            <ESCALATION>FIC_OCULTATTI</ESCALATION>
            <INSTANCENAME>ESCFIC_OCULTATTI</INSTANCENAME>
            <LASTRUN>2013-12-11T18:03:31-02:00</LASTRUN>
            <OBJECTNAME>WORKORDER</OBJECTNAME>
            <SCHEDULE>10m,*,*,*,*,*,*,*,*,*</SCHEDULE>
        </ESCALATION>
...
*/
	
	private List<Escalation> escalations;

	@XmlElementWrapper(name="MXESCALATIONSet")
	@XmlElements({
		@XmlElement(name="ESCALATION")
	})
	public List<Escalation> getEscalations() {
		return escalations;
	}

	public void setEscalations(List<Escalation> escalations) {
		this.escalations = escalations;
	}
	
	
}
