package petrobras.engenharia.fic.jaxb.beans;

import javax.xml.bind.annotation.XmlElement;

public class CronTaskParam {

	private String parameter;
	private String value;
	
	@XmlElement(name="PARAMETER")
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	
	@XmlElement(name="VALUE")
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return "("+parameter+"="+value+")";
	}
}
