package petrobras.engenharia.fic.jaxb.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name="PM")
public class PM {

//	<PM>
//		<ASSETNUM>118702</ASSETNUM>
//		<FIC_DATA_PROX>2015-11-22T00:00:00-02:00</FIC_DATA_PROX>
//		<PMNUM>106585</PMNUM>
//		<SITEID>COMPERJ-IEUT</SITEID>
//		<STATUS maxvalue="ACTIVE">ATIVO</STATUS>
//	</PM>

//	private String assetNum;
//	private String dataProxima;
//	private String pmNum;
//	private String siteId;
//	private String status;
//	
////	@XmlElement(name="ASSETNUM")
//	@XmlTransient
//	public String getAssetNum() {
//		return assetNum;
//	}
//	
//	public void setAssetNum(String assetNum) {
//		this.assetNum = assetNum;
//	}
//	
////	@XmlElement(name="FIC_DATA_PROX")
//	@XmlTransient
//	public String getDataProxima() {
//		return dataProxima;
//	}
//	
//	public void setDataProxima(String dataProxima) {
//		this.dataProxima = dataProxima;
//	}
//	
////	@XmlElement(name="PMNUM")
//	@XmlTransient
//	public String getPmNum() {
//		return pmNum;
//	}
//	
//	public void setPmNum(String pmNum) {
//		this.pmNum = pmNum;
//	}
//	
////	@XmlElement(name="SITEID")
//	@XmlTransient
//	public String getSiteId() {
//		return siteId;
//	}
//	
//	public void setSiteId(String siteId) {
//		this.siteId = siteId;
//	}
//	
////	@XmlElement(name="STATUS")
//	@XmlTransient
//	public String getStatus() {
//		return status;
//	}
//	
//	public void setStatus(String status) {
//		this.status = status;
//	}
}
