package petrobras.engenharia.fic.jaxb.beans;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ESCALATION")
public class Escalation implements Serializable, Comparable<Escalation> {
	
	private static final long serialVersionUID = 1L;

	/*
    <ESCALATION>
	    <ACTIVE>1</ACTIVE>
	    <ESCALATION>FIC_OCULTATTI</ESCALATION>
	    <INSTANCENAME>ESCFIC_OCULTATTI</INSTANCENAME>
	    <LASTRUN>2013-12-11T18:03:31-02:00</LASTRUN>
	    <OBJECTNAME>WORKORDER</OBJECTNAME>
	    <SCHEDULE>10m,*,*,*,*,*,*,*,*,*</SCHEDULE>
    </ESCALATION>
	*/
	
	private String active;
	private String escalation;
	private String instancename;
	private String lastrun;
	private String objectname;
	private String schedule;
	
	@XmlElement(name="ACTIVE")
	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	@XmlElement(name="ESCALATION")
	public String getEscalation() {
		return escalation;
	}

	public void setEscalation(String escalation) {
		this.escalation = escalation;
	}

	@XmlElement(name="INSTANCENAME")
	public String getInstancename() {
		return instancename;
	}

	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}

	@XmlElement(name="LASTRUN")
	public String getLastrun() {
		return lastrun;
	}

	public void setLastrun(String lastrun) {
		this.lastrun = lastrun;
	}

	@XmlElement(name="OBJECTNAME")
	public String getObjectname() {
		return objectname;
	}

	public void setObjectname(String objectname) {
		this.objectname = objectname;
	}

	@XmlElement(name="SCHEDULE")
	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	@Override
	public int compareTo(Escalation o) {
		return 0;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((escalation == null) ? 0 : escalation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Escalation other = (Escalation) obj;
		if (escalation == null) {
			if (other.escalation != null)
				return false;
		} else if (!escalation.equals(other.escalation))
			return false;
		return true;
	}

	
}
