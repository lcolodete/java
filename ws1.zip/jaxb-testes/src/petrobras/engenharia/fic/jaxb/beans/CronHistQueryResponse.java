package petrobras.engenharia.fic.jaxb.beans;

import java.util.Set;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="QueryMXCRONHISTResponse")
public class CronHistQueryResponse {
	
	private Set<CronTaskHistory> cronTaskSet;

	@XmlElementWrapper(name="MXCRONHISTSet")
	@XmlElements({
		@XmlElement(name="CRONTASKHISTORY")
	})
	public Set<CronTaskHistory> getCronTaskSet() {
		return cronTaskSet;
	}

	public void setCronTaskSet(Set<CronTaskHistory> cronTaskSet) {
		this.cronTaskSet = cronTaskSet;
	}
	
	
}
