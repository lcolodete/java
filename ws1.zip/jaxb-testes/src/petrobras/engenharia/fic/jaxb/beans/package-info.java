@XmlSchema( namespace="http://www.ibm.com/maximo", 
			elementFormDefault = XmlNsForm.QUALIFIED,
			xmlns = {
        		@XmlNs( prefix = "max", 
        				namespaceURI="http://www.ibm.com/maximo")
        	}
)

package petrobras.engenharia.fic.jaxb.beans;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

