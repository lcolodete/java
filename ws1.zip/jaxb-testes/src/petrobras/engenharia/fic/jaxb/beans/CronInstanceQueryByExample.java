package petrobras.engenharia.fic.jaxb.beans;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QueryMXCRONINSTANCE")
public class CronInstanceQueryByExample {

	private List<CronTaskInstance> cronInstances;

	@XmlElementWrapper(name="MXCRONINSTANCEQuery")
	@XmlElements({
		@XmlElement(name="CRONTASKINSTANCE")
	})
	public List<CronTaskInstance> getCronInstances() {
		return cronInstances;
	}

	public void setCronInstances(List<CronTaskInstance> cronInstances) {
		this.cronInstances = cronInstances;
	}

}
