package petrobras.engenharia.fic.jaxb.beans;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QueryMXCRONINSTANCEResponse")
public class CronInstanceQueryResponse {

/*
	<?xml version='1.0' encoding='utf-8'?>
	<QueryMXCRONINSTANCEResponse 
	    xmlns="http://www.ibm.com/maximo" 
	    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" creationDateTime="2013-04-01T15:46:09-03:00" transLanguage="PT" baseLanguage="PT" messageID="1364841970136284322" maximoVersion="7 1 20091208-1415 V7116-173" rsStart="0" rsCount="26" rsTotal="26">
	    <MXCRONINSTANCESet>
	        <CRONTASKINSTANCE>
	            <ACTIVE>1</ACTIVE>
	            <AUTOREMOVAL>0</AUTOREMOVAL>
	            <CRONTASKINSTANCEID>1103</CRONTASKINSTANCEID>
	            <CRONTASKNAME>PMWoGenCronTask</CRONTASKNAME>
	            <DESCRIPTION>Tarefa Cron de PmWogen</DESCRIPTION>
	            <INSTANCENAME>COMPERJ-ETAPA1-IEAROM</INSTANCENAME>
	            <KEEPHISTORY>1</KEEPHISTORY>
	            <MAXHISTORY>1000</MAXHISTORY>
	            <NEXTRUNTMOVERWRITE xsi:nil="true"></NEXTRUNTMOVERWRITE>
	            <RELOADREQTIME>2012-03-29T16:55:46-03:00</RELOADREQTIME>
	            <RUNASUSERID>PRV_COMP_IEAROM</RUNASUSERID>
	            <SCHEDULE>1w,0,0,0,*,*,*,6,*,*</SCHEDULE>
	        </CRONTASKINSTANCE>
		</MXCRONINSTANCESet>
	</QueryMXCRONINSTANCEResponse>

*/
	
	private List<CronTaskInstance> cronInstances;

	@XmlElementWrapper(name="MXCRONINSTANCESet")
	@XmlElements({
		@XmlElement(name="CRONTASKINSTANCE")
	})
	public List<CronTaskInstance> getCronInstances() {
		return cronInstances;
	}

	public void setCronInstances(List<CronTaskInstance> cronInstances) {
		this.cronInstances = cronInstances;
	}
	
	
	
}
