package petrobras.engenharia.fic.jaxb.beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="CRONTASKHISTORY")
public class CronTaskHistory {

//<CRONTASKHISTORY>
//    <ACTIVITY>ACTION</ACTIVITY>
//    <CRONTASKHISTORYID>6093288</CRONTASKHISTORYID>
//    <CRONTASKNAME>PMWoGenCronTask</CRONTASKNAME>
//    <ENDTIME>2012-04-20T02:32:26-03:00</ENDTIME>
//    <INSTANCENAME>CMTL</INSTANCENAME>
//    <RUNTIMEERROR></RUNTIMEERROR>
//    <SEQUENCE>231</SEQUENCE>
//    <SERVERHOST>10.152.47.5</SERVERHOST>
//    <SERVERNAME>MXServerESC1</SERVERNAME>
//    <STARTTIME>2012-04-20T02:01:13-03:00</STARTTIME>
//</CRONTASKHISTORY>
	
	
	private String activity;
	private String crontaskhistoryid;
	private String crontaskname;
	private String endtime;
	private String instancename;
	private String runtimeerror;
	private String sequence;
	private String serverhost;
	private String servername;
	private String starttime;
	
	@XmlElement(name="ACTIVITY")
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	
	@XmlElement(name="CRONTASKHISTORYID")
	public String getCrontaskhistoryid() {
		return crontaskhistoryid;
	}
	public void setCrontaskhistoryid(String crontaskhistoryid) {
		this.crontaskhistoryid = crontaskhistoryid;
	}
	
	@XmlElement(name="CRONTASKNAME")
	public String getCrontaskname() {
		return crontaskname;
	}
	public void setCrontaskname(String crontaskname) {
		this.crontaskname = crontaskname;
	}
	
	@XmlElement(name="ENDTIME")
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	
	@XmlElement(name="INSTANCENAME")
	public String getInstancename() {
		return instancename;
	}
	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}
	
	@XmlElement(name="RUNTIMEERROR")
	public String getRuntimeerror() {
		return runtimeerror;
	}
	public void setRuntimeerror(String runtimeerror) {
		this.runtimeerror = runtimeerror;
	}
	
	@XmlElement(name="SEQUENCE")
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	
	@XmlElement(name="SERVERHOST")
	public String getServerhost() {
		return serverhost;
	}
	public void setServerhost(String serverhost) {
		this.serverhost = serverhost;
	}
	
	@XmlElement(name="SERVERNAME")
	public String getServername() {
		return servername;
	}
	public void setServername(String servername) {
		this.servername = servername;
	}
	
	@XmlElement(name="STARTTIME")
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	
	
}
