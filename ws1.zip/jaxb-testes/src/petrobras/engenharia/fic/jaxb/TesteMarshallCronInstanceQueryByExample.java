package petrobras.engenharia.fic.jaxb;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Arrays;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import petrobras.engenharia.fic.jaxb.beans.CronTaskHistory;
import petrobras.engenharia.fic.jaxb.beans.CronTaskInstance;
import petrobras.engenharia.fic.jaxb.beans.CronTaskParam;
import petrobras.engenharia.fic.jaxb.beans.MaxUser;
import petrobras.engenharia.fic.jaxb.beans.CronInstanceQueryByExample;

public class TesteMarshallCronInstanceQueryByExample {


	public static void main(String[] args) throws JAXBException, FileNotFoundException {

		CronTaskInstance cronInstance = new CronTaskInstance();
		cronInstance.setActive("1");
		cronInstance.setAutoremoval("0");
		cronInstance.setCrontaskinstanceid("1101");
		cronInstance.setCrontaskname("PMWoGenCronTask");
		cronInstance.setDescription("Tarefa Cron de PmWogen");
		cronInstance.setInstancename("CMTL");
		cronInstance.setKeephistory("1");
		cronInstance.setMaxhistory("1000");
		cronInstance.setReloadreqtime("2013-04-19T12:39:24-03:00");
		cronInstance.setRunasuserid("FICCRONCMTL");
		cronInstance.setSchedule("1w,0,0,2,*,*,*,6,*,*");
		
		MaxUser maxUser = new MaxUser();
		maxUser.setDefsite("CMTL");
		maxUser.setLoginid("FICCRONCMTL");
		maxUser.setMaxuserid("364");
		maxUser.setUserid("FICCRONCMTL");
		
		cronInstance.setMaxUser(maxUser);
		
		CronTaskParam param1 = new CronTaskParam();
		param1.setParameter("EMPREENDIMENTO");
		param1.setValue("UO-SEAL-SA1815");
		
		cronInstance.setParams(Arrays.asList(param1));
		
		CronInstanceQueryByExample queryObj = new CronInstanceQueryByExample();
		queryObj.setCronInstances(Arrays.asList(cronInstance));
		
		JAXBContext ctx = JAXBContext.newInstance(CronInstanceQueryByExample.class);
		Marshaller marshaller = ctx.createMarshaller();
		System.out.println("Arquivo sera gerado no diretorio: "+System.getProperty("user.dir"));
		marshaller.marshal(queryObj, new FileOutputStream("queryByExample.xml"));
		
		
	}

}
