package petrobras.engenharia.fic.jaxb;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import petrobras.engenharia.fic.jaxb.beans.CronHistQueryResponse;
import petrobras.engenharia.fic.jaxb.beans.CronTaskHistory;

public class TesteMarshallCronHistQueryResponse {


	public static void main(String[] args) throws JAXBException, FileNotFoundException {

		
		CronTaskHistory cronTaskHist = new CronTaskHistory();
		cronTaskHist.setActivity("ACTION");
		cronTaskHist.setCrontaskhistoryid("6093288");
		cronTaskHist.setCrontaskname("PMWoGenCronTask");
		cronTaskHist.setEndtime("2012-04-20T02:32:26-03:00");
		cronTaskHist.setInstancename("CMTL");
		cronTaskHist.setRuntimeerror("");
		cronTaskHist.setSequence("231");
		cronTaskHist.setServerhost("10.152.47.5");
		cronTaskHist.setServername("MXServerESC1");
		cronTaskHist.setStarttime("2012-04-20T02:01:13-03:00");
		
		CronTaskHistory cronTaskHist2 = new CronTaskHistory();
		cronTaskHist2.setActivity("ACTION");
		cronTaskHist2.setCrontaskhistoryid("1234567");
		cronTaskHist2.setCrontaskname("PMWoGenCronTask");
		cronTaskHist2.setEndtime("2012-05-20T03:32:26-03:00");
		cronTaskHist2.setInstancename("COMPERJ-XYZ");
		cronTaskHist2.setRuntimeerror("");
		cronTaskHist2.setSequence("987");
		cronTaskHist2.setServerhost("10.152.47.7");
		cronTaskHist2.setServername("MXServerESC3");
		cronTaskHist2.setStarttime("2012-05-20T03:01:13-03:00");

		
		CronHistQueryResponse queryResponse = new CronHistQueryResponse();
		
		//1
//		queryResponse.cronTaskHist = cronTaskHist;

		//2
		Set<CronTaskHistory> cronTaskSet = new HashSet<CronTaskHistory>();
		cronTaskSet.add(cronTaskHist);
		cronTaskSet.add(cronTaskHist2);
		queryResponse.setCronTaskSet(cronTaskSet);

		//3
//		CronTaskHistory[] cronTaskHistoryArray = {cronTaskHist, cronTaskHist2};
//		queryResponse.cronTaskArray = cronTaskHistoryArray;

		//4
//		CronHistSet cronHistSet = new CronHistSet();
//		cronHistSet.cronTaskSet = new HashSet<CronTaskHistory>();
//		cronHistSet.cronTaskSet.add(cronTaskHist);
//		cronHistSet.cronTaskSet.add(cronTaskHist2);
		
		JAXBContext ctx = JAXBContext.newInstance(CronHistQueryResponse.class);
		Marshaller marshaller = ctx.createMarshaller();
		System.out.println("Arquivo sera gerado no diretorio: "+System.getProperty("user.dir"));
		marshaller.marshal(queryResponse, new FileOutputStream("cronhistqueryresponse.xml"));
		
		
	}

}
