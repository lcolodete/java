package petrobras.engenharia.fic.jaxb;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import petrobras.engenharia.fic.jaxb.beans.Escalation;
import petrobras.engenharia.fic.jaxb.beans.EscalationQueryResponse;

public class TesteUnmarshallEscalationQueryResponse {
	public static void main(String[] args) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(EscalationQueryResponse.class);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		EscalationQueryResponse escalationQueryResponse = (EscalationQueryResponse) unmarshaller.unmarshal(new File("escalationqueryresponse.xml"));

		List<Escalation> escalations = escalationQueryResponse.getEscalations();
		
		for (Escalation esc : escalations) {
			System.out.println("escalation.active="+esc.getActive());
			System.out.println("escalation.escalation="+esc.getEscalation());
			System.out.println("escalation.instancename="+esc.getInstancename());
			System.out.println("escalation.lastrun="+esc.getLastrun());
			System.out.println("escalation.objectname="+esc.getObjectname());
			System.out.println("escalation.schedule="+esc.getSchedule());
		}
		
	}

}
