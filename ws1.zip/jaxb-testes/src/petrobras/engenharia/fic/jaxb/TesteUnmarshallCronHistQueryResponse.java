package petrobras.engenharia.fic.jaxb;

import java.io.File;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import petrobras.engenharia.fic.jaxb.beans.CronHistQueryResponse;
import petrobras.engenharia.fic.jaxb.beans.CronTaskHistory;

public class TesteUnmarshallCronHistQueryResponse {
	public static void main(String[] args) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(CronHistQueryResponse.class);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		CronHistQueryResponse cronHistQueryResponse = (CronHistQueryResponse) unmarshaller.unmarshal(new File("cronhistqueryresponse.xml"));

		Set<CronTaskHistory> cronTaskHistSet = cronHistQueryResponse.getCronTaskSet();
		
		for (CronTaskHistory cronTaskHist : cronTaskHistSet) {
			
			System.out.println(">>>>> Cron Task Instance Name: "+cronTaskHist.getInstancename());
			System.out.println("cronTaskHist.sequence="+cronTaskHist.getSequence());
			System.out.println("cronTaskHist.activity="+cronTaskHist.getActivity());
			System.out.println("cronTaskHist.starttime="+cronTaskHist.getStarttime());
			System.out.println("cronTaskHist.endtime="+cronTaskHist.getEndtime());
			System.out.println("cronTaskHist.servername="+cronTaskHist.getServername());
			System.out.println("cronTaskHist.serverhost="+cronTaskHist.getServerhost());
		}
		
	}

}
