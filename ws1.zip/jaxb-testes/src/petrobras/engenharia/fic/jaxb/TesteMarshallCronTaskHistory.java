package petrobras.engenharia.fic.jaxb;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import petrobras.engenharia.fic.jaxb.beans.CronTaskHistory;

public class TesteMarshallCronTaskHistory {


	public static void main(String[] args) throws JAXBException, FileNotFoundException {

		
		CronTaskHistory cronTaskHist = new CronTaskHistory();
		cronTaskHist.setActivity("ACTION");
		cronTaskHist.setCrontaskhistoryid("6093288");
		cronTaskHist.setCrontaskname("PMWoGenCronTask");
		cronTaskHist.setEndtime("2017-04-12T15:13:26-03:00");
		cronTaskHist.setInstancename("CMTL");
		cronTaskHist.setRuntimeerror("");
		cronTaskHist.setSequence("231");
		cronTaskHist.setServerhost("10.152.47.5");
		cronTaskHist.setServername("MXServerESC1");
		cronTaskHist.setStarttime("2012-04-20T02:01:13-03:00");

		
		JAXBContext ctx = JAXBContext.newInstance(CronTaskHistory.class);
		Marshaller marshaller = ctx.createMarshaller();
		System.out.println("Arquivo sera gerado no diretorio: "+System.getProperty("user.dir"));
		marshaller.marshal(cronTaskHist, new FileOutputStream("crontaskhistory.xml"));
		
		
	}

}
