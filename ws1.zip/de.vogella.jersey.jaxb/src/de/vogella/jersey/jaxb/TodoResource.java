package de.vogella.jersey.jaxb;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import de.vogella.jersey.jaxb.model.Todo;

@Path("/todo")
public class TodoResource {
	// This method is called if XML is requested
	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Todo getXML() {
		
		System.out.println("getXML()");
		
		Todo todo = new Todo();
		todo.setSummary("My first todo - summary");
		todo.setDescription("first todo - description: application/xml ou json");
		return todo;
	}

	// This can be used to test the integration with the browser
	@GET
	@Produces({ MediaType.TEXT_XML })
	public Todo getHTML() {
		
		System.out.println("getHTML()");
		
		Todo todo = new Todo();
		todo.setSummary("first todo - summary");
		todo.setDescription("first todo - desc - text/xml");
		return todo;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getTextPlain() {
		
		System.out.println("getTextPlain()");

		return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><todo><description>first todo - desc - text/plain</description><summary>first todo - summary</summary></todo>";
	}

}
