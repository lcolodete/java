package de.vogella.jersey.jaxb.client;

import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import test.filter.ChangeResponseMediaTypeFilter;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.LoggingFilter;

import de.vogella.jersey.jaxb.model.Todo;

public class TestUnmarshal {
	public static void main(String[] args) {
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		
		client.addFilter(new ChangeResponseMediaTypeFilter());
//		client.addFilter(new LoggingFilter());
		
		WebResource service = client.resource(getBaseURI());

//		System.out.println(service.path("rest").path("todo")
//				.accept(MediaType.APPLICATION_XML).get(String.class));
		
		Todo t = service.path("rest").path("todo")
				.accept(MediaType.APPLICATION_XML).get(Todo.class);
		
		System.out.println("t.description=["+t.getDescription()+"]");
		System.out.println("t.summary=["+t.getSummary()+"]");
		
		System.out.println("\n\n");

//		System.out.println(service.path("rest").path("todo")
//				.accept(MediaType.APPLICATION_JSON).get(String.class));
		
		Todo tJson = service.path("rest").path("todo")
				.accept(MediaType.APPLICATION_JSON).get(Todo.class);
		
		System.out.println("t.description=["+tJson.getDescription()+"]");
		System.out.println("t.summary=["+tJson.getSummary()+"]");

//		System.out.println(service.path("rest").path("todo")
//				.accept(MediaType.TEXT_PLAIN).get(String.class));
//
		Todo tText = service.path("rest").path("todo")
				.accept(MediaType.TEXT_PLAIN).get(Todo.class);
		
		System.out.println("t.description=["+tText.getDescription()+"]");
		System.out.println("t.summary=["+tText.getSummary()+"]");
		
	}

	private static URI getBaseURI() {
		return UriBuilder.fromUri(
				"http://localhost:8088/de.vogella.jersey.jaxb").build();
	}

}