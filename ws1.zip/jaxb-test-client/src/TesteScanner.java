import java.util.Scanner;


public class TesteScanner {

	public static void main(String[] args) {
		System.out.println("teste");
		
		Scanner scan = new Scanner(System.in);

		 /* Declare second integer, double, and String variables. */
        int scan_i = 0;
        double scan_d = 0.0;
        String scan_str = null;

        /* Read and save an integer, double, and String to your variables.*/
//        scan_i = scan.nextInt(); 
        scan_i = Integer.parseInt( scan.nextLine() );
//        scan_d = scan.nextDouble();
        scan_d = Double.parseDouble( scan.nextLine() );

        scan_str = scan.nextLine();
        
//        while (scan.hasNext()) {
//        	scan_str += scan.next(); 
//        }
        
        
        System.out.println("> "+scan_i);
System.out.println("> "+scan_d);
System.out.println("> "+scan_str);
	}
	
	
	
	
}
