import com.sun.jersey.core.util.Base64;


public class TestBase64 {

	public static void main(String[] args) {
		TestBase64 base64 = new TestBase64();
		
		testEncodeUserPassword(base64);
//		testEncodePassword(base64);
//		testDecode(base64);
	}

	private static void testEncodeUserPassword(TestBase64 base64) {
//		String s = "UR5G:c1o2Maximo";
//		String s = "UR5G:tQy5clp1";
//		String s = "maxservice:pAdrao01";
		String s = "ENG-E&P_PROJEN_DNP:pAdrao01";
		
		byte[] bEncoded = base64.encode(s);

		String sEncoded = base64.byteArrayToAsciiString(bEncoded);
		
		System.out.println( sEncoded );

	}
	
	private static void testEncodePassword(TestBase64 base64) {
		String s = "pAdrao01";

		byte[] bEncoded = base64.encode(s);

		String sEncoded = base64.byteArrayToAsciiString(bEncoded);
		
		System.out.println( sEncoded );

	}
	
	private static void testDecode(TestBase64 base64) {
//		String s = "dFF5NWNscDE=";
		String s = "YzFvMk1heGltbw==";
//		String s = "AQgAAADJZm1XAAAAAAoAAAA2t8t+fmvm6I0rFAAAAFCMCnYIhdChrXmO9COEHScLcxYrFAAAACXNTnVdl5sly7H8Wzma5AIsw9Xe";
		
//		byte[] bDecoded = base64.decode(bEncoded);
		byte[] bDecoded = base64.decode(s);
		
		String sDecoded = base64.byteArrayToAsciiString(bDecoded);
		
		System.out.println(sDecoded);

	}
	
	public byte[] encode(String s) {
		byte[] result = Base64.encode(s);
		
		return result;
	}
	
//	public String encode(String s) {
//		byte[] result = Base64.encode(s);
//		
//		return new String(result);
//	}
	
	public String byteArrayToAsciiString(byte[] b) {
		return new String(b);
	}
	
	public byte[] decode(byte[] b) {
		byte[] bDecoded = Base64.decode(b);
		
		return bDecoded;
	}
	
	public byte[] decode(String s) {
		byte[] bDecoded = Base64.decode(s);
		
		return bDecoded;
	}
	
//	public String decode(byte[] b) {
//		byte[] bDecoded = Base64.decode(b);
//		
//		System.out.println(bDecoded);
//		
//		return new String(bDecoded);
//	}
}
