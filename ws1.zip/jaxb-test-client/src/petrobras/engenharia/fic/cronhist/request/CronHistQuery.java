package petrobras.engenharia.fic.cronhist.request;

public class CronHistQuery {

	private StringBuilder xmlBegin;
	
	private StringBuilder xmlEnd;
	
	private String where;
	
	public String getWhere() {
		return where;
	}

	public void setWhere(String where) {
		this.where = where;
	}

	{
		xmlBegin = new StringBuilder();
		xmlBegin.append("<max:QueryMXCRONHIST xmlns:max=\"http://www.ibm.com/maximo\" >")
				.append("<max:MXCRONHISTQuery>");
				

		xmlEnd = new StringBuilder();
		xmlEnd.append("</max:MXCRONHISTQuery>")
			  .append("</max:QueryMXCRONHIST>");
	}
	
	
	public CronHistQuery(String where) {
		this.where = where;
	}
	
	public String getXml() {

		StringBuilder xmlWhere = new StringBuilder();
		xmlWhere.append("<max:WHERE>")
				.append(this.where)
				.append("</max:WHERE>");
				
		return xmlBegin.append(xmlWhere).append(xmlEnd).toString(); 
	}
}
