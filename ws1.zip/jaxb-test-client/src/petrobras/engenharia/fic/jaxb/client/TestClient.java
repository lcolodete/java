package petrobras.engenharia.fic.jaxb.client;

import java.net.URI;
import java.util.Set;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import petrobras.engenharia.fic.cronhist.request.CronHistQuery;
import petrobras.engenharia.fic.jaxb.beans.CronHistQueryResponse;
import petrobras.engenharia.fic.jaxb.beans.CronTaskHistory;
import test.filter.ChangeResponseMediaTypeFilter;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestClient {

	public static void main(String[] args) {
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		
		client.addFilter(new ChangeResponseMediaTypeFilter());
		
		WebResource service = client.resource(getBaseURI());

		CronHistQuery query1 = new CronHistQuery("instancename='CMTL' and activity='ACTION' and ENDTIME=(select max(ENDTIME) from CRONTASKHISTORY where instancename='CMTL' and activity='ACTION' )");
		
		CronHistQuery query2 = new CronHistQuery("(instancename='CMTL' and activity='ACTION' and ENDTIME=(select max(ENDTIME) from CRONTASKHISTORY where instancename='CMTL' and activity='ACTION' ) )  or (instancename='COMPERJ-ETAPA1-IEAROM' and activity='ACTION' and ENDTIME=(select max(ENDTIME) from CRONTASKHISTORY where instancename='COMPERJ-ETAPA1-IEAROM' and activity='ACTION' ) )");
		
		CronHistQueryResponse cronHistQueryResponse = service.path("os").path("MXCRONHIST")
				.accept(MediaType.APPLICATION_XML)
				.header("MAXAUTH", "VVI1Rzp0UXk1Y2xwMQ==")
				.post(CronHistQueryResponse.class, query2.getXml());
		

		Set<CronTaskHistory> cronTaskHistSet = cronHistQueryResponse.getCronTaskSet();
		
		for (CronTaskHistory cronTaskHist : cronTaskHistSet) {
			
			System.out.println(">>>>> Cron Task Instance Name: "+cronTaskHist.getInstancename());
			System.out.println("cronTaskHist.sequence="+cronTaskHist.getSequence());
			System.out.println("cronTaskHist.activity="+cronTaskHist.getActivity());
			System.out.println("cronTaskHist.starttime="+cronTaskHist.getStarttime());
			System.out.println("cronTaskHist.endtime="+cronTaskHist.getEndtime());
			System.out.println("cronTaskHist.servername="+cronTaskHist.getServername());
			System.out.println("cronTaskHist.serverhost="+cronTaskHist.getServerhost());
		}

	}
	
	private static URI getBaseURI() {
		return UriBuilder.fromUri(
				"http://localhost:7001/meaweb").build();
	}

}
