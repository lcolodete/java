package petrobras.engenharia.fic.jaxb.client;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import petrobras.engenharia.fic.jaxb.beans.CronInstanceQueryByExample;
import petrobras.engenharia.fic.jaxb.beans.CronInstanceQueryResponse;
import petrobras.engenharia.fic.jaxb.beans.CronTaskInstance;
import petrobras.engenharia.fic.jaxb.beans.CronTaskParam;
import test.filter.ChangeResponseMediaTypeFilter;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestClient2 {

	public static void main(String[] args) {
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		
		client.addFilter(new ChangeResponseMediaTypeFilter());
		
		WebResource service = client.resource(getBaseURI());

		CronTaskInstance cronInstance = new CronTaskInstance();
		cronInstance.setActive("1");
		cronInstance.setCrontaskname("FIC SISPEN");
		
		CronTaskParam param1 = new CronTaskParam();
		param1.setValue("ieut,iehca");
		
		cronInstance.setParams(Arrays.asList(param1));
		
		CronInstanceQueryByExample queryObj = new CronInstanceQueryByExample();
		queryObj.setCronInstances(Arrays.asList(cronInstance));

		
		CronInstanceQueryResponse cronInstanceQueryResponse = service.path("os").path("MXCRONINSTANCE")
				.accept(MediaType.APPLICATION_XML)
				.header("MAXAUTH", "bWF4c2VydmljZTpwQWRyYW8wMQ==")
				.entity(queryObj)
				.post(CronInstanceQueryResponse.class);

		List<CronTaskInstance> cronTaskInstanceSet = cronInstanceQueryResponse.getCronInstances();
		
		for (CronTaskInstance cronTaskInstance : cronTaskInstanceSet) {
			System.out.println(">>>>> Cron Task Instance Name: " + cronTaskInstance.getInstancename());
			System.out.println("instance.active="+cronTaskInstance.getActive());
		}

	}
	
	private static URI getBaseURI() {
		return UriBuilder.fromUri(
				"https://fic.petrobras.com.br/meaweb").build();
	}

}
